% 
% RT (295)
%
% EEG.icaact = [30x2000x295 single]
% 

ic=7;
[Y,I]=sort(RT);
baseline=reshape(EEG.icaact(ic,1:500,I),500,224);

[PB, freqs, times]=timefreq(baseline, 250, 'wavelet', 0, 'freqs', [3 45], 'winsize', 128, 'padratio',2);
PB=10*log10(PB.*conj(PB));
PB=mean(PB,2);
PB=reshape(PB, 44, 224); % 44 x 295

PB_alert=(PB(:,1:20));
PB_alert=mean(PB_alert,2)*ones(1,224);
PB_n=PB-PB_alert;

PB_mov=movav(PB_n,[],40,1);
Y_mov = movav(Y', [], 40, 1);