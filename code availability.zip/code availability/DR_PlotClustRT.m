%power RT (single and clustered)
%This version: 200903 by poem

%% set parameters (initialize)
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/RS/';  %directory
  SL = '/';
end
DR_PBase_setup;  %load setup file
%datasets
PLOT_SET = {
            's01_061102';  %motionless
            's05_061101';  %motionless
            's31_061103';  %motionless
            's32_061031';  %motionless
            's35_070322';  %motionless
            's36_061221';  %motionless
%             's37_071213';  %motionless
%             's39_070117';  %motionless
            's40_070207';  %motionless
            's41_061225';  %motionless
            's42_070105';  %motionless
            's43_070208';  %motionless
            's44_070325';  %motionless
            's05_061019';  %motion
            's31_061020';  %motion
            's35_070115';  %motion
            's36_061122';  %motion
%             's39_061218';  %motion
            's40_070131';  %motion
            's43_070202';  %motion
%             's44_070126';  %motion
            's44_070209';  %motion
           };
urRT_s = [];
RT_s = [];
MN = 'motionless';
if strcmp(MN, 'motionless')
  MN_COLOR = '{0 0 1}';
elseif strcmp(MN, 'motion')
  MN_COLOR = '{1 0 0}';
else
  MN_COLOR = '{0 1 0}';
end
FilePathOld = FilePath;
rj = '_rj';
%font size
FONT_SIZE = 12;  %text
TITLE_FSIZE = 14;  %title
STITLE_FSIZE = 12;  %subtitle
AXIS_FSIZE = 12;  %axis
CBAR_FSIZE = 12;  %color bar

%% check if dataset is valid and load RT
session_count = 0;
for i = 1 : size(PLOT_SET, 1)
  Go = true;  %flag, if dataset is invalid => stop process
  FilePath = FilePathOld;
  plot_set = PLOT_SET{i, 1};
  %check if the plot_set is valid
  for j = 1 : size(SET, 1)
    Set = SET{j, 1};
    condition = SET{j, 3};
    if strcmp(Set, plot_set)  %dataset found in database, checking if condition is ok
      oldcls = zeros(1, size(ClsLabel, 1));  %register to memorize if the cluster shown before
      if strcmp(condition, MN)  %condition ok => dataset valid => process
        session_count = session_count + 1;
        Set = PLOT_SET{i};
%         [subj ExpDate] = strtok(Set, '_'); ExpDate = ExpDate(2 : end);
        load(['~/liang/' Set '/' Set '_RT_of_trials']);
        RT_s = [RT_s RT];
        urRT_s = [urRT_s RT_original(:, 1)'];
      else  %codition not ok => invalid
        fprintf('%s: not valid, check set name or condition (motion/motionless).\n', plot_set);
      end
      break;
    end
    if j == size(SET, 1)  %not able to find dataset
      fprintf('%s: not valid, check set name or condition (motion/motionless).\n', plot_set);
    end
  end
end

%% sort RT and find trial with 3-sec RT
RT_s = sort(RT_s);
RT_s_idx = find(RT_s <= 3, 1, 'last');
urRT_s = sort(urRT_s);
urRT_s_idx = find(urRT_s <= 3, 1, 'last');

%% plot
figure; hold on;
set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardCopy', 'off');
plot(RT_s, (1:length(RT_s)) / length(RT_s) * 100, 'Color', str2double(MN_COLOR(2 : end - 1)), 'LineWidth', 1.5);
set(gca, 'XScale', 'log');  %set here to get correct x limits
xlim_tmp = get(gca, 'Xlim'); xlim([xlim_tmp(1) RT_s(end)]);
% plot([RT_s_idx / length(RT_s) * 100 RT_s_idx / length(RT_s) * 100], get(gca, 'Ylim'), ...
%     'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
plot([3 3], [0 100], 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
hold off;
xlabel('Reaction Time (sec)', 'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'VerticalAlignment', 'cap');
ylabel('RT-Sorted Index (%)', 'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'VerticalAlignment', 'baseline');
% legend_handle = legend('Reaction Time', 'Trial with 3-sec RT');
legend_handle = legend('Reaction Time', 'RT =  3 sec');
set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off', 'location', 'NorthWest');
grid on;
set(gca, 'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'Color', BACKGROUND_COLOR, ...
    'XColor', AXIS_COLOR, 'XMinorTick', 'off', 'XMinorGrid', 'off', 'YColor', AXIS_COLOR);
set(gca, 'XTickLabel', 10 .^ str2double(get(gca, 'XTickLabel')));
title({['\color[rgb]' FONT_COLOR 'Sorted Reaction Time of \color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ' Datasets']; ...
    ['\rm\fontsize{' int2str(TITLE_FSIZE - 2) '}(' int2str(length(RT_s)) ' trials from ' int2str(session_count) ' sessions, after noise removal)']}, ...
    'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'Bold');
save([FilePath 'RT_Sorted_Trial_' MN], 'urRT_s', 'RT_s', 'MN', 'session_count');
saveas(gcf, [FilePath 'RT_Sorted_Trial_' MN '.fig']);
close gcf;