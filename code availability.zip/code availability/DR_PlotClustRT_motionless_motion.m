%power RT (single and clustered)
%This version: 200903 by poem

%% set parameters (initialize)
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/RS/';  %directory
  SL = '/';
end
DR_PBase_setup;  %load setup file
%datasets
PLOT_SET = {
            's01_061102';  %motionless
            's05_061101';  %motionless
            's31_061103';  %motionless
            's32_061031';  %motionless
            's35_070322';  %motionless
            's36_061221';  %motionless
%             's37_071213';  %motionless
%             's39_070117';  %motionless
            's40_070207';  %motionless
            's41_061225';  %motionless
            's42_070105';  %motionless
            's43_070208';  %motionless
            's44_070325';  %motionless
            's05_061019';  %motion
            's31_061020';  %motion
            's35_070115';  %motion
            's36_061122';  %motion
%             's39_061218';  %motion
            's40_070131';  %motion
            's43_070202';  %motion
%             's44_070126';  %motion
            's44_070209';  %motion
           };
MN = {'motionless'; 'motion'};
for i = 1 : size(MN, 1)  %deciding color
  mn = MN{i};
  switch mn
    case 'motionless'
      mn_color = '{0 0 1}';  %blue
    case 'motion'
      mn_color = '{1 0 0}';  %red
    otherwise
      mn_color = '{0 1 0}';  %green
  end
  com = sprintf('MN_COLOR%d = mn_color;', i); eval(com);
end
FilePathOld = FilePath;
rj = '_rj';
p_val = 0.0001;  %p-value
%font size
FONT_SIZE = 12;  %text
TITLE_FSIZE = 14;  %title
STITLE_FSIZE = 12;  %subtitle
AXIS_FSIZE = 12;  %axis
CBAR_FSIZE = 12;  %color bar

%% modify database (create new database from the original one)
for i = 1 : size(MN, 1)
  com = sprintf('SET%d = {}; SUBJ%d = {};', i, i); eval(com);
end 
%split datasets to motionless and motion subsets
for i = 1 : size(SET, 1)
  if strcmp(SET{i, 3}, MN{1})
    SET1 = [SET1; SET(i, :)];
    SUBJ1 = [SUBJ1; {strtok(SET{i, 1}, '_')}];
  elseif strcmp(SET{i, 3}, MN{2})
    SET2 = [SET2; SET(i, :)];
    SUBJ2 = [SUBJ2; {strtok(SET{i, 1}, '_')}];
  end
end
%find the subjects who have done motionless and motion sessions (in database)
SUBJ_tmp = intersect(SUBJ1, SUBJ2);
for i = 1 : size(MN, 1)
  com =  sprintf('SET%d = SET%d(ismember(SUBJ%d, SUBJ_tmp), :);', i, i, i); eval(com);
end
clear SET SUBJ_tmp;
%till now, new database = SET1 and SET2

%% check subject list and split it into sub-list according to condition
for i = 1 : size(MN, 1)
  com = sprintf('PLOT_SET%d = {}; SUBJ%d = {};', i, i); eval(com);
end
for i = 1 : size(PLOT_SET, 1)
  %check if the plot_set is valid
  plot_set = PLOT_SET{i};
  check_ok = false;
  for j = 1 : size(MN, 1)  
    if check_ok  %in previous dataset
      break;
    else
      com = sprintf('SET_tmp = SET%d;', j); eval(com);
      for k = 1 : size(SET_tmp, 1)
        Set = SET_tmp{k, 1};
        condition = SET_tmp{k, 3};
        if strcmp(Set, plot_set)  %dataset found in database, assign to correct subset
          check_ok = true;
%           if strcmp(condition, MN{j})  %condition ok => assign to appropriate sub-list
            com = sprintf('PLOT_SET%d = [PLOT_SET%d; SET_tmp(k, 1)];', j, j); eval(com);
            com = sprintf('SUBJ%d = [SUBJ%d; {strtok(Set, ''_'')}];', j, j); eval(com);
%           else  %codition not ok => invalid
%             fprintf('%s: not valid, check set name or condition (should be motion/motionless).\n', plot_set);
%           end
          break;
        end
        if k == size(SET_tmp, 1) && j == size(MN, 1)  %not able to find dataset
          fprintf('%s: not valid. Subject Not finishing all experiments or error set name/condition.\n', plot_set);
        end
      end                                                                                                                                                                                                    
    end
  end
end
SUBJ_tmp = intersect(SUBJ1, SUBJ2);
for i = 1 : size(MN, 1)
  com =  sprintf('PLOT_SET%d = PLOT_SET%d(ismember(SUBJ%d, SUBJ_tmp), :);', i, i, i); eval(com);
  com =  sprintf('RT_s%d = [];', i); eval(com);
  com =  sprintf('urRT_s%d = [];', i); eval(com);
end
clear PLOT_SET SUBJ_tmp;

%% load and sort RT
figure; hold on;
set(gca, 'XScale', 'log');  %set here to get correct x limits
set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardCopy', 'off');
legend_string = 'legend_handle = legend(';  %for legend
norm_distr = zeros(1, size(MN, 1));  %store if each dataset is with normal distr.
%for deciding xlim
max_RT = -Inf; min_RT = Inf;
urmax_RT = -Inf; urmin_RT = Inf;
for i = 1 : size(MN, 1)
  com = sprintf('SET_tmp = PLOT_SET%d;', i); eval(com);
  com = sprintf('RT_s_tmp = RT_s%d;', i); eval(com);
  com = sprintf('urRT_s_tmp = urRT_s%d;', i); eval(com);
  com = sprintf('MN_COLOR_tmp = MN_COLOR%d;', i); eval(com);
  for j = 1 : size(SET_tmp, 1)
    Set = SET_tmp{j};
    load(['~/liang/' Set '/' Set '_RT_of_trials']);
    RT_s_tmp = [RT_s_tmp RT];
    urRT_s_tmp = [urRT_s_tmp RT_original(:, 1)'];
  end
  RT_s_tmp = sort(RT_s_tmp);
  if min_RT > RT_s_tmp(1)
    min_RT = RT_s_tmp(1);
  end
  if max_RT < RT_s_tmp(end)
    max_RT = RT_s_tmp(end);
  end
  if urmin_RT > urRT_s_tmp(1)
    urmin_RT = urRT_s_tmp(1);
  end
  if urmax_RT < urRT_s_tmp(end)
    urmax_RT = urRT_s_tmp(end);
  end
  norm_distr(i) = kstest(RT_s_tmp);  %check if with normal distribution. Normal: norm_distr_tmp = 1
  RT_s_idx_tmp = find(RT_s_tmp <= 3, 1, 'last');
  urRT_s_tmp = sort(urRT_s_tmp);
  urRT_s_idx_tmp = find(urRT_s_tmp <= 3, 1, 'last');
  com = sprintf('RT_s%d = RT_s_tmp;', i); eval(com);
  com = sprintf('RT_s_idx%d = RT_s_idx_tmp;', i); eval(com);
  com = sprintf('urRT_s%d = urRT_s_tmp;', i); eval(com);
  com = sprintf('urRT_s_idx%d = urRT_s_idx_tmp;', i); eval(com);
  legend_string = [legend_string '''' MN{i} ''', '];  %legend
  
%% plot
  plot(RT_s_tmp, (1:length(RT_s_tmp)) / length(RT_s_tmp) * 100, 'Color', str2double(MN_COLOR_tmp(2 : end - 1)), 'LineWidth', 1.5);
end
plot([3 3], get(gca, 'Ylim'), 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);  %plot RT = 3-sec (vertical)
xlabel('Reaction Time (sec)', 'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'VerticalAlignment', 'cap');
ylabel('RT-Sorted Index (%)', 'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'VerticalAlignment', 'baseline');
legend_string = [legend_string '''RT = 3 sec'');'];
eval(legend_string)
set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off', 'location', 'NorthWest');
hold on;
grid on;
set(gca, 'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'Color', BACKGROUND_COLOR, ...
    'XColor', AXIS_COLOR, 'YMinorTick', 'off', 'YMinorGrid', 'off', 'YColor', AXIS_COLOR);
xlim([min_RT max_RT]);
set(gca, 'XTickLabel', 10 .^ str2num(get(gca, 'XTickLabel'))');
%title
title_text = {['\color[rgb]' FONT_COLOR 'Sorted Reaction Time']};
for i = 1 : size(MN, 1)
  com = sprintf('MN_tmp = MN{%d};', i); eval(com);
  com = sprintf('MN_COLOR = MN_COLOR%d;', i); eval(com);
  com = sprintf('RT_s = RT_s%d;', i); eval(com);
  com = sprintf('SET_tmp = PLOT_SET%d;', i); eval(com);
  if i == 1
    title_text_tmp = ['\rm\fontsize{' int2str(FONT_SIZE) '}('];
  else
    title_text_tmp = '';
  end
  title_text_tmp = [title_text_tmp '\color[rgb]' MN_COLOR upper(MN_tmp) ...
      '\color[rgb]' FONT_COLOR ': ' int2str(length(RT_s)) ' trials from ' int2str(size(SET_tmp, 1)) ' sessions'];
  title_text(i + 1) = {title_text_tmp};
end
if (size(MN, 1) == 2)
  title_text(2) = {[title_text{2} '; ' title_text{3} ')']};
  title_text(3) = [];
end
title(title_text, 'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'Bold');

%T-test to see if with significant differences
combos = combntns(1 : size(MN, 1), 2); 
stat_diff.h = zeros(size(MN, 1));  %1: with significantly difference (t-test); -1: with significantly difference (K-S test)
stat_diff.p = zeros(size(MN, 1));  %p value
for i = 1 : size(combos, 1)
  for j = 1 : size(combos, 2)
    com = sprintf('types%d = combos(i, %d);', j, j); eval(com);
    com = sprintf('RT_s_tmp%d = RT_s%d;', j, j); eval(com);
  end
  if norm_distr(types1) + norm_distr(types2) == 2  %both with normal distri.  => do t-test
    [stat_diff.h(types1, types2) stat_diff.p(types1, types2)] = ttest2(RT_s_tmp1, RT_s_tmp2, p_val / 2, 'both');
    stat_diff.h(types2, types1) = stat_diff.h(types1, types2);
    stat_diff.p(types2, types1) = stat_diff.p(types1, types2);
  elseif norm_distr(types1) + norm_distr(types2) == 1  %only one with normal distri.  => do K-S test
    [stat_diff.h(types1, types2) stat_diff.p(types1, types2)] = kstest2(RT_s_tmp1, RT_s_tmp2, p_val);
    stat_diff.h(types1, types2) = -stat_diff.h(types1, types2);
    stat_diff.h(types2, types1) = stat_diff.h(types1, types2);
    stat_diff.p(types2, types1) = stat_diff.p(types1, types2);
  else  %unknown
    [stat_diff.h(types1, types2) stat_diff.p(types1, types2)] = NaN;
    stat_diff.h(types2, types1) = stat_diff.h(types1, types2);
    stat_diff.p(types2, types1) = stat_diff.p(types1, types2);
  end
end

save([FilePath 'RT_Sorted_Trial_motionless+motion.mat'], ...
    'PLOT_SET1', 'PLOT_SET2', 'urRT_s1', 'urRT_s2', 'RT_s1', 'RT_s2', 'MN', 'p_val', 'norm_distr', 'stat_diff');
saveas(gcf, [FilePath 'RT_Sorted_Trial_motionless+motion.fig']);
close gcf;