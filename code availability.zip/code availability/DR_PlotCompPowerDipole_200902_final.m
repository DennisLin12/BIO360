%component maps, dipoles and power spectra in a cluster
%ver 2009/02

%% set parameters (initialize)
try
  close(4001);
end
try
  close(4002);
end
try
  close(4003);
end
try
  close(4004);
end
try
  close(4009);
end
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/';  %directory
  SL = '/';
end
DR_PBase_setup;  %load setup file
%datasets
PLOT_SET = {
            's31_061103';  %motionless
            's32_061031';  %motionless
            's35_070322';  %motionless
            's36_061221';  %motionless
%             's37_071213';  %motionless
%             's39_070117';  %motionless
            's40_070207';  %motionless
            's41_061225';  %motionless
            's42_070105';  %motionless
            's43_070208';  %motionless
            's44_070325';  %motionless
            's31_061020';  %motion
            's35_070115';  %motion
            's36_061122';  %motion
%             's39_061218';  %motion
            's40_070131';  %motion
            's43_070202';  %motion
            's44_070126';  %motion
           };
MN = 'motion';
FilePathOld = FilePath;
rj = '_rj';
n_of_cls = size(ClsLabel, 1);  %# of cluster
undef_cls = n_of_cls + 1;
%for component map
std_chanlocs = '~/30ch.xyz';  %standard channel location file
%axes limites for plotting power spectra
% power_xlim = [0 50];
power_xlim = [3 45];
% power_ylim = [-30 10];
power_ylim = [0 30];
avg = '_trim';  %method for averaging
%dipole
view_angle = [45 30];  %view angles
view_angle_single = [40 20];
HeadFilePath = '/home/eeglab5.03/eeglab5.03/plugins/dipfit2.0/standard_BESA/';  %.4, using BESA
hdmfile = [HeadFilePath 'standard_BESA.mat'];  %head model
mrifile = '/home/eeglab5.03/eeglab5.03/plugins/dipfit2.0/standard_BEM/standard_mri.mat';  %MRI file, using MNI in paper
chanfile = [HeadFilePath 'standard-10-5-cap385.elp'];  %electrodes
dip_option = {%for plotting dipole. see help -> pop_dipplot / dipplot for details
              '''axistight'', ' '''off'', ', ...  %for MRI only, display the closest MRI slide
              '''drawedges'', ' '''off'', ', ...  %draw edges of the 3-D MRI (black in axistight, white otherwise.)
              '''mesh'', '      '''off'', ', ...  %display spherical mesh
              '''gui'', '       '''off'', ', ...  %display controls. if gui 'off', a new figure is not created.
              '''summary'', '   '''off'', ', ...  %build a summary plot with three views (top, back, side)
              '''verbose'', '   '''off'', ', ...  %comment on operations on command line
              '''normlen'', '   '''on'', ' , ...  %normalize length of all dipoles
              '''num'', '       '''off'', ', ...  %display component number
              '''cornermri'', ' '''off'', ', ...  %force MRI images to the corner of the MRI volume (useful when background is not black)
              '''projimg'', '   '''on'', ' , ...  %project dipole(s) onto the 2-D images, for use in making 3-D plots
              '''projlines'', ' '''on'', ' , ...  %plot lines connecting dipole with 2-D projection
              '''pointout'', '  '''off'', ', ...  %point the dipoles outward
              '''spheres'', '   '''off'''    ...  %plot dipole markers as 3-D spheres
             };
dip_color = {%for single dipole map
             [0 0 1];
             [0 1 0];
             [0 1 1];
             [1 0 0];
             [1 0 1];
             [1 1 0];
             [0 0 .66];
             [0 .66 0];
             [0 .66 .66];
             [.66 0 0];
             [.66 0 .66];
             [.66 .66 0];
             [0 0 .33];
             [0 .33 0];
             [0 .33 .33];
             [.33 0 0];
             [.33 0 .33];
             [.33 .33 0];
            };
dip_option = cell2mat(dip_option);

%% assign component to cluster
for i = 1 :size(ClsLabel, 1)
  com = sprintf('IC%02d = {ClsLabel{%d}};', i, i); eval(com);
end
for i = 1 : size(PLOT_SET, 1)
  FilePath = FilePathOld;
  plot_set = PLOT_SET{i, 1};
  %check if the plot_set is valid
  for j = 1 : size(SET, 1)
    Set = SET{j, 1};
    condition = SET{j, 3};
    if strcmp(Set, plot_set)  %dataset found in database, checking if condition is ok
%       oldcls = zeros(1, size(ClsLabel, 1));  %register to memorize if the cluster shown before
      if strcmp(condition, MN)  %condition ok => dataset valid => process
        COMP = SET{j, 2};
        EEG = pop_loadset([FilePath Set SL Set '_dev_on' rj '.set']);
        stmp = EEG;
%         stmp.chanlocs = EEG.chanlocs;
%         if i == 1  %load standard channel location
        if ~isstruct(std_chanlocs)  %load standard channel location
          EEG.chanlocs = pop_chanedit(EEG.chanlocs, 'load', {std_chanlocs, 'filetype', 'xyz eeglab'}, ...
              'eval', 'chantmp = pop_chancenter(chantmp, [], []);');
          std_chanlocs = EEG.chanlocs;
        end
%         stmp.times = EEG.times;
%         stmp.srate = EEG.srate;
%         stmp.icaact = EEG.icaact;
%         stmp.icachansind = EEG.icachansind;
%         stmp.icasphere = EEG.icasphere;
%         stmp.icaweights = EEG.icaweights;
%         stmp.icawinv = EEG.icawinv;
%         if ~isfield(EEG, 'dipfit') || isempty(EEG.dipfit)
%           %register channel
%           EEG = pop_dipfit_settings(EEG, 'hdmfile', hdmfile, 'coordformat', 'Spherical', 'mrifile', mrifile, 'chanfile', chanfile, 'chansel', allcomp);
%           %fit the headshape (coarse fit)
%           EEG = pop_dipfit_gridsearch(EEG, allcomp, -85 : 5 : 85, -85 : 5 : 85, 0 : 5 : 85, 0.4);
%           %save the fitted dataset
% %           EEG = pop_saveset(EEG, [FilePath Set SL Set '_intrial' rj '.set']);
%         end
%         stmp.dipfit = EEG.dipfit;
        com = sprintf('%s = stmp;', Set); eval(com);
        clear EEG stmp;
        for k = 1 : size(COMP, 2)
          comp = COMP(1, k);  %componet #
          comp_cls = COMP(2, k);  %#which cluster
          if comp_cls > 0
            IC_tmp = {Set, comp};
            com = sprintf('IC%02d = [IC%02d IC_tmp];', comp_cls, comp_cls); eval(com);
          end
        end
      else  %codition not ok => invalid
        fprintf('%s: not valid, check set name or condition (motion/motionless).\n', plot_set);
      end
      break;
    end
    if j == size(SET, 1)  %not able to find dataset
      fprintf('%s: not valid, check set name or condition (motion/motionless).\n', plot_set);
    end
  end
end

DR_PlotClustComp_func;  %cluster component
% keyboard;
for i = 5%1 : size(ClsLabel, 1)
  eval(['IC_tmp = IC' num2str(i, '%02d') ';']);
  cls_length = (size(IC_tmp, 2) - 1) / 2;
  subplt_width = ceil(sqrt(cls_length + 1));
  subplt_height = floor(sqrt(cls_length + 1));
  if cls_length + 1 > subplt_width * subplt_height
    subplt_height = subplt_height + 1;
  end
  subplt_x = floor(10000 / subplt_width) / 10000;  %floor(10000 / 3) / 10000 = .3333
  subplt_y = floor(10000 / subplt_height) / 10000;  %floor(10000 / 6) / 10000 = .1666 < roundn(1/6, -4) = .1667
  blank_x = (1 - subplt_x * subplt_width) / 2;
  blank_y = (1 - subplt_y * subplt_height) / 2;
  spec_all = [];  %array for storing spectra
  dipole_all = {};  %cell for storing dipole
  for j = 1 : cls_length
    subplt_pos = [blank_x + subplt_x * mod((j - 1), subplt_width) + subplt_x * 0.1, ...
                  blank_y + subplt_y * (subplt_height - ceil(j / subplt_width)) + subplt_y * 0.1];
    plot_set = IC_tmp{1, 2 * j};
    plot_comp = IC_tmp{1, 2 * j + 1};
    com = sprintf('EEG = %s;', plot_set); eval(com);
    [subj ExpDate] = strtok(plot_set, '_'); ExpDate = ExpDate(2 : end);

    %tackling power spectra
%     t0 = find(EEG.times == 0);  %before t0: baseline
%     [spectra, trim_spectra, med_spectra, freqs, speccomp, contrib, specstd, specarr] = ...
%         DR_spectopo(EEG.icaact(plot_comp, 1 : t0, :), t0, EEG.srate, 'mapnorm', EEG.icawinv(:, plot_comp), 'plot', 'off');
%     idx = find(freqs <= 50);
%     freqs = freqs(idx);
%     if strcmp(avg, '_trim')
%       PowerSpec = trim_spectra;  %trim mean
%     elseif strcmp(avg, '_med')
%       PowerSpec = med_spectra;  %median
%     else
%       PowerSpec = spectra;  %mean
%     end
%     spec_all = [spec_all; PowerSpec(idx)];
    try
    load([FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d') SL ...
        plot_set '_PBaseRT_' num2str(plot_comp, '%02d') rj], 'PB_alert_mean', 'freqs');
    catch
    load([FilePath 'RS' SL MN SL 'IC00' SL ...
        plot_set '_PBaseRT_' num2str(plot_comp, '%02d') rj], 'PB_alert_mean', 'freqs');
    end
    PB_alert_mean = PB_alert_mean(:, 1)';  %PB_alert_mean: padded
    spec_all = [spec_all; PB_alert_mean];

    %plot dipole
    %plot dipole in brighter color
    figure(4001);
    dh(j) = subplot('position', [subplt_pos subplt_x * .8 subplt_y * .75]);% axis tight;
%     subplot(subplt_height, subplt_width, j);
%     eval([ ...
%         'pop_dipplot(EEG, plot_comp, ''mri'', mrifile, ''view'', view_angle, ''color'', {[1 1 0]}, ''dipolesize'', 20, ''dipolelength'', 0, ' dip_option ');']);
    eval(['dip_tmp = dipplot(EEG.dipfit.model(plot_comp), ''mri'', mrifile, ''view'', view_angle, ''color'', {[1 1 0]}, ' ...
        '''dipolesize'', 20, ''dipolelength'', 0, ' [dip_option ', ''coordformat'', ''spherical'''] ');']);
    th(j) = subplot('position', [subplt_pos(1) subplt_pos(2) + subplt_y * .75 subplt_x * .8 subplt_y * .15]); axis off;
    text(0.05, .5, ['\color[rgb]{0 0 0}' subj '-' num2str(plot_comp, '%02d')], 'FontName', FONT_FACE, 'FontSize', 8, ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'baseline');
    if ~isfield(EEG.dipfit.model(plot_comp), 'eleccoord') || ~isfield(EEG.dipfit.model(plot_comp), 'talcoord') || ...
            ~isfield(EEG.dipfit.model(plot_comp), 'mnicoord')  %not exist in the original dataset, update the original
      EEG.dipfit.model(plot_comp).eleccoord = dip_tmp.eleccoord;
      EEG.dipfit.model(plot_comp).mnicoord = dip_tmp.mnicoord;
      EEG.dipfit.model(plot_comp).talcoord = dip_tmp.talcoord;
      EEG = pop_saveset(EEG, [FilePath plot_set SL plot_set EpochType{1} rj '.set']);
    end
    %for cluster data, summary
    dipole_all = [dipole_all dip_tmp];
  end

  for j = 1 : cls_length
    plot_set = IC_tmp{1, 2 * j};
    plot_comp = IC_tmp{1, 2 * j + 1};
    com = sprintf('EEG = %s;', plot_set); eval(com);
    [subj ExpDate] = strtok(plot_set, '_'); ExpDate = ExpDate(2 : end);
    subplt_pos = [blank_x + subplt_x * mod((j - 1), subplt_width) + subplt_x * 0.1, ...
                  blank_y + subplt_y * (subplt_height - ceil(j / subplt_width)) + subplt_y * 0.1];

    %plot power spectra
    figure(4009);
    sh(j) = subplot('position', [subplt_pos(1) + subplt_x * .1 subplt_pos(2) + subplt_y * .1 ...
        subplt_x * .75 subplt_y * .75]);
%     subplot(subplt_height, subplt_width, j);
    hold on;
    plot(freqs, spec_all', 'LineStyle', '-', 'Color', [.75 .75 .75]);  %every spectrum
    plot(freqs, spec_all(j, :), '-k', 'LineWidth', 1.5);  %one spectrum
    plot(freqs, trimmean(spec_all, 10, 1), '-r', 'LineWidth', 1.5);  %avg spectrum
    if j == 1
      text(power_xlim(2), power_ylim(2), {[subj '\_' ExpDate '-' num2str(plot_comp, '%02d')]; '\color{red}Avg. Spectra'}, ...
          'FontName', FONT_FACE, 'FontSize', 8, 'HorizontalAlignment', 'right', 'VerticalAlignment', 'cap');
    else
      text(power_xlim(2), power_ylim(2), [subj '\_' ExpDate '-' num2str(plot_comp, '%02d')], ...
          'FontName', FONT_FACE, 'FontSize', 8, 'HorizontalAlignment', 'right', 'VerticalAlignment', 'cap');
    end
    hold off;
    xlim(power_xlim);
    ylim(power_ylim);
    set(gca, 'Box', 'off', 'FontName', FONT_FACE, 'Color', BACKGROUND_COLOR);
    if cls_length - j >= subplt_width
      set(gca, 'XTick', []);
    else
%       set(gca, 'XTick', 0 : 12.5 : 50, 'XTickLabel', {'0', '', '25', '', '50'}, 'FontName', FONT_FACE, 'FontSize', 8);
%       set(gca, 'XTick', 0 : 10 : 50, 'FontName', FONT_FACE, 'FontSize', 8);
      set(gca, 'XTick', 10 : 10 : power_xlim(2), 'FontName', FONT_FACE, 'FontSize', 8);
      xlabel('Frequency (Hz)', 'FontName', FONT_FACE, 'FontSize', 8, 'VerticalAlignment', 'cap');
    end
    if mod(j, subplt_width) ~= 1
      set(gca, 'YTick', []);
    else
%       set(gca, 'YTick', -30 : 10 : 10, 'FontName', FONT_FACE, 'FontSize', 8);
      set(gca, 'YTick', power_ylim(1) : 10 : power_ylim(2), 'FontName', FONT_FACE, 'FontSize', 8);
      ylabel('Power (dB)', 'FontName', FONT_FACE, 'FontSize', 8, 'VerticalAlignment', 'baseline');
    end

    %plot dipole (cont.)
    %plot dipole in darker color
    figure(4002);
%     eval([...
%           'pop_dipplot(EEG, plot_comp, ''mri'', mrifile, ''view'', view_angle, ''color'', {[0 1 1]}, ''dipolesize'', 5, ''dipolelength'', 0, ' dip_option ');']);
    eval(['dipplot(EEG.dipfit.model(plot_comp), ''mri'', mrifile, ''view'', view_angle, ''color'', {[0 1 1]}, ' ...
        '''dipolesize'', 5, ''dipolelength'', 0, ' [dip_option ', ''coordformat'', ''spherical'''] ');']);
    h1 = findobj(gcf, 'Type', 'line');
    figure(4001);  %copy into main window
    for k = 1 : cls_length
      if j ~= k
        copyobj(h1, dh(k));
      end
    end
    close(4002);

    %plot dipole into one figure
    figure(4003);
    subplot('position', [0.84 0 .16 1]); axis off;
    if j == 1
      text(0, .9, {'\color[rgb]{0 0 0}Dipole of '; ...
          ['\color[rgb]{1 0 0}\bf\fontsize{11}' ClsLabel{i} '\color[rgb]{0 0 0}\rm\fontsize{10}']; 'Cluster'}, ...
          'FontName', FONT_FACE, 'FontSize', 10, 'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Middle');
    end
    dip_color_tmp = mat2str(dip_color{mod(j, size(dip_color, 1)) + 1});
    text(0, .85 - j * .025, ['\color[rgb]{' dip_color_tmp(2 : end - 1) '}' '\bullet\color[rgb]{0 0 0} ' subj '\_' ExpDate '-' num2str(plot_comp, '%02d')], ...
        'FontName', FONT_FACE, 'FontSize', 10, 'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Middle');
    subplot('position', [0 0.1 .8 .8]);
    target = gca;
    if j ~= 1
      figure(4004);
      subplot('position', [0 0.1 .8 .8]);
    end
%     eval([ ...
%           'pop_dipplot(EEG, plot_comp, ''mri'', mrifile, ''view'', view_angle_single, ''color'', {' ...
%           mat2str(dip_color{mod(j, size(dip_color, 1)) + 1}) '}, ''dipolesize'', 30, ''dipolelength'', 0, ' dip_option ');']);
    eval(['dipplot(EEG.dipfit.model(plot_comp), ''mri'', mrifile, ''view'', view_angle_single, ''color'', {' ...
        dip_color_tmp '}, ''dipolesize'', 30, ''dipolelength'', 0, ' [dip_option ', ''coordformat'', ''spherical'''] ');']);
    if (j == 1)
      h2 = findobj(gcf, 'Type', 'surface');
      copyobj(h2, target);
    end
    h2 = findobj(gcf,'Type','line');
    copyobj(h2, target);
    if (j ~= 1)
      close(4004);
    end
  end

  %set background
  for k = [4001 4003 4009]
    set(k, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');
  end

  %title of the whole figure
  for k = [4009 4001]
    figure(k);
    subplt_pos = [blank_x + subplt_x * mod(j , subplt_width)  + subplt_x * 0.1, ...
                  blank_y + subplt_y * (subplt_height - ceil((j + 1) / subplt_width)) + subplt_y * 0.1];
    th(j + 1) = subplot('position', [subplt_pos(1) + subplt_x * .1 subplt_pos(2) + subplt_y * .1 ...
        subplt_x * .75 subplt_y * .75]);
    axis off;
    if k == 4009
      text(0.5, 0.5, ...
          {'\color[rgb]{0 0 0}Baseline Power Spectra of \color[rgb]{1 0 0}'; ...
          [ClsLabel{i} '\color[rgb]{0 0 0} Cluster']}, 'FontName', FONT_FACE, 'FontWeight', 'bold',...
          'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle');
    else
      if i ~= 9 && i ~= 10
        text(0.5, 0.5, ...
            ['\color[rgb]{0 0 0}Dipole of \color[rgb]{1 0 0}' ClsLabel{i} '\color[rgb]{0 0 0} Cluster'], ...
            'FontName', FONT_FACE, 'FontWeight', 'bold', 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle');
      else
        text(0.5, 0.5, ...
            {'\color[rgb]{0 0 0}Dipole of \color[rgb]{1 0 0}'; ...
            [ClsLabel{i} '\color[rgb]{0 0 0} Cluster']}, 'FontName', FONT_FACE, 'FontWeight', 'bold',...
            'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle');
      end
    end
  end

  %save necessary variables
  save([FilePath 'RS' SL MN SL 'IC', num2str(i, '%02d'), '_component_' cls_ver '_' MN], 'spec_all', 'freqs', 'dipole_all', '-append');
%   save([FilePath 'RS' SL MN SL 'IC', num2str(i, '%02d'), '_component_' cls_ver '_' MN], 'spec_all', 'freqs', '-append');
  %save figure
  %power spectra
  figure(4009);
  saveas(gcf, [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_Cluster_Spectra_' cls_ver '_' MN '.fig'], 'fig');
  print('-dpng', [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_Cluster_Spectra_' cls_ver '_' MN '.png']);
  close(4009);

%   %dipole
  figure(4001);
  saveas(gcf, [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_DipoleMap_' cls_ver '_' MN], 'fig');
  print('-djpeg', [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_DipoleMap_' cls_ver '_' MN '.jpeg']);
  close(4001);

%   %dipole (single plot)
  figure(4003);
  saveas(gcf, [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_DipoleMap_' cls_ver '_single_' MN ], 'fig');
  print('-dpng', [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_DipoleMap_' cls_ver '_single_' MN '.png']);
  close(4003);
end