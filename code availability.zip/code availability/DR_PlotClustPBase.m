%power spectra cross subjects
%mostly base on RS_powbase
%This version: 200903 by poem

%% set parameters (initialize)
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/RS/';  %directory
  SL = '/';
end
DR_PBase_setup;  %load setup file
%datasets
PLOT_SET = {
            's01_061102';  %motionless
            's05_061101';  %motionless
            's31_061103';  %motionless
            's32_061031';  %motionless
            's35_070322';  %motionless
            's36_061221';  %motionless
%             's37_071213';  %motionless
%             's39_070117';  %motionless
            's40_070207';  %motionless
            's41_061225';  %motionless
            's42_070105';  %motionless
            's43_070208';  %motionless
            's44_070325';  %motionless
            's05_061019';  %motion
            's31_061020';  %motion
            's35_070115';  %motion
            's36_061122';  %motion
%             's39_061218';  %motion
            's40_070131';  %motion
            's43_070202';  %motion
%             's44_070126';  %motion
            's44_070209';  %motion
           };
MN = 'motionless';
p_val = 1E-10;
if strcmpi(MN, 'motionless')
  MN_COLOR = '{0 0 1}';
elseif strcmpi(MN, 'motion')
  MN_COLOR = '{1 0 0}';
else
  MN_COLOR = '{0 1 0}';
end
movstep = 1;  %stepping for moving avg
xstep_int = 5;
FilePathOld = FilePath;
epoch_type = '';  %'' => baseline, all => all epoch, dev_on => after dev_on
% FilePathOld = [FilePath 'dev_on' SL];
try
  close(1079);
end
% try
%   close(1080);
% end
rj = '_rj';
SD = '';  %'' => not plotting SD on power traces; '_SD': plotting  ***no use (figure too small)
noband = '';  %1: alpha + theta
ylim_tmp = [-2 7];
nor = 1;
switch noband
  case '1'
    FREQ_BAND(3, :) = [];
end

%% assign component to cluster
for i = 1 :size(ClsLabel, 1)
   com = sprintf('IC%02d = {ClsLabel{%d}};', i, i); eval(com);
   com = sprintf('subj_seq%02d = {};', i); eval(com);  %# of sessions in a cluster
   com = sprintf('session_count%02d = 0;', i); eval(com);
end
for i = 1 : size(PLOT_SET, 1)
  plot_set = PLOT_SET{i, 1};
  %check if the plot_set is valid
  for j = 1 : size(SET, 1)
    Set = SET{j, 1};
    condition = SET{j, 3};
    if strcmp(Set, plot_set)  %dataset found in database, checking if condition is ok
      oldcls = zeros(1, size(ClsLabel, 1));  %register to memorize if the cluster shown before
      if strcmp(condition, MN)  %condition ok => dataset valid => process
        COMP = SET{j, 2};
        for k = 1 : size(COMP, 2)
          comp = COMP(1, k);  %componet #
          comp_cls = COMP(2, k);  %which cluster
          if comp_cls > 0
            IC_tmp = {Set, comp};
            com = sprintf('IC%02d = [IC%02d IC_tmp];', comp_cls, comp_cls); eval(com);
            if ~oldcls(comp_cls)  %first appearing
              oldcls(comp_cls) = true;
              com = sprintf('session_count%02d = session_count%02d + 1;', comp_cls, comp_cls); eval(com);
            end
          end
        end
      else  %codition not ok => invalid
        fprintf('%s: not valid, check set name or condition (motion/motionless).\n', plot_set);
      end
      break;
    end
    if j == size(SET, 1)  %not able to find dataset
      fprintf('%s: not valid, check set name or condition (motion/motionless).\n', plot_set);
    end
  end
end

%% process data
for i = 1 : size(ClsLabel, 1)
  FilePath = FilePathOld;
  com = sprintf('IC_tmp = IC%02d;', i); eval(com);  %IC_tmp: sorted by subject list given above
  com = sprintf('session_count = session_count%02d;', i); eval(com);
  subj_seq = {};
  session_id = 0;  %the same dataset => session id NOT the same across clusters
  old_set = '';
  %load icawinv for plotting component maps
  tmp_comps = ...
      load([FilePath MN SL 'IC' num2str(i, '%02d') '_component_' cls_ver '_' MN], 'avg_icawinv', 'std_chanlocs', 'dipole_all');  %tmp_comps.PB_mean: row: freq, col: trial  
  icawinv = tmp_comps.avg_icawinv;
  chanlocs = tmp_comps.std_chanlocs;
  dipole_all = tmp_comps.dipole_all;
  clear tmp_comps;
  FilePath = [FilePath epoch_type SL MN SL 'IC' num2str(i, '%02d') SL];
  cls_length = (size(IC_tmp, 2) - 1) / 2;
  if cls_length > 0
    allAlpha = [];
    allTheta = [];
    allRT_s = [];
    RT_s = [];
    PB_mean = [];
    PB_alert_subj = [];  %baseline power for alert trials of each subject. only for the first normalize method
    if nor == 3 || nor == 4
      PB_alert = 0;
    else
      PB_alert = [];
    end
    PB_n = [];
    for j = 1 : cls_length
      plot_set = IC_tmp{1, 2 * j};
      plot_comp = IC_tmp{1, 2 * j + 1};
      tmp_cell = {};  %for storing session
      tmp_arr = [];  %for storing session ID (easy to access when calculating);
      %counting session id
      if ~strcmp(old_set, plot_set)  %new dataset
        session_id = session_id + 1;
      end
      %load dataset
      if ~isempty(epoch_type)
        tmp_set = load([FilePath plot_set '_PBaseRT_' num2str(plot_comp, '%02d') rj '_' epoch_type], ...
            'RT_s', 'PB_mean', 'PB_alert_mean', 'PB_n', 'freqs');  %tmp_set.PB_mean: row: freq, col: trial
      else
        tmp_set = load([FilePath plot_set '_PBaseRT_' num2str(plot_comp, '%02d') rj], ...
            'RT_s', 'PB_mean', 'PB_alert_mean', 'PB_n', 'freqs');  %tmp_set.PB_mean: row: freq, col: trial
      end
      RT_s = [RT_s tmp_set.RT_s];
      PB_mean = [PB_mean tmp_set.PB_mean];
      freqs = tmp_set.freqs;
      %recording session according to trials (length of PB_mean or RT_s)
      tmp_cell(1 : size(tmp_set.PB_mean, 2)) = {plot_set};
      tmp_arr(1 : size(tmp_set.PB_mean, 2)) = session_id;
      tmp_arr_cell = mat2cell(tmp_arr, ones(1, size(tmp_arr, 1)), ones(1, size(tmp_arr, 2)));
      subj_seq = [subj_seq [tmp_cell; tmp_arr_cell]];
      switch nor
        case 1
%           alert.trials = ceil(size(tmp_set.PB_mean, 2) * alert.rate);  %find baseline
%           PB_alert_tmp = tmp_set.PB_mean(:, 1 : alert.trials);  %calculating power of alert trials
%           PB_alert_tmp = mean(PB_alert_tmp, 2) * ones(1, length(tmp_set.RT_s));  %padding
%           PB_n_tmp = tmp_set.PB_mean - PB_alert_tmp;  %normalized by power in alert stage
          PB_alert = [PB_alert tmp_set.PB_alert_mean];
          PB_n = [PB_n tmp_set.PB_n];
          if j == cls_length  %finish loading dataset, calculate baseline
            [RT_s ur_idx] = sort(RT_s, 2);  %sort by RT
            PB_mean = PB_mean(:, ur_idx);
%             PB_alert = PB_alert(:, ur_idx);
            PB_n = PB_n(:, ur_idx);
            PB_alert = PB_alert(:, ur_idx);
            subj_seq = subj_seq(:, ur_idx);
            subj_seq_id = cell2mat(subj_seq(2, :));
          end
          if ~strcmp(old_set, plot_set)
            PB_alert_subj = [PB_alert_subj tmp_set.PB_alert_mean(:, 1)];
          end
        case 2
          if j == cls_length  %finish loading dataset, calculate baseline
            [RT_s ur_idx] = sort(RT_s, 2);  %sort by RT
            PB_mean = PB_mean(:, ur_idx);
%             PB_mean = sortrows(PB_mean', size(PB_mean, 1))';  %sort by RT
%             RT_s = PB_mean(end, :);
%             PB_mean(end, :) = [];
            alert.trials = ceil(size(PB_mean, 2) * alert.rate);  %find baseline
            PB_alert = PB_mean(:, 1 : alert.trials);  %calculating power of alert trials
            PB_alert_mean = trimmean(PB_alert, 10, 2) * ones(1, length(RT_s));  %padding
            PB_n = PB_mean - PB_alert_mean;  %normalized by power in alert stage
          end
        case {3, 4}
%           alert.trials = ceil(size(tmp_set.PB_mean, 2) * alert.rate);  %find baseline
%           PB_alert_tmp = tmp_set.PB_mean(:, 1 : alert.trials);  %calculating power of alert trials
          if nor == 4
%             PB_alert = PB_alert + length(tmp_set.RT_s) * trimmean(PB_alert_tmp, 10, 2);  %weighted sum
            PB_alert = PB_alert + length(tmp_set.RT_s) * (tmp_set.PB_alert_mean(:, 1));  %weighted sum
          else
%             PB_alert = PB_alert + trimmean(PB_alert_tmp, 10, 2);  %direct sum
            PB_alert = PB_alert + (tmp_set.PB_alert_mean(:, 1));  %direct sum
          end
          if j == cls_length  %finish loading dataset, calculate baseline
            [RT_s ur_idx] = sort(RT_s, 2);  %sort by RT
            PB_mean = PB_mean(:, ur_idx);
            if nor == 4
              PB_alert_mean = PB_alert / length(RT_s) * ones(1, length(RT_s));
            else
              PB_alert_mean = PB_alert / cls_length * ones(1, length(RT_s));  %averaging baseline and padding
            end
            PB_n = PB_mean - PB_alert_mean;
          end
      end
      old_set = plot_set;
    end
    alert.trials = ceil(size(RT_s, 2) * alert.rate);

    %moving average
    PB_mov = [];
    RT_s_mov = [];
    for j = 1 : movstep : size(PB_n, 2) - (alert.trials - 1)
%       PB_mov = [PB_mov mean(PB_n(:, j : j + alert.trials - 1), 2)];
%       RT_s_mov = [RT_s_mov mean(RT_s(:, j : j + alert.trials - 1), 2)];
      PB_mov = [PB_mov trimmean(PB_n(:, j : j + alert.trials - 1), 10, 2)];
      RT_s_mov = [RT_s_mov trimmean(RT_s(:, j : j + alert.trials - 1), 10, 2)];
    end  %j
    %compute power over different freq bands
    FREQ_INC = {};
    %columns of FREQ_INC:
    %1: band name; 2: freq range
    %3: color of plotted spectrum
    %4: mean spectrum (10% trimmean), 5: SD
    %6-7: signigicant. 7: p_val; 8: h_mask
    %8-10: polyfit. 8: polynomial coef; 9: for error estimates or predictions; 10: trend of spectrum
    for j = 1 : size(FREQ_BAND, 1)
      freq_band = FREQ_BAND{j, 2};
      FREQ_INC(j, 1) = FREQ_BAND(j, 1);
      FREQ_INC(j, 2) = FREQ_BAND(j, 2);
      FREQ_INC(j, 3) = FREQ_BAND(j, 3);
%       FREQ_INC(j, 4) = {trimmean(PB_mov(find(freqs >= FREQ_BAND{j, 2}(1) & freqs <= FREQ_BAND{j, 2}(2)), :), 2, 10)};
      FREQ_INC(j, 4) = {trimmean(PB_mov(find(freqs >= FREQ_BAND{j, 2}(1) & freqs <= FREQ_BAND{j, 2}(2)), :), 10, 1)};
      FREQ_INC(j, 5) = {std(PB_mov(find(freqs >= FREQ_BAND{j, 2}(1) & freqs <= FREQ_BAND{j, 2}(2)), :), 0, 1)};
      %curve fitting
%       tmp_inc_freq = mean(PB_n(find(freqs >= FREQ_BAND{j, 2}(1) & freqs <= FREQ_BAND{j, 2}(2)), :));
      tmp_inc_freq = trimmean(PB_n(find(freqs >= FREQ_BAND{j, 2}(1) & freqs <= FREQ_BAND{j, 2}(2)), :), 10);
      [tmp_p tmp_S] = polyfit(RT_s, tmp_inc_freq, curfit_order);
      tmp_p_val = polyval(tmp_p, RT_s);
      tmp_p_mov = [];
%       tmp_inc_freq_mov = [];
      for k = 1 : movstep : size(PB_n, 2) - (alert.trials - 1)
%         tmp_p_mov = [tmp_p_mov mean(tmp_p_val(:, k : k + alert.trials - 1), 2)];
        tmp_p_mov = [tmp_p_mov trimmean(tmp_p_val(:, k : k + alert.trials - 1), 10, 2)];
%         tmp_inc_freq_mov = [tmp_inc_freq_mov mean(tmp_inc_freq(:, k : k + alert.trials - 1), 2)];
      end
      FREQ_INC(j, 8) = {tmp_p};
      FREQ_INC(j, 9) = {tmp_S};
      FREQ_INC(j, 10) = {tmp_p_mov};
    end  %j

    %statistics
    fprintf('Performing 2-sample T-test (p = %g): \n', p_val);
    P_mask = zeros(size(PB_mov));
    H_mask = P_mask;
    sig_idx = 1 : movstep : floor(size(PB_n, 2) / movstep) - (alert.trials - 1);
    for j = 1 : size(FREQ_BAND, 1)
      freq_beams = find(freqs >= FREQ_BAND{j, 2}(1) & freqs <= FREQ_BAND{j, 2}(2));
      p_band = trimmean(PB_mean(freq_beams, :), 10, 1);
      p_band_mask = zeros(1, size(P_mask, 2));  %need only one row
      h_band_mask = p_band_mask;
      for k = 1 : size(PB_mov, 2)
        if j == 1
          PB_tmp = PB_mean(:, sig_idx(k) : sig_idx(k) + alert.trials - 1);
          PB_alert_tmp = 0;
          if nor == 1
            subj_seq_id_tmp = subj_seq_id(:, sig_idx(k) : sig_idx(k) + alert.trials - 1);
            %counting how many trials of each subject in this window
            n_of_subj_win = 0;  %number of subjects in a moving window
            for m = 1 : session_count
              n_of_trial = length(find(subj_seq_id_tmp == m));
              if ~isempty(n_of_trial)
                PB_alert_tmp = PB_alert_tmp + PB_alert_subj(:, m) * n_of_trial;  %adding the power of alert trials according to proportion
                n_of_subj_win = n_of_subj_win + 1;
              else
                keyboard;
              end
            end
            PB_alert_tmp = PB_alert_tmp * ones(1, alert.trials) / alert.trials;
          else
            n_of_subject_win = 1;  %use the same baseline, no need do consider the difference between subjects
            PB_alert_tmp = PB_alert(:, 1 : alert.trials);
          end
          %corrected p_val: / 2: 2-tail; / size(freqs, 2): freq beams
%           [H, P] = ttest2(PB_tmp', PB_alert_tmp', p_val / 2 / size(freqs, 2) / alert.trials, 'both');
          %broad band
          [H, P] = ttest2(PB_tmp', PB_alert_tmp', p_val / 2 / size(freqs, 2) / n_of_subj_win, 'both');
          H_mask(:, k) = H';
          P_mask(:, k) = P';
        end
        %single band
        p_band_tmp = p_band(1, sig_idx(k) : sig_idx(k) + alert.trials - 1);
        p_band_alert_tmp = trimmean(PB_alert_tmp(freq_beams, :), 10, 1);
        [h, p] = ttest2(p_band_tmp', p_band_alert_tmp', p_val / 2 / size(freq_beams, 2) / n_of_subj_win, 'both');
        h_mask(:, k) = h';
        p_mask(:, k) = p';
      end
      FREQ_INC(j, 6) = {p_mask};
      FREQ_INC(j, 7) = {h_mask};
    end

%% plot figure for original, baseline, normalized, and moving avg. power images, p-value image, and power increase
%     xstep = (size(RT_s, 2) - 1) / xstep_int;
%     xstep_mov = (size(RT_s_mov, 2) - 1) / xstep_int;
    xstep = size(RT_s, 2) / xstep_int;
    xstep_mov = size(RT_s_mov, 2) / xstep_int;
    xticks_mov = ...
        (2 * .1 - alert.rate - 0.01) / (2 - 2 * alert.rate) * size(RT_s_mov, 2) - 1 : xstep / movstep : size(RT_s_mov, 2);
    figure(1079); hold on;
    set(gcf, 'Renderer', 'ZBuffer');
%     subplot('position', [.03 .88 .12 .12]); axis off;  %plot component map
    subplot('position', [.03 .9 .12 .1]); axis off;  %plot component map
    DR_topoplot(icawinv, chanlocs, 'electrodes', 'off', 'shrink', 'force');
    set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');  %set after topoplot to preserve backgound color
    subplot('position', [.15 .88 .8 .12]); axis off;   %title
    switch epoch_type
      case 'all'
        text(.5, .6, ...
            {['\color[rgb]' FONT_COLOR 'Mixed Power of the \color[rgb]{0 0 1}' IC_tmp{1} '\color[rgb]' FONT_COLOR  ' Cluster']; ...
            ['\fontsize{' int2str(STITLE_FSIZE + 4) '}\rm(\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' int2str(length(RT_s)) ' trials, ' int2str(cls_length) ...
            ' components from ' int2str(session_count) ' sessions)']}, ...
            'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE + 2, 'FontWeight', 'bold', ...
            'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
      case 'dev_on'
        text(.5, .6, ...
            {['\color[rgb]' FONT_COLOR 'Phasic Power of the \color[rgb]{0 0 1}' IC_tmp{1} '\color[rgb]' FONT_COLOR  ' Cluster']; ...
            ['\fontsize{' int2str(STITLE_FSIZE + 4) '}\rm(\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' int2str(length(RT_s)) ' trials, ' int2str(cls_length) ...
            ' components from ' int2str(session_count) ' sessions)']}, ...
            'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE + 2, 'FontWeight', 'bold', ...
            'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
      otherwise
        text(.5, .6, ...
            {['\color[rgb]' FONT_COLOR 'Tonic Power of the \color[rgb]{0 0 1}' IC_tmp{1} '\color[rgb]' FONT_COLOR  ' Cluster']; ...
            ['\fontsize{' int2str(STITLE_FSIZE + 4) '}\rm(\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' int2str(length(RT_s)) ' trials, ' int2str(cls_length) ...
            ' components from ' int2str(session_count) ' sessions)']}, ...
            'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE + 2, 'FontWeight', 'bold', ...
            'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
    end

    %plot original power image
%     subplot('position', [.055 .55 .36 .215]); hold on;
%     subplot('position', [.08 .605 .36 .19]); hold on;
    subplot('position', [.08 .57 .36 .225]); hold on;
    imagesc(1 : size(RT_s, 2), freqs, PB_mean, [-40 40]);
    set(gca, 'Xlim', [1 size(RT_s, 2)], 'XTick', xstep / 2 : xstep : size(RT_s, 2) - xstep / 2, ...
        'XTickLabel', (1 / 2: xstep_int - 1 / 2) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
        'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
%     %mark x ticks and add 2nd x-axis (RT, in the bottom)
%     tmp_xtick = roundn(RT_s(xstep / 2 : xstep : size(RT_s, 2) - xstep / 2), -2);
%     for k = xstep / 2 : xstep : size(RT_s, 2) - xstep / 2
%       if k ~= 1 && k ~= size(RT_s, 2)
%         plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
%       end
%       text(k, freqs(1), ['\color[rgb]' FONT_COLOR num2str(tmp_xtick(round((k - 1)/ xstep)), '%0.2f')], ...
%           'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Top');
%     end
%     %x label for the ticks on the bottom
%     text((1 + size(RT_s, 2)) / 2, freqs(1), {''; 'Reaction Time (sec)'}, ...
%         'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Top');
    %mark frequencies
    for k = 10 : 10 : 40
      plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
    end
%     %plot a vertical line with x axis on RT = 3 sec
%     try
%       plot([find(RT_s <= 3, 1, 'last') find(RT_s <= 3, 1, 'last')], get(gca, 'Ylim'), ...
%           'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
%     end
    xlabel('Reaction-Time-Sorted Trial Index (%)', 'VerticalAlignment', 'Baseline');
    %title
%     subplot('position', [.055 .82 .42 .03]); axis off;
    subplot('position', [.08 .85 .36 .03]); axis off;
    text(.5, 0, ['\color[rgb]' FONT_COLOR 'Original Baseline Power Image'], 'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, ...
        'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
    %colorbar
%     subplot('position', [.42 .55 .01 .215]); axis off;
%     subplot('position', [.445 .605 .01 .19]); axis off;
    subplot('position', [.445 .57 .01 .225]); axis off;
    imagesc(1, 33:65, (65 : -1 : 33)', [1 65]);
    title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
        'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
    set(gca, 'XTick', [], 'YTick', 33 : 8 : 65, 'YTickLabel', 40 : -10 : 0, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);

    %plot power image for alert trials (avg. power: baseline)
%     subplot('position', [.055 .305 .36 .215]); hold on;
%     subplot('position', [.08 .335 .36 .19]); hold on;
    subplot('position', [.08 .315 .36 .225]); hold on;
    if nor == 1 || nor == 2
      imagesc(1 : size(PB_alert, 2), [freqs(1) freqs(end)], PB_alert, [-40 40]);
%       set(gca, 'Xlim', [1 size(RT_s, 2)], 'XTick', 1 : xstep : size(RT_s, 2), 'XTickLabel', [], 'XColor', AXIS_COLOR, ...
%           'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
%       set(gca, 'Xlim', [1 size(PB_alert, 2)], 'XColor', AXIS_COLOR, ...
%           'XTick', (size(PB_alert, 2) - 1) / xstep_int + 1 : (size(PB_alert, 2) - 1) / xstep_int : size(PB_alert, 2) - (size(PB_alert, 2) - 1) / xstep_int, ...
%           'XTickLabel', roundn(RT_s((size(PB_alert, 2) - 1) / xstep_int + 1 : (size(PB_alert, 2) - 1) / xstep_int : size(PB_alert, 2) - (size(PB_alert, 2) - 1) / xstep_int), -2), ...
%           'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
      set(gca, 'Xlim', [1 size(PB_alert, 2)], 'XColor', AXIS_COLOR, ...
          'XTick', size(PB_alert, 2) / xstep_int / 2 : size(PB_alert, 2) / xstep_int : size(PB_alert, 2) - size(PB_alert, 2) / xstep_int / 2, ...
          'XTickLabel', [], 'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
      %mark x ticks
      for k = size(PB_alert, 2) / xstep_int / 2 : size(PB_alert, 2) / xstep_int : size(PB_alert, 2) - size(PB_alert, 2) / xstep_int / 2
        plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
      end
      %mark frequencies
      for k = 10 : 10 : 40
        plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
      end
%       xlabel('Reaction Time (sec)');
      %plot the avg. power of alert trial on the left (only for use the 2nd way in normalizing)
      if nor == 2
        set(gca, 'YTickLabel', []);
%         subplot('position', [.415 .305 .025 .215]);
%         subplot('position', [.055 .335 .025 .19]);
        subplot('position', [.055 .315 .025 .225]);
        plot(PB_alert_mean(:, 1), freqs(1 : end));
        set(gca, 'Color', BACKGROUND_COLOR, 'FontSize', AXIS_FSIZE, 'XAxisLocation', 'Top', ...
            'Xlim', [floor(min(PB_alert_mean(:, 1)) / 5) * 5 ceil(max(PB_alert_mean(:, 1)) / 5) * 5], ...
            'XTick', [floor(min(PB_alert_mean(:, 1)) / 5) * 5 floor(max(PB_alert_mean(:, 1)) / 5) * 5], 'XColor', AXIS_COLOR, ...
            'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : 40, 'YColor', AXIS_COLOR, 'YGrid', 'on', ...
            'Color', BACKGROUND_COLOR, 'FontSize', AXIS_FSIZE);
        title('Avg. Pow.', 'VerticalAlignment', 'Bottom');
      end
      ylabel('Frequency (dB)');
      %colorbar
%       subplot('position', [.445 .305 .01 .215]); axis off;
%       subplot('position', [.445 .335 .01 .19]); axis off;
      subplot('position', [.445 .315 .01 .225]); axis off;
      imagesc(1, 33:65, (65 : -1 : 33)', [1 65]);
      title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
          'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
      set(gca, 'XTick', [], 'YTick', 33 : 8 : 65, 'YTickLabel', 40 : -10 : 0, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);
    else
      plot(freqs, PB_alert_mean, 'b');
      set(gca, 'XTick', 10 : 10 : 40, 'Ylim', [0 30]);
      xlabel('Frequency (Hz)');
      ylabel('Power (dB)');
    end
    %title
%     subplot('position', [.055 .52 .42 .03]); axis off;
%     subplot('position', [.08 .525 .36 .03]); axis off;
    subplot('position', [.08 .54 .36 .03]); axis off;
    if nor == 1
      text(.5, 0, ...
          ['\color[rgb]' FONT_COLOR 'Power Image of Alert Trials of Each Subject'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
    elseif nor == 2
      text(.5, 0, ...
          ['\color[rgb]' FONT_COLOR 'Power Image of Alert Trials\rm\fontsize{' int2str(STITLE_FSIZE - 2) '} (' int2str(alert.trials) ' Trials)'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
    else
      text(.5, 0, ...
          ['\color[rgb]' FONT_COLOR 'Power Spectrum of Alert Trials\rm\fontsize{' int2str(STITLE_FSIZE - 2) '} (' int2str(alert.trials) ' Trials)'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
    end

    %plot normalized power image
%     subplot('position', [.055 .06 .36 .215]); hold on;
%     subplot('position', [.08 .06 .36 .19]); hold on;
    subplot('position', [.08 .06 .36 .225]); hold on;
    imagesc(1 : size(RT_s, 2), [freqs(1) freqs(end)], PB_n, [-10 20]);
    set(gca, 'Xlim', [1 size(RT_s, 2)], 'XTick', xstep / 2 : xstep : size(RT_s, 2) - xstep / 2, ...
        'XTickLabel', roundn(RT_s(xstep / 2 : xstep : size(RT_s, 2) - xstep / 2), -2), 'XColor', AXIS_COLOR, ...
        'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
    %mark x ticks
    for k = xstep / 2 : xstep : size(RT_s, 2) - xstep / 2
      plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
    end
    %mark frequencies
    for k = 10 : 10 : 40
      plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
    end
%     %plot a vertical line with x axis on that point
%     try
%       plot([find(RT_s <= 3, 1, 'last') find(RT_s <= 3, 1, 'last')], get(gca, 'Ylim'), ...
%           'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
%     end
    xlabel('Reaction Time (sec)');
    %title
%     subplot('position', [.055 .275 .42 .03]); axis off;
%     subplot('position', [.08 .25 .36 .03]); axis off;
    subplot('position', [.08 .285 .36 .03]); axis off;
    text(.5, 0, ['\color[rgb]' FONT_COLOR 'Normalized Baseline Power Image'], 'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, ...
        'HorizontalAlignment', 'Center', 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
    %colorbar
%     subplot('position', [.42 .06 .01 .215]); axis off;
%     subplot('position', [.445 .06 .01 .19]); axis off;
    subplot('position', [.445 .06 .01 .225]); axis off;
    imagesc(1, 1:65, (65 : -1 : 1)', [1 65]);
    title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
        'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
    set(gca, 'XTick', [], 'YTick', 1 : 64/3 : 65, 'YTickLabel', 20 : -10 : -10, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);

    %plot moving avg. power image (inside contour: p < p_val)
%     subplot('position', [.505 .55 .42 .215]); hold on;
    subplot('position', [.51 .57 .42 .225]); hold on;
    imagesc(1 : size(RT_s_mov, 2), freqs, PB_mov, [-3 6]);
    contour(1 : size(RT_s_mov, 2), freqs, H_mask, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
%     set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2, ...
%         'XTickLabel', (1 / 2 : xstep_int - 1 / 2) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
%         'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
    set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xticks_mov, ...
        'XTickLabel', (1 / 2 : xstep_int - 1 / 2) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
        'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
    %mark x ticks
%     for k = xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2
    for k = xticks_mov
      plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
    end
    %mark frequency
    for k = 10 : 10 : 40
      plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
    end
%     %plot a vertical line with x axis on RT = 3 sec
%     try
%       plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
%           'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
%     end
    xlabel('Reaction-Time-Sorted Trial Index (%)', 'VerticalAlignment', 'Baseline');
    %title
%     subplot('position', [.505 .82 .48 .03]); axis off;
    subplot('position', [.51 .85 .42 .03]); axis off;
    text(.5, 0, ['\color[rgb]' FONT_COLOR 'Moving Avg. Baseline Power Image\rm\fontsize {' int2str(STITLE_FSIZE - 2) '} (Countour: \itp\rm < ' num2str(p_val, '%.e') ')'], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
    %colorbar
%     subplot('position', [.93 .55 .01 .215]); axis off;
    subplot('position', [.935 .57 .01 .225]); axis off;
    imagesc(1, 1:65, (65 : -1 : 1)', [1 65]);
    title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
        'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
    set(gca, 'XTick', [], 'YTick', 1 : 64/3 : 65, 'YTickLabel', 6 : -3 : -3, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);

    %plot p-value image
%     subplot('position', [.505 .305 .42 .215]); hold on;
    subplot('position', [.51 .315 .42 .225]); hold on;
    imagesc(1 : size(RT_s_mov, 2), freqs, -log10(P_mask), [-10 30]);
    contour(1 : size(RT_s_mov, 2), freqs, H_mask, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
%     set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2, 'XTickLabel', [], 'XColor', AXIS_COLOR, ...
%         'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
    set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xticks_mov, 'XTickLabel', [], 'XColor', AXIS_COLOR, ...
        'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
    %mark x ticks
%     for k = xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2
    for k = xticks_mov
      plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
    end
    %mark frequency
    for k = 10 : 10 : 40
      plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
    end
%     %plot a vertical line with x axis on RT = 3 sec
%     try
%       plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
%           'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
%     end
    %title
%     subplot('position', [.505 .52 .48 .03]); axis off;
    subplot('position', [.51 .54 .42 .03]); axis off;
    text(.5, 0, ['\color[rgb]' FONT_COLOR 'P-Value Image\rm\fontsize{' int2str(STITLE_FSIZE - 2) '} (Countour: \itp\rm < ' num2str(p_val, '%.e') ')'], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
    %colorbar
%     subplot('position', [.93 .305 .01 .215]); axis off;
    subplot('position', [.935 .315 .01 .225]); axis off;
    imagesc(1, 1:65, (65 : -1 : 1)', [1 65]);
    title(['\color[rgb]' FONT_COLOR '(\itp\rm) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
        'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
    set(gca, 'XTick', [], 'FontSize', CBAR_FSIZE, ...
        'Ylim', [1 49], 'YTick', 1 : 16 : 49, 'YTickLabel', {'1e-30', '1e-20', '1e-10', '1'}, 'YAxisLocation', 'Right');
    %ylabel for the above two figure
%     subplot('position', [.475 .305 .03 .545]); axis off;
    subplot('position', [.48 .315 .03 .565]); axis off;
    text(0, .425, 'Frequency (Hz)', 'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, ...
        'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'Rotation', 90);

    %plot power increase over different frequent bands
%     subplot('position', [.505 .06 .42 .215]); hold on;
    subplot('position', [.51 .06 .42 .225]); hold on;
    %dummy, for legend
    if strcmpi(SD, '_SD')
      for k = 1 : size(FREQ_INC, 1)
        freq_color = FREQ_INC{k, 3};
        plot(0, 0, 'Color', freq_color, 'LineWidth', 1);
      end
    end
    %dummy, for RT
    if find(RT_s_mov <= 3, 1, 'last') ~= size(RT_s_mov, 2) || RT_s_mov(find(RT_s_mov <= 3, 1, 'last')) >= 2.995
      plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
    end
    legend_string = 'legend(';
    for k = 1 : size(FREQ_INC, 1)
      freq_name = FREQ_INC{k, 1};
      freq_band = FREQ_INC{k, 2};
      freq_color = FREQ_INC{k, 3};
      freq_inc = FREQ_INC{k, 4};
      freq_SD = FREQ_INC{k, 5};
      freq_sig = FREQ_INC{k, 6};
      plot(freq_inc, 'Color', freq_color, 'LineWidth', 1);
      if strcmpi(SD, '_SD')
        plot(freq_inc + freq_SD, 'Color', freq_color / 2, 'LineStyle', '-', 'LineWidth', .5);
      end
      %deal with legend
      legend_string = [legend_string '''' freq_name ' (' int2str(freq_band(1)) '~' int2str(freq_band(2)) ' Hz)'', '];
    end
%     set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2, ...
%         'XTickLabel', roundn(RT_s_mov(xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2), -2), 'XColor', AXIS_COLOR, ...
%         'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, 'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
    set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xticks_mov, 'XTickLabel', ...
        roundn(RT_s_mov((2 * .1 - alert.rate - 0.01) / (2 - 2 * alert.rate) * size(RT_s_mov, 2) - 1 : xstep / movstep : size(RT_s_mov, 2)), -2), ...
        'XColor', AXIS_COLOR, 'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, 'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
    %mark x ticks
%     for k = xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2
    for k = xticks_mov
      plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
    end
    %plot a vertical line with x axis on RT = 3 sec
    if find(RT_s_mov <= 3, 1, 'last') ~= size(RT_s_mov, 2) || RT_s_mov(find(RT_s_mov <= 3, 1, 'last')) >= 2.995
      plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
          'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
      legend_string = [legend_string '''RT = 3 sec'', ''Location'', ''NorthWest'');'];
    else
      legend_string = [legend_string '''Location'', ''NorthWest'');'];
    end
    legend_handle = eval(legend_string);
    set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off');
    xlabel('Moving Avg. Reaction Time (sec)');
    ylabel('Power Increase (dB)', 'VerticalAlignment', 'middle');
    title(['\color[rgb]' FONT_COLOR 'Power Increase in Different Frequency Bands'], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');

% %% plot figure for moving averaged power image and power increase [REPLACED BY DR_PlotClustPBase_merge from 2009/3/12]
%     figure(1080); hold on;
%     subplot('position', [.03 .88 .12 .12]); axis off;  %plot component map
%     DR_topoplot(icawinv, chanlocs, 'electrodes', 'off', 'shrink', 'force');
%     set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');  %set after topoplot to preserve backgound color
%     subplot('position', [.15 .88 .8 .12]); axis off;   %title
%     switch epoch_type
%       case 'all'
%         text(.5, .6, ...
%             {['\color[rgb]' FONT_COLOR 'Moving Averaged Power Spectra of \color[rgb]{0 0 1}' IC_tmp{1} '\color[rgb]' FONT_COLOR  ' Cluster']; ...
%             ['(Whole Epoch, \color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' int2str(length(RT_s)) ' Trials from ' int2str(cls_length) ...
%             ' Components in ' int2str(session_count) ' Sessions)']}, ...
%             'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
%             'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
%       case 'dev_on'
%         text(.5, .6, ...
%             {['\color[rgb]' FONT_COLOR 'Moving Averaged Power Spectra of \color[rgb]{0 0 1}' IC_tmp{1} '\color[rgb]' FONT_COLOR  ' Cluster']; ...
%             ['(After dev\_on, \color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' int2str(length(RT_s)) ' Trials from ' int2str(cls_length) ...
%             ' Components in ' int2str(session_count) ' Sessions)']}, ...
%             'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
%             'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
%       otherwise
%          text(.5, .6, ...
%             {['\color[rgb]' FONT_COLOR 'Moving Averaged Baseline Power Spectra of \color[rgb]{0 0 1}' IC_tmp{1} '\color[rgb]' FONT_COLOR  ' Cluster']; ...
%             ['(\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' int2str(length(RT_s)) ' Trials from ' int2str(cls_length) ...
%             ' Components in ' int2str(session_count) ' Sessions)']}, ...
%             'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
%             'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
%     end
% 
%     %plot moving avg. power image (inside contour: p < p_val)
%     subplot('position', [.055 .44 .875 .355]); hold on;
%     imagesc(1 : size(RT_s_mov, 2), freqs, PB_mov, [-3 6]);
%     contour(1 : size(RT_s_mov, 2), freqs, H_mask, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
%     set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2, ...
%         'XTickLabel', (1 / 2 : xstep_int - 1 / 2) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
%         'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
%     %mark x ticks
%     for k = xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2
%       plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
%     end
%     %mark frequency
%     for k = 10 : 10 : 40
%       plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
%     end
% %     %plot a vertical line with x axis on RT = 3 sec
% %     try
% %       plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
% %           'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
% %     end
%     xlabel('Reaction-Time-Sorted Trial Index (%)', 'VerticalAlignment', 'Baseline');
%     ylabel('Frequency (Hz)');
%     %title
%     subplot('position', [.055 .85 .875 .03]); axis off;
%     text(.5, 0, ['\color[rgb]' FONT_COLOR 'Moving Avg. Baseline Power Image\rm\fontsize {' int2str(STITLE_FSIZE - 2) '} (Countour: \itp\rm < ' num2str(p_val, '%.e') ')'], ...
%         'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
%     %colorbar
%     subplot('position', [.935 .44 .01 .355]); axis off;
%     imagesc(1, 1:65, (65 : -1 : 1)', [1 65]);
%     title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
%         'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
%     set(gca, 'XTick', [], 'YTick', 1 : 64/3 : 65, 'YTickLabel', 6 : -3 : -3, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);
% 
%     %plot power increase in different frequent bands
%     subplot('position', [.055 .06 .875 .355]); hold on;
%     legend_string = 'legend(';
%     for k = 1 : size(FREQ_INC, 1)
%       freq_name = FREQ_INC{k, 1};
%       freq_band = FREQ_INC{k, 2};
%       freq_inc = FREQ_INC{k, 3};
%       freq_color = FREQ_INC{k, 4};
%       plot(freq_inc, 'Color', freq_color, 'LineWidth', .5);
%       %deal with legend
%       legend_string = [legend_string '''' freq_name ' (' int2str(freq_band(1)) '~' int2str(freq_band(2)) ' Hz)'', '];
%     end
%     plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', .5);  %dummy, for RT
%     set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2, ...
%         'XTickLabel', roundn(RT_s_mov(xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2), -2), 'XColor', AXIS_COLOR, ...
%         'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, 'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
%     %mark x ticks
%     for k = xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2
%       plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
%     end
%     %plot a vertical line with x axis on RT = 3 sec
%     if find(RT_s_mov <= 3, 1, 'last') ~= size(RT_s_mov, 2) || RT_s_mov(find(RT_s_mov <= 3, 1, 'last')) >= 2.995
%       plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
%           'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
%       legend_string = [legend_string '''RT = 3 sec'', ''Location'', ''NorthWest'');'];
%     else
%       legend_string = [legend_string '''Location'', ''NorthWest'');'];
%     end
%     legend_handle = eval(legend_string);
%     set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off');
%     xlabel('Moving Avg. Reaction Time (sec)');
%     ylabel('Power Increase (dB)', 'VerticalAlignment', 'middle');
%     title(['\color[rgb]' FONT_COLOR 'Power Increase in Different Frequency Bands'], ...
%         'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');

%% save figure;
    figure(1079)
    if ~strcmp(epoch_type, 'all') && ~strcmp(epoch_type, 'dev_on')
      if isempty(noband) && isempty(SD)
%         save([FilePathOld epoch_type SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_' MN '.mat'], ...
%                'cls_length', 'session_count', 'icawinv', 'chanlocs', 'freqs', 'RT_s', 'RT_s_mov', 'subj_seq', 'p_val', ...
%                'PB_mean', 'PB_alert', 'PB_n', 'PB_alert_subj', 'PB_mov', 'FREQ_INC', 'H_mask', 'P_mask', ['IC' num2str(i, '%02d')]);
      end
%       save(['~/IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_' MN '.mat'], ...
%              'cls_length', 'session_count', 'icawinv', 'chanlocs', 'freqs', 'RT_s', 'RT_s_mov', 'subj_seq', 'p_val', ...
%              'PB_mean', 'PB_alert', 'PB_n', 'PB_alert_subj', 'PB_mov', 'FREQ_INC', 'H_mask', 'P_mask', ['IC' num2str(i, '%02d')]);
      saveas(1079, [FilePathOld epoch_type SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_method_' MN SD noband '.fig']);
%       print('-dpng', [FilePathOld epoch_type SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_method_' MN SD noband '.png']);
%       print('-dpng', ['~/IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_method_' MN SD noband '.png']);
    else
      save([FilePathOld epoch_type SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_' MN '_' epoch_type '.mat'], ...
             'cls_length', 'session_count', 'icawinv', 'chanlocs', 'freqs', 'RT_s', 'RT_s_mov', 'subj_seq', 'p_val', ...
             'PB_mean', 'PB_alert', 'PB_n', 'PB_alert_subj', 'PB_mov', 'FREQ_INC', 'H_mask', 'P_mask', ['IC' num2str(i, '%02d')]);
      print('-dpng', [FilePathOld epoch_type SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_method_' MN '_' epoch_type SD noband '.png']);
    end
%     figure(1080)
%     if ~strcmp(epoch_type, 'all') && ~strcmp(epoch_type, 'dev_on')
%       saveas(1080, [FilePathOld epoch_type SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_result_' MN '.fig']);
%       print('-dpng', [FilePathOld epoch_type SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_result_' MN '.png']);
%     else
%       print('-dpng', [FilePathOld epoch_type SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_result_' MN '_' epoch_type '.png']);
%     end
    close(1079);
%     close(1080);
  else
    fprintf('IC%02d: No components in this cluster. Omit this cluster.', i);
  end
%%
end