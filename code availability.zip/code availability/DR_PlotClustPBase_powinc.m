% Comparing power between motionless/motion + 2 of tonic/mixed/phasic
% Plot power increase in desired bands (each band / a plot)
% Plot all designated cluster in a plot
% rows: motionless/motion
% columns: cluster
% colors of traces: tonic/mixed/phasic
% This version: 200906 by poem

%% set parameters (initialize)
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/RS/';  %directory
  SL = '/';
end
DR_PBase_setup;  %load setup file
MN = {'motionless'; 'motion'};
MN_COLOR = {'{0 0 1}', '{1 0 0}', '{0 1 0}'};
EPOCH_TYPE = {'', 'all'};  %'' => baseline, all => all epoch, dev_on => after dev_on; allowing 2 types
EPOCH_COLOR = {[0 .5 1], [0 .66 0], [0 0 0]};
for i = 1 : size(FREQ_BAND, 1)
  try
    close(1900 + i);
  end
end
rj = '_rj';
noband = '';  %1: alpha + theta
SD = '';
ylim_tmp = [-2 7];
nor = 1;
plot_clust = [9 5 1 4];  %the cluster to be plotted (sequence matter)
%font size
FONT_SIZE = 12;  %text
TITLE_FSIZE = 14;  %title
STITLE_FSIZE = 12;  %subtitle
AXIS_FSIZE = 12;  %axis
CBAR_FSIZE = 12;  %color bar
ClsLabel = ClsLabel(plot_clust, :);
splt_width = size(ClsLabel, 1);
blank = .015;
splt_height = size(MN, 1);
%splt_w = total - MN - ylabel - yticklabel - blank
splt_w = 1 - .03 - .03 - .03 - splt_width * blank;
splt_w = floor(splt_w * 10000 / splt_width) / 10000;
%splt_h = total - title - s_title - blank - xticklabel - xlabel
splt_h = 1 - .015 * 2 - .035 - .03 - blank * (splt_height - 1) - .03 - .03;  %.015: upper and lower blank
splt_h = floor(splt_h * 10000 / splt_height) / 10000;
%dimension of scalp map: square with length of each side = min(splt_w, splt_h) * .4
comp_w = min(splt_w, splt_w) * 1/3;
comp_h = comp_w * 4/3;  %aspect ratio
splt_count = 0;  %for indexing subplots
RT_s_mov_overlap = [-Inf Inf];
legend_string = 'legend(';

%% process data and plot figure
for i = 1 : size(ClsLabel, 1)
  for j = 1 : size(MN, 1)
    splt_count = splt_count + 1;
    mn = MN{j};
    if j <= size(MN_COLOR, 2)
      mn_color = MN_COLOR{j};
    else
      mn_color = MN_COLOR{mod(j, size(MN_COLOR, 2)) + 1};
    end
    for k = 1 : size(EPOCH_TYPE, 2)
      if k <= size(EPOCH_COLOR, 2)
        epoch_cl = EPOCH_COLOR{k};
      else
        epoch_cl = EPOCH_COLOR{mod(k, size(EPOCH_COLOR_COLOR, 2)) + 1};
      end
      if ~isempty(EPOCH_TYPE{k})
        epoch_type_tmp = load([FilePath ...
            EPOCH_TYPE{k} SL mn SL 'IC' num2str(plot_clust(i), '%02d') '_PBase_' int2str(nor) '_' mn '_' EPOCH_TYPE{k}]);
      else
        epoch_type_tmp = load([FilePath ...
            EPOCH_TYPE{k} SL mn SL 'IC' num2str(plot_clust(i), '%02d') '_PBase_' int2str(nor) '_' mn]);
      end
      RT_s_mov = epoch_type_tmp.RT_s_mov;
      freqs = epoch_type_tmp.freqs;
      H_mask = epoch_type_tmp.H_mask;
      FREQ_INC = epoch_type_tmp.FREQ_INC;
      icawinv = epoch_type_tmp.icawinv;
      chanlocs = epoch_type_tmp.chanlocs;
      clear epoch_type_tmp;
      switch noband
        case '1'
          FREQ_INC(3, :) = [];
      end
      if RT_s_mov(1) > RT_s_mov_overlap(1)
        RT_s_mov_overlap(1) = RT_s_mov(1);
      end
      if RT_s_mov(end) < RT_s_mov_overlap(2)
        RT_s_mov_overlap(2) = RT_s_mov(end);
      end
      for m = 1 : size(FREQ_INC, 1)
        freq_name = FREQ_INC{m, 1};
        freq_band = FREQ_INC{m, 2};
        freq_color = FREQ_INC{m, 3}; freq_color = mat2str(freq_color);
        freq_inc = FREQ_INC{m, 4};
        freq_SD = FREQ_INC{m, 5};
        freq_sigh = FREQ_INC{m, 7};
        freq_beams = find(freqs >= freq_band(1) & freqs < freq_band(2));
        h_mask = H_mask(freq_beams, :); h_mask = sum(h_mask);
        pow_inc_sig_idx = find(freq_sigh);
        figure(1900 + m);
        if i == 1 && j == 1 && k == 1  %first plot, add title and axis labels
          subplot('position', [0 .95 1 .035]); axis off;
          %title
          text(.5, .5, ['\color[rgb]' FONT_COLOR 'Power Increase (\color[rgb]{' freq_color(2 : end - 1) '}' ...
              freq_name '\color[rgb]' FONT_COLOR ' Band)'], 'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, ...
              'FontWeight', 'bold', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'baseline');
          %xlabel
          subplot('position', [0 0.015 1 .03]); axis off;
          text(.5, .5, ...
              ['\color[rgb]' FONT_COLOR 'Moving Averaged Reaction Time (sec)'], 'FontName', FONT_FACE, ...
              'FontSize', AXIS_FSIZE, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'cap');
          %ylabel
          subplot('position', [.03 .045 .03 .875]); axis off;
          text(.5, .5, ...
              ['\color[rgb]' FONT_COLOR 'Power Increase (dB)'], 'Rotation', 90, 'FontName', FONT_FACE, ...
              'FontSize', AXIS_FSIZE, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'cap');
        end
        splt_x = .09 + (splt_w + blank) * (i - 1);
        splt_y = 1 - .015 - .035 - .03 - splt_h * j - blank * (j - 1);
        %motionless/motion
        if i == 1 && k == 1  %the first cluster to be plotted. add motionless/motion
          subplot('position', [0 splt_y .03 splt_h]); axis off;
          text(.5, .5, ...
              ['\color[rgb]' mn_color upper(mn)], 'Rotation', 90, 'FontName', FONT_FACE, 'FontWeight', 'bold', ...
              'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'cap');
        end
        %subtitle
        if j == 1 && k == 1  %the first condition add sub-title
          subplot('position', [splt_x .92 splt_w .03]); axis off;
          text(.5, .5, ['\color[rgb]' FONT_COLOR ClsLabel{i}], 'FontName', FONT_FACE, 'FontWeight', 'bold', ...
              'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
        end
        if k == 1
          spow((m - 1) * 100 + splt_count) = subplot('position', ...
              [splt_x splt_y splt_w splt_h]);
          hold on;
          if i == 1 && j == 1 && k == 1 %for legend
            plot(0, 0, 'Color', [0 .5 1], 'LineWidth', 1);
            plot(0, 0, 'Color', [0 .66 0], 'LineWidth', 1);
            plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);  %dummy, for RT
          end
        else
          subplot(spow((m - 1) * 100 + splt_count));
        end
        if ~isempty(pow_inc_sig_idx)
%           plot(RT_s_mov(pow_inc_sig_idx), freq_inc(pow_inc_sig_idx), 'Color', [0 0 0], 'LineWidth', 3);
          idx_diff = diff(pow_inc_sig_idx);
          gap = find(idx_diff ~= 1);
          if isempty(gap)
            gap = size(pow_inc_sig_idx, 2);
          end
          lineseg = {1 : gap(1)};
          for n = 2 : size(gap, 2)
            lineseg = [lineseg; gap(n - 1) + 1 : gap(n)];
          end
          lineseg =[lineseg; (gap(n) + 1) : size(pow_inc_sig_idx, 2)];
          for n = 1 : size(lineseg, 1)
            plot(RT_s_mov(pow_inc_sig_idx(lineseg{n})), freq_inc(pow_inc_sig_idx(lineseg{n})), 'Color', [0 0 0], 'LineWidth', 3);
          end
%           for n = 1 : size(pow_inc_sig_idx, 2)  %using dots to mark significant region
%             plot(RT_s_mov(pow_inc_sig_idx(n)), freq_inc(pow_inc_sig_idx(n)), ...
%                 'Color', [0 0 0], 'Marker', 's', 'MarkerSize', 3, 'MarkerEdgeColor', [0 0 0], 'MarkerFaceColor', [0 0 0]);
%           end
        end
        plot(RT_s_mov, freq_inc, 'Color', epoch_cl, 'LineWidth', 1);
        if strcmpi(SD, '_SD')
          plot(RT_s_mov, freq_inc + freq_SD, 'Color', epoch_cl / 2, 'LineWidth', .5);
        end
        %deal with legend
        if i == 1 && j == 1 && m == 1
          if k == 1
          legend_string = [legend_string '[8220 ''Tonic'' 8221], '];
          else
          legend_string = [legend_string '[8220 ''Mixed'' 8221], '];
          end
        end
        %deal with component map
        if k == 1%size(EPOCH_TYPE, 2)
          scom((m - 1) * 100 + splt_count) = axes('position', ...
              [splt_x + (splt_w - comp_w), splt_y + (splt_h - comp_h), comp_w, comp_h]); axis off;
          try
            DR_topoplot(icawinv, chanlocs, 'electrodes', 'off', 'shrink', 'force');
          catch
            topoplot(icawinv, chanlocs, 'electrodes', 'off', 'shrink', 'force');  %default in EEGLAB
          end
        end
      end  %m = 1 : size(FREQ_INC, 1)
    end  %k = 1 : size(EPOCH_TYPE, 2)
  end  %j = 1 : size(MN, 1)
%   keyboard;
end  %i = 1 : size(ClsLabel, 1)

%add 3-sec line and set axes properties
for i = 1 : size(FREQ_INC, 1)
  figure(1900 + i);
  set(gcf, 'Color', BACKGROUND_COLOR, 'Renderer', 'zbuffer', 'InvertHardcopy', 'off');
  for j = 1 : splt_count
    subplot(spow((i - 1) * 100 + j));
    box on;
    if RT_s_mov_overlap(2) >= 3
      %a vertical line with x axis on RT = 3 sec
      plot([3 3], ylim_tmp, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
      %update legend
      if i == 1 && j == 1
        legend_string = [legend_string '''RT = 3 sec'', '];
      end
    end
    if i == 1 && j == 1  %legend
      legend_string = [legend_string '''Location'', ''NorthWest'');'];
    end
    if j == 1
      legend_handle = eval(legend_string);
      set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off');
    end
    %finish a plot. decide axes properties
    set(gca, 'Xlim', RT_s_mov_overlap, 'XColor', AXIS_COLOR, 'XScale', 'linear', ...
        'XTick', 1 : 2 : RT_s_mov_overlap(2), 'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, ...
        'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
    if mod(j, size(MN, 1)) ~= 0  %last row. label for XTick
      set(gca, 'XTickLabel', []);
    end
    if (j - 1) / size(MN, 1) < 1  %first column. label for YTick
      set(gca, 'YTickLabel', {'', '0', '', '2', '', '4', '', '6'});
    else
      set(gca, 'YTickLabel', []);
    end
  end  %j = 1 : splt_count
    
  %save figure
  freq_name = FREQ_INC{i, 1};
  freq_name = freq_name(find(freq_name ~= '\' & freq_name ~= ' '));
  saveas(gcf, [FilePath SL 'ICs' dec2hex(plot_clust)' '_powinc_' freq_name '_' int2str(nor) rj SD '.fig']);
  print('-dpng', [FilePath SL 'ICs' dec2hex(plot_clust)' '_powinc_' freq_name '_' int2str(nor) rj SD '.png']);
  close(gcf);
end  %i = 1 : size(FREQ_INC, 1)