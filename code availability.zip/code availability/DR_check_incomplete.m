% function [evt_mark evt_tmp] = DR_check_incomplete(evt_mark, evt_col)
% check if incomplete trial exists
% inputs:
%   evt_mark: array containing event information (with n colunms)
%   evt_col: this column is event type
% output:
%   evt_mark: array containing event information with new columns
%     indicating if this trial and nearby trials may be incomplete (with n 
%     + 2 columns)
%   evt_tmp: if not empty => evt_mark has incomplete (losting event) trials
%            if empty => all trials are complete
% for drowsiness
% by poem, 2008/6

function [evt_mark evt_tmp] = DR_check_incomplete(evt_mark, evt_col)

  lastcol = size(evt_mark, 2) + 1;
  %dev_on
  evt_tmp = find(mod(evt_mark(:, evt_col), 1000) == 251 | mod(evt_mark(:, evt_col), 1000) == 252);
  evt_mark(evt_tmp, lastcol) = 1;
  %dev_peak
  evt_tmp = find(mod(evt_mark(:, evt_col), 1000) == 253);
  evt_mark(evt_tmp, lastcol) = 2;
  %dev_off
  evt_tmp = find(mod(evt_mark(:, evt_col), 1000) == 254 | mod(evt_mark(:, evt_col), 1000) == 255);
  evt_mark(evt_tmp, lastcol) = 3;
  if evt_mark(1, lastcol) ~= 1  %ensure the 1st event == dev_on
    evt_tmp = find(evt_mark(:, lastcol) == 1, 1, 'first');
    evt_mark(1 : evt_tmp - 1, :) =[];
  end
  if evt_mark(end, lastcol) ~= 3  %ensure the last event == dev_off
    evt_tmp = find(evt_mark(:, lastcol) == 3, 1, 'last');
    evt_mark(evt_tmp + 1 : end, :) =[];
  end
  if size(evt_mark, 1) < 3  %a "complete" trial with 3 events
    fprintf('Insufficient length of input matrix. All trials are incomplete.\n');
    evt_mark(:, evt_col) = 0; evt_mark(:, lastcol + 1) = -1;
    return;
  end
  %check if incomplete trials exist
  evt_mark(1, lastcol + 1) = -2;
  for j = 2 : size(evt_mark, 1)
    evt_mark(j, lastcol + 1) = evt_mark(j, lastcol) - evt_mark(j - 1, lastcol);
  end
  evt_tmp = find(evt_mark(:, lastcol + 1) == -2 & evt_mark(:, lastcol) == 1);
  evt_mark(evt_tmp, lastcol + 1) = 1;
  evt_tmp = find(evt_mark(:, lastcol + 1) ~= 1);

end