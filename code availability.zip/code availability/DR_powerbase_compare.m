% Comparing power between 2 of the followings: baseline, whole epoch, and after dev_on [single subject]
% ver 200903 by poem

%% set parameters (initialize)
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/RS/';  %directory
  SL = '/';
end
DR_PBase_setup;
%datasets
PLOT_SET = {
            's31_061103';  %motionless
            's32_061031';  %motionless
            's35_070322';  %motionless
            's36_061221';  %motionless
%             's37_061213';  %motionless
%             's39_070117';  %motionless
            's40_070207';  %motionless
            's41_061225';  %motionless
            's42_070105';  %motionless
            's43_070208';  %motionless
            's44_070325';  %motionless
            's54_081209n';  %motionless
            's31_061020';  %motion
            's35_070115';  %motion
            's36_061122';  %motion
%             's39_061218';  %motion
            's40_070131';  %motion
            's43_070202';  %motion
            's44_070126';  %motion
           };
MN = 'motion';
p_val = 1E-4;
try  %for topoplot
  icadefs;
catch
  addpath(genpath(EEGLAB_dir));
  icadefs;
end
movstep = 1;  %stepping for moving avg
xstep_int = 5;
ylim_tmp = [-2 7];  %for power increase
EPOCH_TYPE = {'', 'all'};  %'' => baseline, all => all epoch, dev_on => after dev_on; allowing 2 types
rj = '_rj';
FilePathOld = FilePath;
try
  close(1066);
end

%%
for i = 1 : size(PLOT_SET, 1)
%% calculate power
  Go = true;  %flag, if dataset is invalid => stop process
  FilePath = FilePathOld;
  plot_set = PLOT_SET{i, 1};
  %check if the plot_set is valid
  for j = 1 : size(SET, 1)
    Set = SET{j, 1};
    condition = SET{j, 3};
    if strcmp(Set, plot_set)
      if strcmp(condition, MN)
        COMP = SET{j, 2};
        break;
      else
       Go = false;
       break;
      end
    end
    if j == size(SET, 1)
      Go = false;  %error occurs
    end
  end
  if Go
    rj = '_rj';
    [subj ExpDate] = strtok(Set, '_'); ExpDate = ExpDate(2 : end);

    for j = 1 : size(COMP, 2)
      %loading data
      comp = COMP(1, j);
      cls = COMP(2, j);  %which cluster
%       PB_mean = [];
      if cls < 0  %not selected after screening
        cls = 0;
      end
      if ~isempty(EPOCH_TYPE{1})
        epoch_type1 = load([FilePath EPOCH_TYPE{1} SL MN SL 'IC' num2str(cls, '%02d') SL ...
            Set '_PBaseRT_' num2str(comp, '%02d') rj '_' EPOCH_TYPE{1}]);
      else
        epoch_type1 = load([FilePath EPOCH_TYPE{1} SL MN SL 'IC' num2str(cls, '%02d') SL ...
            Set '_PBaseRT_' num2str(comp, '%02d') rj]);
      end
      alert.trials = ceil(size(epoch_type1.RT_s, 2) * alert.rate);  %the first alert.rate * 100% of all trials: alert
      if ~isempty(EPOCH_TYPE{2})
        epoch_type2 = load([FilePath EPOCH_TYPE{2} SL MN SL 'IC' num2str(cls, '%02d') SL ...
            Set '_PBaseRT_' num2str(comp, '%02d') rj '_' EPOCH_TYPE{2}]);
      else
        epoch_type2 = load([FilePath EPOCH_TYPE{2} SL MN SL 'IC' num2str(cls, '%02d') SL ...
            Set '_PBaseRT_' num2str(comp, '%02d') rj]);
      end
      valid_trial = size(epoch_type1.PB_mean, 2);
      %calculate differences
%       PB_mov_diff = epoch_type1.PB_mov - epoch_type2.PB_mov;  %these two PB_mov with the same dimension
%       FREQ_INC_DIFF = epoch_type1.FREQ_INC;
%       for k = 1 : size(FREQ_INC_DIFF, 1)
%         FREQ_INC_DIFF{k, 3} = FREQ_INC_DIFF{k, 3} - epoch_type2.FREQ_INC{k, 3};
%       end
%       %statistics test (2-sample t-test)
%       %courtesy Ruey-Song Huang in UCSD
%       fprintf('Performing 2-sample T-test (p = %g): \n', p_val);
%       P_mask_diff = zeros(size(epoch_type1.PB_mov));
%       H_mask_diff = P_mask_diff;
%       sig_idx = 1 : movstep : floor(size(epoch_type1.PB_n, 2) / movstep) - (alert.trials - 1);
%       for k = 1 : size(epoch_type1.PB_mov, 2)
%         PB_tmp1 = epoch_type1.PB_mean(:, sig_idx(k) : sig_idx(k) + alert.trials - 1);
%         PB_tmp2 = epoch_type2.PB_mean(:, sig_idx(k) : sig_idx(k) + alert.trials - 1);
%         %corrected p_val: / 2: 2-tail; / size(freqs, 2): freq bins;
% %         [H, P] = ttest2(PB_tmp1', PB_tmp2', p_val / 2 / size(epoch_type1.freqs, 2) / alert.trials, 'both');
%         [H, P] = ttest2(PB_tmp1', PB_tmp2', p_val / 2 / size(epoch_type1.freqs, 2), 'both');
%         H_mask_diff(:, k) = H';
%         P_mask_diff(:, k) = P';
%       end

%% plot figure for moving averaged power image and power increase
      figure(1066); hold on;
      set(gcf, 'Render', 'Zbuffer');
      %title for whole figure
      subplot('position', [.03 .88 .12 .12]); axis off;  %plot component map
      topoplot(epoch_type1.icawinv(:, comp), epoch_type1.chanlocs, 'electrodes', 'on', 'shrink', 'force');
      set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');  %set after topoplot to preserve backgound color
      subplot('position', [.15 .88 .8 .12]); axis off;   %title
      text(.5, .6, {['\color[rgb]' FONT_COLOR 'Comparison of Moving Avg. Power Spectra Between "Baseline" and "Whole Epoch"']; ...
          ['Component ' int2str(comp) ', ' subj '\_' ExpDate ' (' int2str(valid_trial) ' Trials)']}, ...
          'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
          'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');

      xstep = (size(epoch_type1.RT_s, 2) - 1) / xstep_int;
      xstep_mov = (size(epoch_type1.RT_s_mov, 2) - 1) / xstep_int;
      for k = 1 : 2
        %1: baseline power; 2: power of the whole epoch; 3: power differences (obsolete)
%         if k ~= 3
%           eval(['epoch_type_tmp = epoch_type' int2str(k) ';']);
%           PB_mov = epoch_type_tmp.PB_mov;
%           RT_s_mov = epoch_type_tmp.RT_s_mov;
%           freqs = epoch_type_tmp.freqs;
%           PB_mov = epoch_type_tmp.PB_mov;
%           FREQ_INC = epoch_type_tmp.FREQ_INC;
%           clear epoch_type_tmp;
%         else
          PB_mov = PB_mov_diff;
          RT_s_mov = epoch_type1.RT_s_mov;
          freqs = epoch_type1.freqs;
          FREQ_INC = FREQ_INC_DIFF;
%         end
        %power image
        subplot('position', [.055 + .3 * (k - 1) .44 .275 .355]); hold on;
        imagesc(1 : size(RT_s_mov, 2), freqs, PB_mov, [-3 6]);
%         %adding significant region
%         if k == 3
%           contour(1 : size(RT_s_mov, 2), freqs, H_mask_diff, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
%         end
        set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov, ...
            'XTickLabel', (1 : xstep_int - 1) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
            'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
        if k ~= 1
          set(gca, 'YTickLabel', []);
        end
        %mark x ticks
        for m = xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov
          plot([m m], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
        end
        %mark frequency
        for m = 10 : 10 : 40
          plot(get(gca, 'Xlim'), [m m], ':k', 'LineWidth', 1);
        end
%         %plot a vertical line with x axis on RT = 3 sec
%         try
%           plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
%               'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
%         end
        %axis labels
        if k == 1
          ylabel('Frequency (Hz)');
        elseif k == 2
          xlabel('Reaction-Time-Sorted Trial Index (%)', 'VerticalAlignment', 'Baseline');
        end
%         subplot('position', [.055 + .3 * (k - 1) .85 .275 .03]); axis off;
        subplot('position', [.055 + .45 * (k - 1) .85 .425 .03]); axis off;
        %title and colorbar
        if k == 1
          text(.5, 0, ['\color[rgb]' FONT_COLOR 'Baseline Power Image'], ...
              'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
        else%if k == 2
          %title
          text(.5, 0, ['\color[rgb]' FONT_COLOR 'Power Image of the Whole Epoch'], ...
              'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
%         else
%           text(.5, 0, ['\color[rgb]' FONT_COLOR 'Power Differences\rm\fontsize {' int2str(STITLE_FSIZE - 2) '} (Countour: p < ' num2str(p_val, '%.e') ')'], ...
%               'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
        end
          %colorbar
          subplot('position', [.935 .44 .01 .355]); axis off;
          imagesc(1, 1:65, (65 : -1 : 1)', [1 65]);
          title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
              'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
          set(gca, 'XTick', [], 'YTick', 1 : 64/3 : 65, 'YTickLabel', 6 : -3 : -3, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);
%         end

        %plot power increase over different frequent bands
%         subplot('position', [.055 + .3 * (k - 1) .06 .275 .355]); hold on;
        subplot('position', [.055 + .45 * (k - 1) .06 .425 .355]); hold on;
        if k == 1
          legend_string = 'legend(';
        end
        for m = 1 : size(FREQ_INC, 1)
          freq_name = FREQ_INC{m, 1};
          freq_band = FREQ_INC{m, 2};
          freq_inc = FREQ_INC{m, 3};
          freq_color = FREQ_INC{m, 4};
          plot(freq_inc, 'Color', freq_color, 'LineWidth', .5);
          if k == 1
            %deal with legend
            legend_string = [legend_string '''' freq_name ' (' int2str(freq_band(1)) '~' int2str(freq_band(2)) ' Hz)'', '];
          end
        end
        plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', .5);  %dummy, for RT
        set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XColor', AXIS_COLOR, ...
            'XTick', xstep_mov + 1 : xstep_mov : size(RT_s_mov - xstep_mov, 2) - xstep_mov, ...
            'XTickLabel', roundn(RT_s_mov(xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov), -2), ...
            'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
        if k ~= 1
          set(gca, 'YTickLabel', []);
        end
        %mark x ticks
        for m = xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov
          plot([m m], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
        end
        %plot a vertical line with x axis on RT = 3 sec
        if find(RT_s_mov <= 3, 1, 'last') ~= size(RT_s_mov, 2) || RT_s_mov(find(RT_s_mov <= 3, 1, 'last')) >= 2.995
          plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
              'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
          if k == 1
            legend_string = [legend_string '''RT = 3 sec'', ''Location'', ''NorthWest'');'];
          end
        else
          if k == 1
            legend_string = [legend_string '''Location'', ''NorthWest'');'];
          end
        end
        if k == 1
          legend_handle = eval(legend_string);
          set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off');
        end
        %axis labels and titles
        if k == 1
          ylabel('Power (dB)', 'VerticalAlignment', 'middle');
          title(['\color[rgb]' FONT_COLOR 'Baseline Power Increase'], ...
            'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
        else%if k == 2
          xlabel('Moving Avg. Reaction Time (sec)');
          title(['\color[rgb]' FONT_COLOR 'Power Increase of the Whole Epoch'], ...
              'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
%         else
%           title(['\color[rgb]' FONT_COLOR 'Differences Between Power Increases'], ...
%               'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
        end
      end

%% save all figures and necessary variables
      str1 = EPOCH_TYPE{1};
      str2 = EPOCH_TYPE{2};
      if isempty(str1)
        str1 = 'baseline';
      end
      if isempty(str2)
        str2 = 'baseline';
      end
%       save([FilePathOld MN SL ...
%           'IC' num2str(cls, '%02d') SL Set '_compare_' str1 '_' str2 '_' num2str(comp, '%02d') rj '.mat'], ...
%           'PB_mov_diff', 'FREQ_INC_DIFF', 'H_mask_diff', 'P_mask_diff');
      saveas(1066, [FilePathOld MN SL ...
          'IC' num2str(cls, '%02d') SL Set '_compare_' str1 '_' str2 '_' num2str(comp, '%02d') rj '.fig']);
      print('-dpng', [FilePathOld MN SL ...
          'IC' num2str(cls, '%02d') SL Set '_compare_' str1 '_' str2 '_' num2str(comp, '%02d') rj '.png']);
      close(1066);
    end
%%
  else
    fprintf('%s: not valid, check set name or condition (motion/motionless).\n', plot_set);
  end
end