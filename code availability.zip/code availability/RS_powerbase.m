% Computing baseline power
% Core code provided by Ruey-song Huang (SCCN, UCSD)
% ver 200901

%% set parameters (initialize)
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/';  %directory
  SL = '/';
end
DR_PBase_setup;
%datasets
PLOT_SET = {
            's01_061102';  %motionless
            's05_061101';  %motionless
            's31_061103';  %motionless
            's32_061031';  %motionless
            's35_070322';  %motionless
            's36_061221';  %motionless
%             's37_061213';  %motionless
%             's39_070117';  %motionless
            's40_070207';  %motionless
            's41_061225';  %motionless
            's42_070105';  %motionless
            's43_070208';  %motionless
            's44_070325';  %motionless
            's54_081209n';  %motionless
            's05_061019';  %motion
            's31_061020';  %motion
            's35_070115';  %motion
            's36_061122';  %motion
%             's39_061218';  %motion
            's40_070131';  %motion
            's43_070202';  %motion
%             's44_070126';  %motion
            's44_070209';  %motion
           };
MN = 'motionless';
p_val = 1E-4;
try  %for topoplot
  try 
    DR_icadefs
  catch
    icadefs;
  end
catch
  addpath(genpath(EEGLAB_dir));
  try 
    DR_icadefs
  catch
    icadefs;
  end
end
winsize = 30;  %-30 < t <= 30 (sec); real winsize = winsize * 2
stepping = 1;  %step
movstep = 1;  %stepping for moving avg
xstep_int = 5;
ylim_tmp = [-2 7];  %for power increase
epoch_type = '';  %'' => baseline, all => all epoch, dev_on => after dev_on
FilePathOld = FilePath;
try
  close(1015);
end
try
  close(1024);
end
try
  close(1026);
end

%%
for i = 1 : size(PLOT_SET, 1)
%% calculate power
  Go = true;  %flag, if dataset is invalid => stop process
  FilePath = FilePathOld;
  plot_set = PLOT_SET{i, 1};
  %check if the plot_set is valid
  for j = 1 : size(SET, 1)
    Set = SET{j, 1};
    condition = SET{j, 3};
    if strcmp(Set, plot_set)
      if strcmp(condition, MN)
        COMP = SET{j, 2};
        break;
      else
       Go = false;
       break;
      end
    end
    if j == size(SET, 1)
      Go = false;  %error occurs
    end
  end
  if Go
    rj = '_rj';
    [subj ExpDate] = strtok(Set, '_'); ExpDate = ExpDate(2 : end);
    FilePath = [FilePath Set SL];
    %load EEG dataset (only load necessary information. name of variables: the same as in .set file)
    EEG = pop_loadset([FilePath Set EpochType{1} rj '.set']);
    %load RT
    load([FilePath Set '_RT_of_trials'], 'RT');  %RT: 1 * n array
    %load epoch information
    load([FilePath Set '_epoch_inf']);
    %modify rj, for different epoch_type
    if ~isempty(epoch_type)
      rj = [rj '_' epoch_type];
    end
    %rename variables to more meaningful ones
    icaact = EEG.icaact;
    icawinv = EEG.icawinv;
    chanlocs = EEG.chanlocs;
    n_of_trials = EEG.trials;
%     epoch_start = EEG.xmin;
%     epoch_start = -1;
    epoch_start = find(EEG.times >= -1000, 1, 'first');
%     epoch_end = EEG.xmax;
    epoch_end = length(EEG.times);
    dev_on = find(EEG.times == 0);
    clear EEG;
    epoch_inf = epoch_inf(find(epoch_inf(:, 11)), :);
    urPB_old = [epoch_inf(:, 5) (epoch_inf(:, 6) - epoch_inf(:, 5))] / 500;  %urPB: [(time of dev_on) RT]; / 500: frame -> sec
    switch epoch_type
      case 'all'
%         baseln = (epoch_end - epoch_start) * SR + 1;  %length of baseline (WHOLE epoch)
        data_length = 1 : epoch_end;
      case 'dev_on'
%         baseln = (epoch_end - 0) * SR + 1;  %length of baseline (after event)
        data_length = dev_on : epoch_end;
      otherwise
%         baseln = (0 - epoch_start) * SR;  %length of baseline
        data_length = epoch_start : dev_on;  %length of baseline
    end
%     tmp = find(RT <= alert.rt, 1, 'last');  %find # of trials with RT <= 3 sec
%     alert.trials = ceil(tmp * alert.rate);  %the first alert.rate * 100% of these trials: alert
    valid_trial = find(RT >= min_RT & RT <= max_RT);  %trial with RT in desired region
    [RT_s ur_idx] = sort(RT(valid_trial));  %RT_s: sorted RT; ur_idx: original index of each element in RT_s
    alert.trials = ceil(size(RT_s, 2) * alert.rate);  %the first alert.rate * 100% of all trials: alert

    for j = 1 : size(COMP, 2)
      comp = COMP(1, j);
      cls = COMP(2, j);  %which cluster
      PB_mean = [];
      if cls < 0  %not selected after screening
        cls = 0;
      end
%       baseline = reshape(icaact(comp, 1 : baseln, :), baseln, n_of_trials);
      baseline = reshape(icaact(comp, data_length, :), length(data_length), n_of_trials);
%       baseline = reshape(icaact(comp, 1 : baseln, ur_idx), baseln, n_of_trials);  %sort by RT
      %calculate power across frequency
%       help timefreq2004;
      %timefreq2004: the same as timefreq in SCCN, UCSD
      %PB: time frequency array for all trials (freqs * times * trials) **baseline only**
      %freqs: vector of computed frequencies (Hz)
      %times: vector of computed time points (ms)
      [PB, freqs, times] = timefreq2004(baseline, SR, 'wavelet', 0, 'freqs', [min_freq max_freq], ...
          'winsize', 128, 'padratio', 2, 'ntimesout', 100);
      PB = 10 * log10(PB .* conj(PB));  %convert into dB
%       PB_mean = mean(PB, 2);  %calculate avg. spectra
      PB_mean = trimmean(PB, 10, 2);  %calculate avg. spectra
      PB_mean = reshape(PB_mean, size(freqs, 2), n_of_trials);
%       icaact = icaact(:, :, ur_idx);
%       for k = 1 : n_of_trials
%       [ERSP, ITC, PB_meanT, times, freqs] = timef(icaact(comp, :, k), 2000, [-2000 5996], 250, 0, ...
%           'padratio', 4, 'plotersp', 'off', 'plotitc', 'off', 'verbose', 'off'); close gcf;
%       PB_mean = [PB_mean PB_meanT'];
%       end
      PB_mean = PB_mean(find(freqs >= 3 & freqs <= 45), valid_trial);
      freqs = freqs(find(freqs >= 3 & freqs <= 45));

      %sparse moving avg.
      URPB = {'Duration', [], urPB_old(valid_trial, 1)', AXIS_COLOR, 0, 0, '0';
                  'RT', [], urPB_old(valid_trial, 2)', RT_COLOR, 0, 0, '0';};
      for k = 1 : size(FREQ_BAND, 1)
        freq_band = FREQ_BAND{k, 2};
        URPB(k + 2, 1) = FREQ_BAND(k, 1);  %k + 2: already 2 rows
        URPB(k + 2, 2) = FREQ_BAND(k, 2);
%         URPB(k + 2, 3) = {mean(PB_mean(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :))};
        URPB(k + 2, 3) = {trimmean(PB_mean(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :), 10)};
        URPB(k + 2, 4) = FREQ_BAND(k, 3);
        %correlation
        [corr p] = corrcoef(URPB{k + 2, 3}, log10(URPB{2, 3}));
        URPB(k + 2, [5 6]) = {corr(2), p(2)};
        if p(2) > .01
          URPB(k + 2, 7) = {num2str(p(2), '%.02f')};
        else
          URPB(k + 2, 7) = {num2str(p(2), '%.e')};
        end
      end
      %moving average (1-min window, 0: each dev_on)
      URPB_mov = URPB;
      urPB_mov = [];
      urPB_tmp = cell2mat(URPB(:, 3));
      sparse_ylim = [min(min(urPB_tmp(3 : end, :))) max(max(urPB_tmp(3 : end, :)))];
      for k = 1 : stepping : size(urPB_tmp, 2)
        idx = find(urPB_tmp(1, :) > urPB_tmp(1, k) - winsize & urPB_tmp(1, :) <= urPB_tmp(1, k) + winsize);
%         urPB_mov = [urPB_mov mean(urPB_tmp(:, idx), 10, 2)];
        urPB_mov = [urPB_mov trimmean(urPB_tmp(:, idx), 10, 2)];
      end
      sparse_ylim_mov = [min(min(urPB_mov(3 : end, :))) max(max(urPB_mov(3 : end, :)))];
      URPB_mov(:, 3) = mat2cell(urPB_mov, ones(1, size(urPB_mov, 1)), size(urPB_mov, 2));
      clear urPB_mov urPB_tmp;
      %correlation
      for k = 1 : size(FREQ_BAND, 1)
        [corr p] = corrcoef(URPB_mov{k + 2, 3}, log10(URPB_mov{2, 3}));  %k + 2: already 2 rows
        URPB_mov(k + 2, [5 6]) = {corr(2), p(2)};
        if p(2) > .01
          URPB_mov(k + 2, 7) = {num2str(p(2), '%.02f')};
        else
          URPB_mov(k + 2, 7) = {num2str(p(2), '%.e')};
        end
      end

      %sort by RT
      PB_mean = PB_mean(:, ur_idx);
%       PB_mean = 10*log10(PB_mean);
      PB_alert = PB_mean(:, 1 : alert.trials);  %calculating power of alert trials
%       PB_alert = mean(PB_alert, 2) * ones(1, size(valid_trial, 2));  %padding
      PB_alert_mean = trimmean(PB_alert, 10, 2) * ones(1, size(valid_trial, 2));  %padding
      PB_n = PB_mean - PB_alert_mean;  %normalized by power in alert stage
      %moving average
%       help movav;
%       PB_mov = movav(PB_n, [], alert.trials, 1);
%       RT_s_mov = movav(RT_s', [], alert.trials, 1);
      PB_mov = [];
      RT_s_mov = [];
      for k = 1 : movstep : size(PB_n, 2) - (alert.trials - 1)
%         PB_mov = [PB_mov mean(PB_n(:, k : k + alert.trials - 1), 2)];
%         RT_s_mov = [RT_s_mov mean(RT_s(:, k : k + alert.trials - 1), 2)];
        PB_mov = [PB_mov trimmean(PB_n(:, k : k + alert.trials - 1), 10, 2)];
        RT_s_mov = [RT_s_mov trimmean(RT_s(:, k : k + alert.trials - 1), 10, 2)];
      end
      %compute power over different freq bands
      FREQ_INC = {};
      for k = 1 : size(FREQ_BAND, 1)
        freq_band = FREQ_BAND{k, 2};
        FREQ_INC(k, 1) = FREQ_BAND(k, 1);
        FREQ_INC(k, 2) = FREQ_BAND(k, 2);
%         FREQ_INC(k, 3) = {mean(PB_mov(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :))};
        FREQ_INC(k, 3) = {trimmean(PB_mov(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :), 10)};
        FREQ_INC(k, 4) = FREQ_BAND(k, 3);
      end

      %statistics test (2-sample t-test)
      %courtesy Ruey-Song Huang in UCSD
      fprintf('Performing 2-sample T-test (p = %g): \n', p_val);
      P_mask = zeros(size(PB_mov));
      H_mask = P_mask;
      sig_idx = 1 : movstep : floor(size(PB_n, 2) / movstep) - (alert.trials - 1);
      for k = 1 : size(PB_mov, 2)
        PB_tmp = PB_mean(:, sig_idx(k) : sig_idx(k) + alert.trials - 1);
        %corrected p_val: / 2: 2-tail; / size(freqs, 2): freq bins;
%         [H, P] = ttest2(PB_tmp', PB_alert(:, 1 : alert.trials)', p_val / 2 / size(freqs, 2) / alert.trials, 'both');
        [H, P] = ttest2(PB_tmp', PB_alert_mean(:, 1 : alert.trials)', p_val / 2 / size(freqs, 2), 'both');
        H_mask(:, k) = H';
        P_mask(:, k) = P';
      end

%% plot figure for original, baseline, normalized, and moving avg. power images, p-value image, and power increase
      xstep = (size(RT_s, 2) - 1) / xstep_int;
      xstep_mov = (size(RT_s_mov, 2) - 1) / xstep_int;
      xticks_mov = ...
          (2 * .2 - alert.rate - 0.01) / (2 - 2 * alert.rate) * size(RT_s_mov, 2) - 1 : xstep / movstep : size(RT_s_mov, 2);

      figure(1024); hold on;
      subplot('position', [.03 .88 .12 .12]); axis off;  %plot component map
      DR_topoplot(icawinv(:, comp), chanlocs, 'electrodes', 'off', 'shrink', 'force');
      set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');  %set after topoplot to preserve backgound color
      subplot('position', [.15 .88 .8 .12]); axis off;   %title
      switch epoch_type
        case 'all'
          text(.5, .6, {['\color[rgb]' FONT_COLOR 'Power Spectra of']; ...
              ['Component ' int2str(comp) ', ' subj '\_' ExpDate ' (Whole Epoch, ' int2str(size(valid_trial, 2)) ' Trials)']}, ...
              'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
              'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
        case 'dev_on'
          text(.5, .6, {['\color[rgb]' FONT_COLOR 'Power Spectra of']; ...
              ['Component ' int2str(comp) ', ' subj '\_' ExpDate ' (After dev\_on, ' int2str(size(valid_trial, 2)) ' Trials)']}, ...
              'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
              'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
        otherwise
          text(.5, .6, {['\color[rgb]' FONT_COLOR 'Baseline Power Spectra of']; ...
              ['Component ' int2str(comp) ', ' subj '\_' ExpDate ' (' int2str(size(valid_trial, 2)) ' Trials)']}, ...
              'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
              'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
      end

      %plot original power image
%       subplot('position', [.055 .55 .36 .215]); hold on;
      subplot('position', [.08 .605 .36 .19]); hold on;
      imagesc(1 : size(RT_s, 2), freqs, PB_mean, [-40 40]);
      set(gca, 'Xlim', [1 size(RT_s, 2)], 'XTick', xstep + 1 : xstep : size(RT_s, 2) - xstep, ...
          'XTickLabel', (1 : xstep_int - 1) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
          'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
      %mark x ticks and add 2nd x-axis (RT, in the bottom)
      tmp_xtick = roundn(RT_s(xstep + 1 : xstep : size(RT_s, 2) - xstep), -2);
      m = 1;
      for k = xstep + 1 : xstep : size(RT_s, 2) - xstep
        if k ~= 1 && k ~= size(RT_s, 2)
          plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
        end
        text(k, freqs(1), ['\color[rgb]' FONT_COLOR num2str(tmp_xtick(m), '%0.2f')], ...
            'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Top');
        m = m + 1;
      end
      clear m;
      %x label for the ticks on the bottom
      text((1 + size(RT_s, 2)) / 2, freqs(1), {''; 'Reaction Time (sec)'}, ...
          'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Top');
      %mark frequencies
      for k = 10 : 10 : 40
        plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
      end
%       %plot a vertical line with x axis on RT = 3 sec
%       try
%         plot([find(RT_s <= 3, 1, 'last') find(RT_s <= 3, 1, 'last')], get(gca, 'Ylim'), ...
%             'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
%       end
      xlabel('Reaction-Time-Sorted Trial Index (%)', 'VerticalAlignment', 'Baseline');
      %title
%       subplot('position', [.055 .82 .42 .03]); axis off;
      subplot('position', [.08 .85 .36 .03]); axis off;
      text(.5, 0, ['\color[rgb]' FONT_COLOR 'Original Baseline Power Image'], 'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, ...
          'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
      %colorbar
%       subplot('position', [.42 .55 .01 .215]); axis off;
      subplot('position', [.445 .605 .01 .19]); axis off;
      imagesc(1, 33:65, (65 : -1 : 33)', [1 65]);
      title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
          'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
      set(gca, 'XTick', [], 'YTick', 33 : 8 : 65, 'YTickLabel', 40 : -10 : 0, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);

      %plot power image for alert trials (avg. power: baseline)
%       subplot('position', [.055 .305 .36 .215]); hold on;
      subplot('position', [.08 .335 .36 .19]); hold on;
      imagesc(1 : size(PB_alert, 2), [freqs(1) freqs(end)], PB_alert, [-40 40]);
%       set(gca, 'Xlim', [1 size(RT_s, 2)], 'XTick', 1 : xstep : size(RT_s, 2), 'XTickLabel', [], 'XColor', AXIS_COLOR, ...
%           'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
      set(gca, 'Xlim', [1 size(PB_alert, 2)], 'XColor', AXIS_COLOR, ...
          'XTick', (size(PB_alert, 2) - 1) / xstep_int + 1 : (size(PB_alert, 2) - 1) / xstep_int : size(PB_alert, 2) - (size(PB_alert, 2) - 1) / xstep_int, ...
          'XTickLabel', roundn(RT_s((size(PB_alert, 2) - 1) / xstep_int + 1 : (size(PB_alert, 2) - 1) / xstep_int : size(PB_alert, 2) - (size(PB_alert, 2) - 1) / xstep_int), -2), ...
          'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'YTickLabel', [], 'FontSize', AXIS_FSIZE);
      %mark x ticks
      for k = (size(PB_alert, 2) - 1) / xstep_int + 1 : (size(PB_alert, 2) - 1) / xstep_int : size(PB_alert, 2) - (size(PB_alert, 2) - 1) / xstep_int
        plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
      end
      %mark frequencies
      for k = 10 : 10 : 40
        plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
      end
      xlabel('Reaction Time (sec)');
      %title
%       subplot('position', [.055 .52 .42 .03]); axis off;
      subplot('position', [.08 .525 .36 .03]); axis off;
      text(.5, 0, ...
          ['\color[rgb]' FONT_COLOR 'Power Image of Alert Trials\rm\fontsize{' int2str(STITLE_FSIZE - 2) '} (' int2str(size(PB_alert, 2)) ' Trials)'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
      %plot the avg. power of alert trial on the left
%       subplot('position', [.415 .305 .025 .215]);
      subplot('position', [.055 .335 .025 .19]);
      plot(PB_alert_mean(:, 1), freqs(1 : end));
      set(gca, 'Color', BACKGROUND_COLOR, 'FontSize', AXIS_FSIZE, 'XAxisLocation', 'Bottom', ...
          'Xlim', [floor(min(PB_alert_mean(:, 1)) / 5) * 5 ceil(max(PB_alert_mean(:, 1)) / 5) * 5], 'XDir', 'reverse', ...
          'XTick', [floor(min(PB_alert_mean(:, 1)) / 5) * 5 floor(max(PB_alert_mean(:, 1)) / 5) * 5], 'XColor', AXIS_COLOR, ...
          'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : 40, 'YColor', AXIS_COLOR, 'YGrid', 'on', ...
          'Color', BACKGROUND_COLOR, 'FontSize', AXIS_FSIZE);
      ylabel('Frequency (Hz)');
      title({'Avg. Pow.'; '(dB)'}, 'VerticalAlignment', 'Bottom');
      %colorbar
%       subplot('position', [.445 .305 .01 .215]); axis off;
      subplot('position', [.445 .335 .01 .19]); axis off;
      imagesc(1, 33:65, (65 : -1 : 33)', [1 65]);
      title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
          'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
      set(gca, 'XTick', [], 'YTick', 33 : 8 : 65, 'YTickLabel', 40 : -10 : 0, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);

      %plot normalized power image
%       subplot('position', [.055 .06 .36 .215]); hold on;
      subplot('position', [.08 .06 .36 .19]); hold on;
      imagesc(1 : size(RT_s, 2), [freqs(1) freqs(end)], PB_n, [-10 20]);
      set(gca, 'Xlim', [1 size(RT_s, 2)], 'XTick', xstep + 1 : xstep : size(RT_s, 2) - xstep, ...
          'XTickLabel', roundn(RT_s(xstep + 1 : xstep : size(RT_s, 2) - xstep), -2), 'XColor', AXIS_COLOR, ...
          'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
      %mark x ticks
      for k = xstep + 1 : xstep : size(RT_s, 2) - xstep
        plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
      end
      %mark frequencies
      for k = 10 : 10 : 40
        plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
      end
%       %plot a vertical line with x axis on that point
%       try
%         plot([find(RT_s <= 3, 1, 'last') find(RT_s <= 3, 1, 'last')], get(gca, 'Ylim'), ...
%             'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
%       end
      xlabel('Reaction Time (sec)');
      %title
%       subplot('position', [.055 .275 .42 .03]); axis off;
      subplot('position', [.08 .25 .36 .03]); axis off;
      text(.5, 0, ['\color[rgb]' FONT_COLOR 'Normalized Baseline Power Image'], 'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, ...
          'HorizontalAlignment', 'Center', 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
      %colorbar
%       subplot('position', [.42 .06 .01 .215]); axis off;
      subplot('position', [.445 .06 .01 .19]); axis off;
      imagesc(1, 1:65, (65 : -1 : 1)', [1 65]);
      title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
          'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
      set(gca, 'XTick', [], 'YTick', 1 : 64/3 : 65, 'YTickLabel', 20 : -10 : -10, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);

      %plot moving avg. power image (inside contour: p < p_val)
%       subplot('position', [.505 .55 .42 .215]); hold on;
      subplot('position', [.51 .57 .42 .225]); hold on;
      imagesc(1 : size(RT_s_mov, 2), freqs, PB_mov, [-3 6]);
      contour(1 : size(RT_s_mov, 2), freqs, H_mask, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
%       set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov, ...
%           'XTickLabel', (1 : xstep_int - 1) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
%           'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
      set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xticks_mov, ...
          'XTickLabel', (1 : xstep_int - 1) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
          'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
      %mark x ticks
%       for k = xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov
      for k = xticks_mov
        plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
      end
      %mark frequency
      for k = 10 : 10 : 40
        plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
      end
%       %plot a vertical line with x axis on RT = 3 sec
%       try
%         plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
%             'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
%       end
      xlabel('Reaction-Time-Sorted Trial Index (%)', 'VerticalAlignment', 'Baseline');
      %title
%       subplot('position', [.505 .82 .48 .03]); axis off;
      subplot('position', [.51 .85 .42 .03]); axis off;
      text(.5, 0, ['\color[rgb]' FONT_COLOR 'Moving Avg. Baseline Power Image\rm\fontsize {' int2str(STITLE_FSIZE - 2) '} (Countour: \itp\rm < ' num2str(p_val, '%.e') ')'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
      %colorbar
%       subplot('position', [.93 .55 .01 .215]); axis off;
      subplot('position', [.935 .57 .01 .225]); axis off;
      imagesc(1, 1:65, (65 : -1 : 1)', [1 65]);
      title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
          'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
      set(gca, 'XTick', [], 'YTick', 1 : 64/3 : 65, 'YTickLabel', 6 : -3 : -3, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);

      %plot p-value image
%       subplot('position', [.505 .305 .42 .215]); hold on;
      subplot('position', [.51 .315 .42 .225]); hold on;
      imagesc(1 : size(RT_s_mov, 2), freqs, -log10(P_mask), [-2.5 10]);
      contour(1 : size(RT_s_mov, 2), freqs, H_mask, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
%       set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov, 'XTickLabel', [], 'XColor', AXIS_COLOR, ...
%           'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
      set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xticks_mov, 'XTickLabel', [], 'XColor', AXIS_COLOR, ...
          'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
      %mark x ticks
%       for k = xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov
      for k = xticks_mov
        plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
      end
      %mark frequency
      for k = 10 : 10 : 40
        plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
      end
%       %plot a vertical line with x axis on RT = 3 sec
%       try
%         plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
%             'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
%       end
      %title
%       subplot('position', [.505 .52 .48 .03]); axis off;
      subplot('position', [.51 .54 .42 .03]); axis off;
      text(.5, 0, ['\color[rgb]' FONT_COLOR 'P-Value Image\rm\fontsize{' int2str(STITLE_FSIZE - 2) '} (Countour: \itp\rm < ' num2str(p_val, '%.e') ')'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
      %colorbar
%       subplot('position', [.93 .305 .01 .215]); axis off;
      subplot('position', [.935 .315 .01 .225]); axis off;
      imagesc(1, 1:65, (65 : -1 : 1)', [1 65]);
      title(['\color[rgb]' FONT_COLOR '(\itp\rm) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
          'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
      set(gca, 'XTick', [], 'FontSize', CBAR_FSIZE, ...
          'Ylim', [1 52.2], 'YTick', 1 : 25.6 : 52.2, 'YTickLabel', {'1e-10', '1e-5', '1'}, 'YAxisLocation', 'Right');
      %ylabel for the above two figure
%       subplot('position', [.475 .305 .03 .545]); axis off;
      subplot('position', [.48 .315 .03 .565]); axis off;
      text(0, .425, 'Frequency (Hz)', 'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, ...
          'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'Rotation', 90);

      %plot power increase in different frequent bands
%       subplot('position', [.505 .06 .42 .215]); hold on;
      subplot('position', [.51 .06 .42 .225]); hold on;
      legend_string = 'legend(';
      for k = 1 : size(FREQ_INC, 1)
        freq_name = FREQ_INC{k, 1};
        freq_band = FREQ_INC{k, 2};
        freq_inc = FREQ_INC{k, 3};
        freq_color = FREQ_INC{k, 4};
        plot(freq_inc, 'Color', freq_color, 'LineWidth', .5);
        %deal with legend
        legend_string = [legend_string '''' freq_name ' (' int2str(freq_band(1)) '~' int2str(freq_band(2)) ' Hz)'', '];
      end
      plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', .5);  %dummy, for RT
%       set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov, ...
%           'XTickLabel', roundn(RT_s_mov(xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov), -2), 'XColor', AXIS_COLOR, ...
%           'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, 'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
      set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xticks_mov, 'XTickLabel', ...
          roundn(RT_s_mov((2 * .2 - alert.rate - 0.01) / (2 - 2 * alert.rate) * size(RT_s_mov, 2) - 1 : xstep / movstep : size(RT_s_mov, 2)), -2), ...
          'XColor', AXIS_COLOR, 'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, 'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
      %mark x ticks
%       for k = xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov
      for k = xticks_mov
        plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
      end
      %plot a vertical line with x axis on RT = 3 sec
      if find(RT_s_mov <= 3, 1, 'last') ~= size(RT_s_mov, 2) || RT_s_mov(find(RT_s_mov <= 3, 1, 'last')) >= 2.995
        plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
            'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
        legend_string = [legend_string '''RT = 3 sec'', ''Location'', ''NorthWest'');'];
      else
        legend_string = [legend_string '''Location'', ''NorthWest'');'];
      end
      legend_handle = eval(legend_string);
      set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off');
      xlabel('Moving Avg. Reaction Time (sec)');
      ylabel('Power Increase (dB)', 'VerticalAlignment', 'middle');
      title(['\color[rgb]' FONT_COLOR 'Power Increase in Different Frequency Bands'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');

%% plot figure for moving averaged power image and power increase
      figure(1026); hold on;
      subplot('position', [.03 .88 .12 .12]); axis off;  %plot component map
      DR_topoplot(icawinv(:, comp), chanlocs, 'electrodes', 'off', 'shrink', 'force');
      set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');  %set after topoplot to preserve backgound color
      subplot('position', [.15 .88 .8 .12]); axis off;   %title
      switch epoch_type
        case 'all'
          text(.5, .6, {['\color[rgb]' FONT_COLOR 'Moving Averaged Power Spectra of']; ...
              ['Component ' int2str(comp) ', ' subj '\_' ExpDate ' (Whole Epoch, ' int2str(size(valid_trial, 2)) ' Trials)']}, ...
              'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
              'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
        case 'dev_on'
          text(.5, .6, {['\color[rgb]' FONT_COLOR 'Moving Averaged Power Spectra of']; ...
              ['Component ' int2str(comp) ', ' subj '\_' ExpDate ' (After dev\_on, ' int2str(size(valid_trial, 2)) ' Trials)']}, ...
              'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
              'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
        otherwise
          text(.5, .6, {['\color[rgb]' FONT_COLOR 'Moving Averaged Baseline Power Spectra of']; ...
              ['Component ' int2str(comp) ', ' subj '\_' ExpDate ' (' int2str(size(valid_trial, 2)) ' Trials)']}, ...
              'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
              'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
      end

      %plot moving avg. power image (inside contour: p < p_val)
      subplot('position', [.055 .44 .875 .355]); hold on;
      imagesc(1 : size(RT_s_mov, 2), freqs, PB_mov, [-3 6]);
      contour(1 : size(RT_s_mov, 2), freqs, H_mask, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
%       set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov, ...
%           'XTickLabel', (1 : xstep_int - 1) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
%           'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
      set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xticks_mov, ...
          'XTickLabel', (1 : xstep_int - 1) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
          'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
      %mark x ticks
%       for k = xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov
      for k = xticks_mov
        plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
      end
      %mark frequency
      for k = 10 : 10 : 40
        plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
      end
%       %plot a vertical line with x axis on RT = 3 sec
%       try
%         plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
%             'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
%       end
      xlabel('Reaction-Time-Sorted Trial Index (%)', 'VerticalAlignment', 'Baseline');
      ylabel('Frequency (Hz)');
      %title
      subplot('position', [.055 .85 .875 .03]); axis off;
      text(.5, 0, ['\color[rgb]' FONT_COLOR 'Moving Avg. Baseline Power Image\rm\fontsize {' int2str(STITLE_FSIZE - 2) '} (Countour: \itp\rm < ' num2str(p_val, '%.e') ')'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
      %colorbar
      subplot('position', [.935 .44 .01 .355]); axis off;
      imagesc(1, 1:65, (65 : -1 : 1)', [1 65]);
      title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
          'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
      set(gca, 'XTick', [], 'YTick', 1 : 64/3 : 65, 'YTickLabel', 6 : -3 : -3, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);

      %plot power increase in different frequent bands
      subplot('position', [.055 .06 .875 .355]); hold on;
      legend_string = 'legend(';
      for k = 1 : size(FREQ_INC, 1)
        freq_name = FREQ_INC{k, 1};
        freq_band = FREQ_INC{k, 2};
        freq_inc = FREQ_INC{k, 3};
        freq_color = FREQ_INC{k, 4};
        plot(freq_inc, 'Color', freq_color, 'LineWidth', .5);
        %deal with legend
        legend_string = [legend_string '''' freq_name ' (' int2str(freq_band(1)) '~' int2str(freq_band(2)) ' Hz)'', '];
      end
      plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', .5);  %dummy, for RT
%       set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov, ...
%           'XTickLabel', roundn(RT_s_mov(xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov), -2), 'XColor', AXIS_COLOR, ...
%           'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, 'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
      set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xticks_mov, 'XTickLabel', ...
          roundn(RT_s_mov((2 * .2 - alert.rate - 0.01) / (2 - 2 * alert.rate) * size(RT_s_mov, 2) - 1 : xstep / movstep : size(RT_s_mov, 2)), -2), ...
          'XColor', AXIS_COLOR, 'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, 'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
      %mark x ticks
%       for k = xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov
      for k = xticks_mov
        plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
      end
      %plot a vertical line with x axis on RT = 3 sec
      if find(RT_s_mov <= 3, 1, 'last') ~= size(RT_s_mov, 2) || RT_s_mov(find(RT_s_mov <= 3, 1, 'last')) >= 2.995
        plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
            'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
        legend_string = [legend_string '''RT = 3 sec'', ''Location'', ''NorthWest'');'];
      else
        legend_string = [legend_string '''Location'', ''NorthWest'');'];
      end
      legend_handle = eval(legend_string);
      set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off');
      xlabel('Moving Avg. Reaction Time (sec)');
      ylabel('Power Increase (dB)', 'VerticalAlignment', 'middle');
      title(['\color[rgb]' FONT_COLOR 'Power Increase in Different Frequency Bands'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');

%% plot figure for moving averaged power image, power increase, and sparse moving average
      figure(1015); hold on;
      subplot('position', [.03 .88 .12 .12]); axis off;  %plot component map
      DR_topoplot(icawinv(:, comp), chanlocs, 'electrodes', 'off', 'shrink', 'force');
      set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');  %set after topoplot to preserve backgound color
      subplot('position', [.15 .88 .8 .12]); axis off;   %title
      switch epoch_type
        case 'all'
          text(.5, .6, {['\color[rgb]' FONT_COLOR 'Power Spectra and Sparse Moving Average of']; ...
              ['Component ' int2str(comp) ', ' subj '\_' ExpDate ' (Whole Epoch, ' int2str(size(valid_trial, 2)) ' Trials)']}, ...
              'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
              'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
        case 'dev_on'
          text(.5, .6, {['\color[rgb]' FONT_COLOR 'Power Spectra and Sparse Moving Average of']; ...
              ['Component ' int2str(comp) ', ' subj '\_' ExpDate ' (After dev\_on, ' int2str(size(valid_trial, 2)) ' Trials)']}, ...
              'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
              'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
        otherwise
          text(.5, .6, {['\color[rgb]' FONT_COLOR 'Baseline Power Spectra and Sparse Moving Average of']; ...
              ['Component ' int2str(comp) ', ' subj '\_' ExpDate ' (' int2str(size(valid_trial, 2)) ' Trials)']}, ...
              'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
              'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
      end

      %plot moving avg. power image (inside contour: p < p_val)
      subplot('position', [.055 .58 .875 .215]); hold on;
      imagesc(1 : size(RT_s_mov, 2), freqs, PB_mov, [-3 6]);
      contour(1 : size(RT_s_mov, 2), freqs, H_mask, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
%       set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov, ...
%           'XTickLabel', (1 : xstep_int - 1) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
%           'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
      set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xticks_mov, ...
          'XTickLabel', (1 : xstep_int - 1) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
          'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
      %mark x ticks
%       for k = xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov
      for k = xticks_mov
        plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
      end
      %mark frequency
      for k = 10 : 10 : 40
        plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
      end
%       %plot a vertical line with x axis on RT = 3 sec
%       try
%         plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
%             'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
%       end
      xlabel('Reaction-Time-Sorted Trial Index (%)', 'VerticalAlignment', 'Baseline');
      ylabel('Frequency (Hz)', 'VerticalAlignment', 'Baseline');
      %title
      subplot('position', [.055 .85 .875 .03]); axis off;
      text(.5, 0, ['\color[rgb]' FONT_COLOR 'Moving Avg. Baseline Power Image\rm\fontsize {' int2str(STITLE_FSIZE - 2) '} (Countour: \itp\rm < ' num2str(p_val, '%.e') ')'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
      %colorbar
      subplot('position', [.935 .58 .01 .215]); axis off;
      imagesc(1, 1:65, (65 : -1 : 1)', [1 65]);
      title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
          'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
      set(gca, 'XTick', [], 'YTick', 1 : 64/3 : 65, 'YTickLabel', 6 : -3 : -3, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);


      %plot power increase in different frequent bands
      subplot('position', [.055 .335 .875 .215]); hold on;
      legend_string = 'legend(';
      for k = 1 : size(FREQ_INC, 1)
        freq_name = FREQ_INC{k, 1};
        freq_band = FREQ_INC{k, 2};
        freq_inc = FREQ_INC{k, 3};
        freq_color = FREQ_INC{k, 4};
        plot(freq_inc, 'Color', freq_color, 'LineWidth', .5);
        %deal with legend
        legend_string = [legend_string '''' freq_name ' (' int2str(freq_band(1)) '~' int2str(freq_band(2)) ' Hz)'', '];
      end
      plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', .5);  %dummy, for RT
%       set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov, ...
%           'XTickLabel', roundn(RT_s_mov(xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov), -2), 'XColor', AXIS_COLOR, ...
%           'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, 'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
      set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xticks_mov, 'XTickLabel', ...
          roundn(RT_s_mov((2 * .2 - alert.rate - 0.01) / (2 - 2 * alert.rate) * size(RT_s_mov, 2) - 1 : xstep / movstep : size(RT_s_mov, 2)), -2), ...
          'XColor', AXIS_COLOR, 'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, 'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
      %mark x ticks
%       for k = xstep_mov + 1 : xstep_mov : size(RT_s_mov, 2) - xstep_mov
      for k = xticks_mov
        plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
      end
      %plot a vertical line with x axis on RT = 3 sec
      if find(RT_s_mov <= 3, 1, 'last') ~= size(RT_s_mov, 2) || RT_s_mov(find(RT_s_mov <= 3, 1, 'last')) >= 2.995
        plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
            'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
        legend_string = [legend_string '''RT = 3 sec'', ''Location'', ''NorthWest'');'];
      else
        legend_string = [legend_string '''Location'', ''NorthWest'');'];
      end
      legend_handle = eval(legend_string);
      set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off');
      xlabel('Moving Avg. Reaction Time (sec)', 'VerticalAlignment', 'Middle');
      ylabel('Power Increase (dB)', 'VerticalAlignment', 'Middle');
      title(['\color[rgb]' FONT_COLOR 'Power Increase in Different Frequency Bands'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');

      %plot sparse moving avg.
      subplot('position', [.055 .06 .875 .16]); hold on;
%       urPB_latency = URPB{1, 3};
%       urPB_RT = URPB{2, 3};
      urPB_mov_latency = URPB_mov{1, 3};
      urPB_mov_RT = URPB_mov{2, 3};
% %       sparse_xlim = [0 floor(urPB_latency / 500) * 500 + 500];
%       sparse_xlim = [0 urPB_latency];
%       sparse_ylimRT = [0 floor(max(urPB_RT) / 50) * 50 + 50];
%       sparse_xlim = [0 floor(urPB_mov_latency(end) / 500) * 500 + 500];
      sparse_xlim = [0 urPB_mov_latency(end)];
      sparse_ylim_movRT = [0 floor(max(urPB_mov_RT) / 50) * 50 + 50];
%       sparse_ylim = [min(min(sparse_ylim, sparse_ylim_mov)) max(max(sparse_ylim, sparse_ylim_mov))];
%       sparse_ylimRT = [0 max(max(sparse_ylimRT, sparse_ylim_movRT))];
      sparse_ylim = sparse_ylim_mov;
      sparse_ylimRT = sparse_ylim_movRT;
      sparse_ylim = [floor(sparse_ylim(1) / 5) * 5 ceil(sparse_ylim(2) / 5) * 5 + 10];
      for k = 1 : size(FREQ_BAND, 1)
%         urPB_inc = URPB{k + 2, 3};
%         urPB_color = URPB{k + 2, 4};
        urPB_mov_inc = URPB_mov{k + 2, 3};
        urPB_mov_color = URPB_mov{k + 2, 4};
        if k == 1
          %plot original power vs RT
%           [AX1, H11 H12] = plotyy(urPB_latency, urPB_inc, urPB_latency, urPB_RT);
%           set(H11, 'Color', urPB_color, 'LineWidth', .5, 'LineStyle', '--');
%           set(H12, 'Color', RT_COLOR, 'LineWidth', .5, 'LineStyle', '--');
%           set(AX2(1), 'XColor', AXIS_COLOR, 'Xlim', sparse_xlim, 'XTick', [], 'XTickLabel', [], ...
%               'YColor', AXIS_COLOR, 'Ylim', sparse_ylim, 'YTick', [], 'YTickLabel', []);
%           set(AX2(2), 'FontSize', AXIS_FSIZE, 'XColor', AXIS_COLOR, 'Xlim', sparse_xlim, 'XTick', [], 'XTickLabel', [], ...
%               'YColor', RT_COLOR, 'YScale', 'log',  'Ylim', sparse_ylim_movRT, 'YTick', [], 'YTickLabel', []);
          %plot moving avg. power vs RT
          [AX2, H21 H22] = plotyy(urPB_mov_latency, urPB_mov_inc, urPB_mov_latency, urPB_mov_RT);
          set(H21, 'Color', urPB_mov_color, 'LineWidth', .5);
          set(H22, 'Color', RT_COLOR, 'LineWidth', .5);
          set(AX2(1), 'XColor', AXIS_COLOR, 'Xlim', sparse_xlim, 'XTick', [], 'XTickLabel', [], ...
              'YColor', RT_COLOR, 'Ylim', sparse_ylim, 'YTick', [], 'YTickLabel', []);
          set(AX2(2), 'FontSize', AXIS_FSIZE, 'XColor', AXIS_COLOR, 'Xlim', sparse_xlim, 'XTick', [], 'XTickLabel', [], ...
              'YColor', RT_COLOR, 'YScale', 'log',  'Ylim', sparse_ylim_movRT, ...
              'YTick', 10 .^ (-1 : 1 : log10(sparse_ylim_movRT(2))), 'YTickLabel', 10 .^ (-1 : 1 : log10(sparse_ylim_movRT(2))), 'YMinorTick', 'on');
          set(get(AX2(1),'YLabel'), 'String', 'Power (dB)', 'FontSize', AXIS_FSIZE);
          set(get(AX2(2),'YLabel'), 'String', 'Reaction Time (Sec)', 'FontSize', AXIS_FSIZE);
        else
%           %plot original power
%           plot(urPB_latency, urPB_inc, 'Color', urPB_color, 'LineWidth', .5, 'LineStyle', '--');
          %plot moving avg. power  
          plot(urPB_mov_latency, urPB_mov_inc, 'Color', urPB_mov_color, 'LineWidth', .5);
        end
      end
      set(gca, 'COLOR', BACKGROUND_COLOR, 'FontSize', AXIS_FSIZE, 'Box', 'off', ...
          'XColor', AXIS_COLOR, 'Xlim', sparse_xlim, 'XTick', 0 : 1000 : sparse_xlim(2), 'XTickLabel', 0 : 1000 : sparse_xlim(2), ...
          'YColor', AXIS_COLOR, 'Ylim', sparse_ylim, 'YTick', 0 : 10 : sparse_ylim(2), 'YTickLabel', 0 : 10 : sparse_ylim(2));
      set(get(gca,'XLabel'), 'String', 'Experiment Latency (Sec)', 'FontSize', AXIS_FSIZE);
%       ylabel('Power (dB)')
      %title
      subplot('position', [.055 .27 .875 .03]); axis off;
      text(.5, 0, ['\color[rgb]' FONT_COLOR 'Correlation Between Alpha/Theta Power and Reaction Time'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
      %add text
      subplot('position', [.055 .22 .875 .05]); axis off;
      set(gca, 'XMinorGrid', 'on');
      %width of 1st column: .16
      text(0, 0, ['\color[rgb]' FONT_COLOR 'Corr. Coef. (P-Val.)'], ...
          'FontName', FONT_FACE, 'FontSize', FONT_SIZE, 'HorizontalAlignment', 'Left', 'VerticalAlignment', 'baseline');
      colwidth = (1 - .16) / (size(URPB_mov, 1) - 2);  %.16: width of 1st col
      urPB_RT_text = URPB_mov{2, 1};
      urPB_RT_color = mat2str(URPB_mov{2, 4}); urPB_RT_color(1) = '{'; urPB_RT_color(end) = '}';
      for k = 1 : size(URPB_mov, 1) - 2  %-2: the first 2 col: latency and RT
        urPB_title = URPB_mov{k + 2, 1};
        urPB_color = mat2str(URPB_mov{k + 2, 4}); urPB_color(1) = '{'; urPB_color(end) = '}';
        urPB_corr = num2str(URPB_mov{k + 2, 5}, '%.2f');
        urPB_p_val = URPB_mov{k + 2, 7};
        %title
        text(.16 + colwidth * k - colwidth / 2 , .5, ['\color[rgb]' urPB_color urPB_title ...
            '\color[rgb]' FONT_COLOR ' VS log_1_0(\color[rgb]' urPB_RT_color urPB_RT_text '\color[rgb]' FONT_COLOR ')'], ...
            'FontName', FONT_FACE, 'FontSize', FONT_SIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline');
        %corr coef and p-val
        text(.16 + colwidth * k - colwidth / 2 , 0, ['\color[rgb]' FONT_COLOR urPB_corr ' (' urPB_p_val ')'], ...
            'FontName', FONT_FACE, 'FontSize', FONT_SIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline');
      end
      URPB(:, 7) = [];
      URPB_mov(:, 7) = [];

%% save all figures and necessary variables
      save([FilePathOld 'RS' SL epoch_type SL MN SL 'IC' num2str(cls, '%02d') SL Set '_PBaseRT_' num2str(comp, '%02d') rj '.mat'], ...
          'icawinv', 'chanlocs', 'PB', 'PB_mean', 'PB_alert', 'PB_alert_mean', 'PB_n', 'PB_mov', 'freqs', 'RT', 'RT_s', 'RT_s_mov', 'FREQ_INC', 'H_mask', 'P_mask', 'p_val', 'URPB', 'URPB_mov');
%       save(['~/' Set '_PBaseRT_' num2str(comp, '%02d') rj '.mat'], ...
%           'icawinv', 'chanlocs', 'PB', 'PB_mean', 'PB_alert', 'PB_alert_mean', 'PB_n', 'PB_mov', 'freqs', 'RT', 'RT_s', 'RT_s_mov', 'FREQ_INC', 'H_mask', 'P_mask', 'p_val', 'URPB', 'URPB_mov');
      figure(1024);
      if ~strcmp(epoch_type, '_all') && ~strcmp(epoch_type, '_dev_on')
      saveas(1024, [FilePathOld 'RS' SL epoch_type SL MN SL 'IC' num2str(cls, '%02d') SL Set '_PBaseRT_' num2str(comp, '%02d') rj '_method.fig']);
%       saveas(1024, ['~/' Set '_PBaseRT_' num2str(comp, '%02d') rj '_method.fig']);
      end
      print('-dpng', [FilePathOld 'RS' SL epoch_type SL MN SL 'IC' num2str(cls, '%02d') SL Set '_PBaseRT_' num2str(comp, '%02d') rj '_method.png']);
%       saveas(1024, ['~/' Set '_PBaseRT_' num2str(comp, '%02d') rj '_method.fig']);
%       print('-dpng', ['~/'  Set '_PBaseRT_' num2str(comp, '%02d') rj '_method.png']);
      figure(1026);
      if ~strcmp(epoch_type, '_all') && ~strcmp(epoch_type, '_dev_on')
      saveas(1026, [FilePathOld 'RS' SL epoch_type SL MN SL 'IC' num2str(cls, '%02d') SL Set '_PBaseRT_' num2str(comp, '%02d') rj '_result.fig']);
%       saveas(1026, ['~/' Set '_PBaseRT_' num2str(comp, '%02d') rj '_result.fig']);
      end
      print('-dpng', [FilePathOld 'RS' SL epoch_type SL MN SL 'IC' num2str(cls, '%02d') SL Set '_PBaseRT_' num2str(comp, '%02d') rj '_result.png']);
%       saveas(1026, ['~/' Set '_PBaseRT_' num2str(comp, '%02d') rj '_result.fig']);
%       print('-dpng', ['~/'  Set '_PBaseRT_' num2str(comp, '%02d') rj '_result.png']);
      figure(1015);
      if ~strcmp(epoch_type, '_all') && ~strcmp(epoch_type, '_dev_on')
      saveas(1015, [FilePathOld 'RS' SL epoch_type SL MN SL 'IC' num2str(cls, '%02d') SL Set '_PBaseRT_' num2str(comp, '%02d') rj '_sparse.fig']);
%       saveas(1015, ['~/' Set '_PBaseRT_' num2str(comp, '%02d') rj '_sparse.fig']);
      end
      print('-dpng', [FilePathOld 'RS' SL epoch_type SL MN SL 'IC' num2str(cls, '%02d') SL Set '_PBaseRT_' num2str(comp, '%02d') rj '_sparse.png']);
%       saveas(1015, ['~/' Set '_PBaseRT_' num2str(comp, '%02d') rj '_sparse.fig']);
%       print('-dpng', ['~/'  Set '_PBaseRT_' num2str(comp, '%02d') rj '_sparse.png']);
      close(1024);
      close(1026);
      close(1015);
    end
%%
  else
    fprintf('%s: not valid, check set name or condition (motion/motionless).\n', plot_set);
  end
end