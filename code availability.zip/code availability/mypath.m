addpath(genpath('/home/poem/'));
addpath(genpath('/home/eeglab5.03/'));