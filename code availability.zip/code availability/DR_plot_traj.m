% Plot deviation, for Drowsiness
% Required input: event file (subj_ExpDate_event.txt)
% Output: subj_ExpDate_driving_err.mat, containing moving averaged trajectory and latency
% by poem, 20080430

% clear all;
FilePath = '';
if isunix
  mypath;
%   FilePath = '~/Drowsiness/';
  FilePath = '~/liang/';
  SL = '/';
end
% SET = {
%        's18_060120';
%        's18_060121';
%        's18_060228';
%        's22_060718A';
%        's23_060707';
%        's23_060711B';
%        's23_060707n';
%        's23_060711m';
%        's31_061020m';
%        's31_061103n';
%        's41_070117';
%        's48_080501n';
%        's48_080516m';
%        's22_080513m';
%        's41_080520m';
%        's49_080527n';
%        's22_080529n';
%        's41_080530n';
%        's49_080602m';
%        's50_080725n';
%        's50_080731m';
%        's54_081209n';
%        's22_090120n';
%       };
SET = {
%        's01_051020';
%        's01_061102';
%        's05_060308';
%        's05_061019';
%        's05_061101';
%        's11_060920';
%        's16_060717';
%        's18_060303';
%        's28_060707';
%        's30_061121';
%        's31_061103';
%        's31_061020';
%        's32_061031';
%        's35_070322';
       's36_061130';
%        's36_061221';
%        's39_070117';
%        's40_070116';
%        's40_070124';
%        's40_070207';
%        's41_061225';
%        's42_061222';
%        's42_070105';
%        's43_070205';
%        's43_070208';
%        's44_070205';
%        's44_070209';
%        's44_070325';
%        's45_070321';
%        's44_070126';
%        's36_061122';
%        's45_070307';
%        's37_061213';
      };
SR = 500;  %ORIGINAL sampling rate. 250 => 250 Hz
% window = 90;  %90-sec window
% stepping = 2;  %2-sec stepping
COLOR = {
         [.5 .5 .5];  %raw traj.
%          [0 0 0];  %moving avg. traj.
         [1 0 0];  %dev_on (left)
         [1 0 0];  %dev_on (right)
         [0 1 0];  %act_on
         [0 0 1];  %act_off (correct)
%          [.5 .5 .5];  %act_off (wrong)
        };
FilePathOld = FilePath;

for i = 1 : size(SET, 1)
  FilePath = FilePathOld;
  Set = SET{i};
  [subj ExpDate] = strtok(Set, '_'); ExpDate = ExpDate(2 : end);
  FilePath = [FilePath Set SL];

  %load modified event file
  try
%     evt = load([FilePath 'single/' Set '_event_new.txt']);  %sxx_yymmdd_event_new.txt
    evt = load([FilePath Set '_event.txt']);  %sxx_yymmdd_event_new.txt
  catch
    error('Fail to load modified event file');
  end
  evt(:, 2) = mod(evt(:, 2), 1000);
  %fix the first and the last events
  if evt(1, 2) > 250  %1st point
    evt(1, 2) = evt(2, 2);
  end
  if evt(end, 2) > 250 & (evt(end, 2) ~= 254 | evt(end, 2) ~= 255)  %last point
    evt(end, 2) = evt(end - 1, 2);
  end
  %fix index of event
  if ~isequal(evt(:, 1), (1 : size(evt(:, 1), 1))')
    evt(:, 1) = (1 : size(evt(:, 1), 1))';
  end
  %extract event mark
  evt_tmp = find(evt(:, 2) >= 250);  %evt: event file
  evt_mark = evt(evt_tmp, [1 2 5]);
  help DR_check_incomplete;
  [evt_mark evt_tmp] = DR_check_incomplete(evt_mark, 2);
  if ~isempty(evt_tmp)
    fprintf('Manually remove incomplete trials: ');
    keyboard;
  end
  %after this step, evt_mark should be [(251/252) - 253 - (254/255)] + [(251/252) - 253 - (254/255)] ...
  
  %save information of each epoch (behavior time)
%   epoch_inf = [];
%   for j = 1 : 3 : size(evt_mark, 1)
%     epoch_inf_tmp = [
%                      (j + 2) / 3  %evt_idx
%                      evt_mark(j, 3),  %latency of dev_on
%                      evt_mark(j + 1, 3),  %latency of act_on
%                      evt_mark(j + 2, 3),  %latency of dev_off
%                      evt_mark(j + 1, 3) - evt_mark(j, 3),  %RT
%                      evt_mark(j, 1),  %original index of dev_on
%                      evt_mark(j + 1, 1),  %original index of act_on
%                      evt_mark(j + 2, 1),  %original index of dev_off
%                     ]';
%     epoch_inf = [epoch_inf; epoch_inf_tmp];
%   end
%   clear epoch_inf_tmp;

  %extract different time point in each deviation
  evt_tmp = find(evt_mark(:, 4) == 1);
  dev_on = evt_mark(evt_tmp, 1 : 3);
  evt_tmp = find(evt_mark(:, 4) == 2);
  dev_peak = evt_mark(evt_tmp, 1 : 3);
  evt_tmp = find(evt_mark(:, 4) == 3);
  dev_off = evt_mark(evt_tmp, 1 : 3);

  %take out event marks and interpolate car's position
  for j = 2 : size(evt, 1)  %1st column: trajectory
    if evt(j, 2) == 251 || evt(j, 2) == 252  %dev_on
      if evt(j, 2) == 251
        direct = 0;  %left
      else
        direct = 1;  %right
      end
      evt(j, 2) = evt(j - 1, 2);
    elseif evt(j, 2) == 253 || evt(j, 2) == 254 || evt(j, 2) == 255  %act_on & dev_off
      if j > 10
        Prev = find(evt(j - 10 : j - 1, 2) < 250, 1, 'last');
        Prev = evt(j - 11 + Prev, 2);
      else
        Prev = find(evt(1 : j - 1, 2) < 250, 1, 'last');
        Prev = evt(Prev, 2);
      end
      if j <= size(evt, 1) - 10
        Next = find(evt(j + 1 : j + 10, 2) < 250, 1, 'first');
      else
        Next = find(evt(j + 1 : end, 2) < 250, 1, 'first');
      end
      Next = evt(j + Next, 2);
      if evt(j, 2) == 253
        if direct == 0  %left
          evt(j, 2) = min(Prev, Next);
        else  %right
          evt(j, 2) = max(Prev, Next);
        end
%       if (evt(j - 1, 2) < 250 & evt(j + 1, 2) < 250)
%         evt(j, 2) = round((evt(j + 1, 2) + evt(j - 1, 2)) / 2);
%       elseif (evt(j - 1, 2) < 250 & evt(j + 1, 2) >= 250)
%         evt(j, 2) = evt(j - 1, 2);
%       elseif  (evt(j - 1, 2) >= 250 & evt(j + 1, 2) < 250)
%         evt(j, 2) = evt(j + 1, 2);
%       else
%         evt(j, 2) = evt(j - 2, 2);
%       end
      else
        evt(j, 2) = round((Prev + Next) / 2);
%       evt(j, 2) = evt(j + 1, 2);
      end
    end
  end
  %plot the original trajectory
  figure; hold on;
  %for legend
  for j = 1% : 2
    cl = COLOR{j};
    plot(0, 0, 'Color', cl);
  end
  for j = 2 : 5
    cl = COLOR{j};
%     plot(0, 0, 'Color', cl, 'LineStyle', 'none', 'Marker', 'o', 'MarkerEdgeColor', cl, 'MarkerEdgeColor', cl);
    plot(2500, 200, 'LineStyle', 'none', 'Marker', '.', 'MarkerEdgeColor', cl, 'MarkerFaceColor', cl);
  end
  plot(2500, 200, 'LineStyle', 'none', 'Marker', '.', 'MarkerEdgeColor', 'w', 'MarkerFaceColor', 'w');
  axis off; axis on;
  %trajectory
  plot(evt(:, 5) / SR, evt(:, 2), 'color', [.5 .5 .5], 'LineWidth', 1);

  %plot moving-averaged trajectory
  % op_arr = DR_movavg(ip_arr, window, stepping, SR, mov_key)
  %   Input parameters:
  %     ip_arr: m * n array
  %     window: length of window in sec.
  %     stepping: the next window is step sec. after ini. time of this window
  %     SR: sampling rate
  %     mov_key: the column of time point
  %   Output parameters:
  %     op_arr: p * (n + 1) array
  %       1st column: index
  %       qth column: the same as (q - 1)th column of ip_arr
%   mov_traj = DR_movavg([evt(:, 2) evt(:, 5)], 90, 2, SR, 2);
%   plot(mov_traj(:, 3) / SR, mov_traj(:, 2), 'k', 'LineWidth', 3);
  for j = 1 : 4
    cl = COLOR{j + 1};
    evt_tmp = find(evt_mark(:, 2) == 250 + j);  %left dodge
    for k = 1 : size(evt_tmp)
      plot(evt(evt_mark(evt_tmp(k), 1), 5) / SR, evt(evt_mark(evt_tmp(k), 1), 2), 'Marker', 'o', 'MarkerFaceColor', cl, ...
          'MarkerEdgeColor', cl, 'MarkerSize', 2);
    end
  end
%   legend('Raw Trajectory', 'Moving Avg. Trajectory', 'Deviation Onset (Left)', 'Deviation Onset (Right)', ...
%       'Response Onset', 'Response Offset (Correct)', 'Response Offset (Wrong)', 'Location', 'SouthEast');
%   legend('Raw Trajectory', 'Moving Avg. Trajectory', 'Deviation Onset (Left)', 'Deviation Onset (Right)', ...
%       'Response Onset', 'Response Offset', 'Location', 'SouthEast');
  legend('Raw Trajectory', 'Deviation Onset (Left)', 'Deviation Onset (Right)', ...
      'Response Onset', 'Response Offset', 'Location', 'SouthEast');
  title(['Trajectory of ' subj '\_' ExpDate]);
  xlabel('Time (sec)');
  ylabel('Position (pt)');
  hold off;
  keyboard;
%   saveas(gcf, [FilePath Set '_raw_traj'], 'fig');
%   print('-dpng', [FilePath Set '_raw_traj']);
  close(gcf);

%   %fix value of trajectory
%   traj = evt(:, [1 2 5]);
%   err = traj;
%   if size(dev_on, 1) == size(dev_off, 1)
%     iter = size(dev_on, 1);
%   else
%     iter = min(size(dev_on, 1), size(dev_off, 1));
%   end
%   for j = 1 : iter
%     if j == 1
%       err(1 : dev_on(j, 1) - 1, 2) = 0;  %set position before the 1st dev. to 0
%     else
%       err(dev_off(j - 1, 1) : dev_on(j, 1) - 1, 2) = 0;  %set position between dev. to 0
%     end
%     err(dev_on(j, 1) : dev_off(j, 1), 2) = abs(err(dev_on(j, 1) : dev_off(j, 1), 2)  - err(dev_on(j, 1), 2));
% %     else
% %       err(dev_off(j - 1, 1) + 1 : dev_off(j, 1), 2) = ...
% %           abs(err(dev_off(j - 1, 1) + 1 : dev_off(j, 1), 2)  - err(dev_on(j, 1), 2));
% %     end
%   end
%   %set max. dev. = 85
%   for j = 1 : size(err, 1)
%     if err(j, 2) > 85
%       err(j, 2) = 85;
%     end
%   end
%   %moving avg (90-sec window, step 2 sec)
%   mov_err = DR_movavg([err(:, 2), err(:, 3)], 90, 2, SR, 2);
%   figure; hold on;
% %   plot(err(:, 3) / SR, err(:, 2), 'b');
%   plot(mov_err(:, 3) / SR, mov_err(:, 2), 'b');
% %   legend('Actual Driving Err', 'Moving Averaged Err', 'Location', 'Best');
%   title(['Driving Error of ' subj '\_' ExpDate ' (Moving Averaged)']);
%   xlabel('Time (sec)');
%   ylabel('Position (pt)');
%   ylim([0 90]);
%   hold off;
%   print('-dpng', [FilePath Set '_driving_err.png']);
%   saveas(gcf, [FilePath Set '_driving_err'], 'fig');
%   close(gcf);
% 
%   %plot sorted trial
%   sort_RT = sortrows(epoch_inf, 5); sort_RT(:, 1) = [1 : size(sort_RT, 1)]';
%   figure;
%   plot(sort_RT(:, 5) / SR, sort_RT(:, 1) / sort_RT(end, 1) * 100);
%   %ylim([0 6]);
%   xlabel('Reaction Time (sec)');
%   ylabel('% of Trials');
%   title(['Sorted Reaction Time of ' subj '\_' ExpDate]);
%   print('-dpng', [FilePath Set '_sorted_RT.png']);
%   saveas(gcf, [FilePath Set '_sorted_RT'], 'fig');
%   close(gcf);
% 
%   save([FilePath Set '_driving_err'], 'epoch_inf', 'traj', 'err', 'mov_err', 'SR');  %sxx_yymmdd_driving_err.mat
end