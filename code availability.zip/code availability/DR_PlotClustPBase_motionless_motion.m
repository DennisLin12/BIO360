%power spectra cross subjects (comparing motionless and motion)
%mostly base on RS_powbase
%This version: 200908 by poem

%% set parameters (initialize)
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/RS/';  %directory
  SL = '/';
end
DR_PBase_setup;  %load setup file
%datasets
PLOT_SET = {
            's01_061102';  %motionless
            's05_061101';  %motionless
            's31_061103';  %motionless
            's32_061031';  %motionless
            's35_070322';  %motionless
            's36_061221';  %motionless
%             's37_071213';  %motionless
%             's39_070117';  %motionless
            's40_070207';  %motionless
            's41_061225';  %motionless
            's42_070105';  %motionless
            's43_070208';  %motionless
            's44_070325';  %motionless
            's05_061019';  %motion
            's31_061020';  %motion
            's35_070115';  %motion
            's36_061122';  %motion
%             's39_061218';  %motion
            's40_070131';  %motion
            's43_070202';  %motion
%             's44_070126';  %motion
            's44_070209';  %motion
           };
MN = {'motionless'; 'motion'};
p_val = 1E-10;
for i = 1 : size(MN, 1)  %deciding color
  mn = MN{i};
  switch mn
    case 'motionless'
      mn_color = '{0 0 1}';  %blue
    case 'motion'
      mn_color = '{1 0 0}';  %red
    otherwise
      mn_color = '{0 1 0}';  %green
  end
  com = sprintf('MN_COLOR%d = mn_color;', i); eval(com);
  com = sprintf('%s = struct;', mn); eval(com);
end
movstep = 1;  %stepping for moving avg
xstep_int = 5;
FilePathOld = FilePath;
epoch_type = '';  %'' => baseline, all => all epoch, dev_on => after dev_on
try
  close(1058);
end
noband = '';  %1: alpha + theta
SD = '';
rj = '_rj';
ylim_tmp = [-2 7];
nor = 1;
switch noband
  case '1'
    FREQ_BAND(3, :) = [];
end
%font size
FONT_SIZE = 12;  %text
TITLE_FSIZE = 14;  %title
STITLE_FSIZE = 12;  %subtitle
AXIS_FSIZE = 12;  %axis
CBAR_FSIZE = 12;  %color bar

%% modify database (create new database from the original one)
for i = 1 : size(MN, 1)
  com = sprintf('SET%d = {}; SUBJ%d = {};', i, i); eval(com);
end 
%split datasets to motionless and motion subsets
for i = 1 : size(SET, 1)
  if strcmp(SET{i, 3}, MN{1})
    SET1 = [SET1; SET(i, :)];
    SUBJ1 = [SUBJ1; {strtok(SET{i, 1}, '_')}];
  elseif strcmp(SET{i, 3}, MN{2})
    SET2 = [SET2; SET(i, :)];
    SUBJ2 = [SUBJ2; {strtok(SET{i, 1}, '_')}];
  end
end
%find the subjects who have done motionless and motion sessions (in database)
SUBJ_tmp = intersect(SUBJ1, SUBJ2);
for i = 1 : size(MN, 1)
  com =  sprintf('SET%d = SET%d(ismember(SUBJ%d, SUBJ_tmp), :);', i, i, i); eval(com);
end
clear SET SUBJ_tmp;
%till now, new database = SET1 and SET2

%% check subject list and split it into sub-list according to condition
for i = 1 : size(MN, 1)
  com = sprintf('PLOT_SET%d = {}; SUBJ%d = {};', i, i); eval(com);
end
for i = 1 : size(PLOT_SET, 1)
  %check if the plot_set is valid
  plot_set = PLOT_SET{i};
  check_ok = false;
  for j = 1 : size(MN, 1)  
    if check_ok  %in previous dataset
      break;
    else
      com = sprintf('SET_tmp = SET%d;', j); eval(com);
      for k = 1 : size(SET_tmp, 1)
        Set = SET_tmp{k, 1};
        condition = SET_tmp{k, 3};
        if strcmp(Set, plot_set)  %dataset found in database, assign to correct subset
          check_ok = true;
            com = sprintf('PLOT_SET%d = [PLOT_SET%d; SET_tmp(k, :)];', j, j); eval(com);
            com = sprintf('SUBJ%d = [SUBJ%d; {strtok(Set, ''_'')}];', j, j); eval(com);
          break;
        end
        if k == size(SET_tmp, 1) && j == size(MN, 1)  %not able to find dataset
          fprintf('%s: not valid. Subject Not finishing all experiments or error set name/condition.\n', plot_set);
        end
      end                                                                                                                                                                                                    
    end
  end
end
SUBJ_tmp = intersect(SUBJ1, SUBJ2);
for i = 1 : size(MN, 1)
  com = sprintf('PLOT_SET%d = PLOT_SET%d(ismember(SUBJ%d, SUBJ_tmp), :);', i, i, i); eval(com);
end
clear PLOT_SET SUBJ_tmp;

%% assign component to cluster
for i = 1 :size(ClsLabel, 1)
  for j = 1 : size(MN, 1)
    com = sprintf('IC%02d_%d = {ClsLabel{%d}};', i, j, i); eval(com);
%     com = sprintf('subj_seq%02d_%d = {};', i, j); eval(com);  %# of sessions in a cluster
    com = sprintf('session_count%02d_%d = 0;', i, j); eval(com);
  end
end
for i = 1 : size(MN, 1)
  com = sprintf('SET_tmp = SET%d;', i); eval(com);  %database
  com = sprintf('PLOT_SET_tmp = PLOT_SET%d;', i); eval(com);  %plot list
  for j = 1 : size(PLOT_SET_tmp, 1)
    plot_set = PLOT_SET_tmp{j};
    for k = 1 : size(SET_tmp, 1)
      Set = SET_tmp{k, 1};
      if strcmp(Set, plot_set)  %dataset found in database, assign to correct subset
        oldcls = zeros(1, size(ClsLabel, 1));  %register to memorize if the cluster shown before
        COMP = SET_tmp{k, 2};
        for m = 1 : size(COMP, 2)  %assign to cluster
          comp = COMP(1, m);  %componet #
          comp_cls = COMP(2, m);  %which cluster
          if comp_cls > 0
            IC_tmp = {Set, comp};
            com = sprintf('IC%02d_%d = [IC%02d_%d IC_tmp];', comp_cls, i, comp_cls, i); eval(com);
            if ~oldcls(comp_cls)  %first appearing
              oldcls(comp_cls) = true;
              com = sprintf('session_count%02d_%d = session_count%02d_%d + 1;', comp_cls, i, comp_cls, i); eval(com);
            end
          end
        end
        break;
      end
    end
  end
end

% process data
for i = 1 : size(ClsLabel, 1)
  RT_s_overlap = [0 Inf];
  for j = 1 : size(MN, 1)
    mn = MN{j};
    com = sprintf('%s = struct;', mn); eval(com);
    FilePath = FilePathOld;
    com = sprintf('IC_tmp = IC%02d_%d;', i, j); eval(com);  %IC_tmp: sorted by subject list given above
    com = sprintf('session_count = session_count%02d_%d;', i, j); eval(com);
    subj_seq = {};
    session_id = 0;  %the same dataset => session id NOT the same across clusters
    old_set = '';

    %load icawinv for plotting component maps
    tmp_icawinv = load([FilePath mn SL 'IC' num2str(i, '%02d') '_component_' cls_ver '_' mn], 'icawinv', 'std_chanlocs');  %tmp_set.PB_mean: row: freq, col: trial
    icawinv = tmp_icawinv.icawinv;
    chanlocs = tmp_icawinv.std_chanlocs;
    clear tmp_icawinv;
    FilePath = [FilePath epoch_type SL mn SL 'IC' num2str(i, '%02d') SL];
    cls_length = (size(IC_tmp, 2) - 1) / 2;
    allAlpha = [];
    allTheta = [];
    allRT_s = [];
    RT_s = [];
    PB_mean = [];
    PB_alert_subj = [];  %baseline power for alert trials of each subject. only for the first normalize method
    if nor == 3 || nor == 4
      PB_alert = 0;
    else
      PB_alert = [];
    end
    PB_n = [];
    for k = 1 : cls_length
      plot_set = IC_tmp{1, 2 * k};
      plot_comp = IC_tmp{1, 2 * k + 1};
      tmp_cell = {};  %for storing session
      tmp_arr = [];  %for storing session ID (easy to access when calculating);
      %counting session id
      if ~strcmp(old_set, plot_set)  %new dataset
        session_id = session_id + 1;
      end
      %load dataset
      if ~isempty(epoch_type)
        tmp_set = load([FilePath plot_set '_PBaseRT_' num2str(plot_comp, '%02d') rj '_' epoch_type], 'RT_s', 'PB_mean', 'freqs');  %tmp_set.PB_mean: row: freq, col: trial
      else
        tmp_set = load([FilePath plot_set '_PBaseRT_' num2str(plot_comp, '%02d') rj], 'RT_s', 'PB_mean', 'freqs');  %tmp_set.PB_mean: row: freq, col: trial
      end
      RT_s = [RT_s tmp_set.RT_s];
      PB_mean = [PB_mean tmp_set.PB_mean];
      freqs = tmp_set.freqs;
      %recording session according to trials (length of PB_mean or RT_s)
      tmp_cell(1 : size(tmp_set.PB_mean, 2)) = {plot_set};
      tmp_arr(1 : size(tmp_set.PB_mean, 2)) = session_id;
      tmp_arr_cell = mat2cell(tmp_arr, ones(1, size(tmp_arr, 1)), ones(1, size(tmp_arr, 2)));
      subj_seq = [subj_seq [tmp_cell; tmp_arr_cell]];

      %normalize
      switch nor
        case 1
          alert.trials = ceil(size(tmp_set.PB_mean, 2) * alert.rate);  %find baseline
          PB_alert_tmp = tmp_set.PB_mean(:, 1 : alert.trials);  %calculating power of alert trials
          PB_alert_tmp = mean(PB_alert_tmp, 2) * ones(1, length(tmp_set.RT_s));  %padding
          PB_n_tmp = tmp_set.PB_mean - PB_alert_tmp;  %normalized by power in alert stage
          PB_alert = [PB_alert PB_alert_tmp];
          PB_n = [PB_n PB_n_tmp];
          if k == cls_length  %finish loading dataset, calculate baseline
            [RT_s ur_idx] = sort(RT_s, 2);  %sort by RT
            PB_mean = PB_mean(:, ur_idx);
            PB_n = PB_n(:, ur_idx);
            PB_alert = PB_alert(:, ur_idx);
            subj_seq = subj_seq(:, ur_idx);
            subj_seq_id = cell2mat(subj_seq(2, :));
            RT_s_overlap = [max(RT_s(1), RT_s_overlap(1)) min(RT_s_overlap(2), RT_s(end))];
          end
          if ~strcmp(old_set, plot_set)
            PB_alert_subj = [PB_alert_subj PB_alert_tmp(:, 1)];
          end
        case 2
          if k == cls_length  %finish loading dataset, calculate baseline
            [RT_s ur_idx] = sort(RT_s, 2);  %sort by RT
            PB_mean = PB_mean(:, ur_idx);
            alert.trials = ceil(size(PB_mean, 2) * alert.rate);  %find baseline
            PB_alert = PB_mean(:, 1 : alert.trials);  %calculating power of alert trials
            PB_alert_mean = trimmean(PB_alert, 10, 2) * ones(1, length(RT_s));  %padding
            PB_n = PB_mean - PB_alert_mean;  %normalized by power in alert stage
          end
        case {3, 4}
          alert.trials = ceil(size(tmp_set.PB_mean, 2) * alert.rate);  %find baseline
          PB_alert_tmp = tmp_set.PB_mean(:, 1 : alert.trials);  %calculating power of alert trials
          if nor == 4
            PB_alert = PB_alert + length(tmp_set.RT_s) * mean(PB_alert_tmp, 2);  %weighted sum
          else
            PB_alert = PB_alert + mean(PB_alert_tmp, 2);  %direct sum
          end
          if k == cls_length  %finish loading dataset, calculate baseline
            [RT_s ur_idx] = sort(RT_s, 2);  %sort by RT
            PB_mean = PB_mean(:, ur_idx);
            if nor == 4
              PB_alert_mean = PB_alert / length(RT_s) * ones(1, length(RT_s));
            else
              PB_alert_mean = PB_alert / cls_length * ones(1, length(RT_s));  %averaging baseline and padding
            end
            PB_n = PB_mean - PB_alert_mean;
          end
      end  %switch
      old_set = plot_set;
    end  %k
    alert.trials = ceil(size(RT_s, 2) * alert.rate);

    %moving average
    PB_mov = [];
    RT_s_mov = [];
    for k = 1 : movstep : size(PB_n, 2) - (alert.trials - 1)
      PB_mov = [PB_mov trimmean(PB_n(:, k : k + alert.trials - 1), 10, 2)];
      RT_s_mov = [RT_s_mov trimmean(RT_s(:, k : k + alert.trials - 1), 10, 2)];
    end

    %compute power over different freq bands
    FREQ_INC = {};
    for k = 1 : size(FREQ_BAND, 1)
      freq_band = FREQ_BAND{k, 2};
      FREQ_INC(k, 1) = FREQ_BAND(k, 1);
      FREQ_INC(k, 2) = FREQ_BAND(k, 2);
      FREQ_INC(k, 3) = FREQ_BAND(k, 3);
      FREQ_INC(k, 4) = {trimmean(PB_mov(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :), 10, 1)};
      FREQ_INC(k, 5) = {std(PB_mov(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :), 0, 1)};
      %curve fitting
      tmp_inc_freq = trimmean(PB_n(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :), 10, 1);
      [tmp_p tmp_S] = polyfit(RT_s, tmp_inc_freq, curfit_order);
      tmp_p_val = polyval(tmp_p, RT_s);
      tmp_p_mov = [];
      for m = 1 : movstep : size(PB_n, 2) - (alert.trials - 1)
        tmp_p_mov = [tmp_p_mov trimmean(tmp_p_val(:, m : m + alert.trials - 1), 10, 2)];
      end  %m
      FREQ_INC(k, 8) = {tmp_p};
      FREQ_INC(k, 9) = {tmp_S};
      FREQ_INC(k, 10) = {tmp_p_mov};
    end  %k
  
    %statistics
    fprintf('Performing 2-sample T-test (p = %g): \n', p_val);
    P_mask = zeros(size(PB_mov));
    H_mask = P_mask;
    sig_idx = 1 : movstep : floor(size(PB_n, 2) / movstep) - (alert.trials - 1);
    for k = 1 : size(PB_mov, 2)
      PB_tmp = PB_mean(:, sig_idx(k) : sig_idx(k) + alert.trials - 1);
      PB_alert_tmp = 0;
      if nor == 1
        subj_seq_id_tmp = subj_seq_id(:, sig_idx(k) : sig_idx(k) + alert.trials - 1);
        %counting how many trials of each subject in this window
        n_of_subj_win = 0;  %number of subjects in a moving window
        for m = 1 : session_count
          n_of_trial = length(find(subj_seq_id_tmp == m));
          if ~isempty(n_of_trial)
            PB_alert_tmp = PB_alert_tmp + PB_alert_subj(:, m) * n_of_trial;  %adding the power of alert trials according to propotion
            n_of_subj_win = n_of_subj_win + 1;
          else
            keyboard;
          end
        end
        PB_alert_tmp = PB_alert_tmp * ones(1, alert.trials) / alert.trials;
      else
        n_of_subject_win = 1;  %use the same baseline, no need do consider the difference between subjects
        PB_alert_tmp = PB_alert(:, 1 : alert.trials);
      end
      %corrected p_val: / 2: 2-tail; / size(freqs, 2): freq bins;
      [H, P] = ttest2(PB_tmp', PB_alert_tmp', p_val / 2 / size(freqs, 2) / n_of_subj_win, 'both');
      H_mask(:, k) = H';
      P_mask(:, k) = P';
    end  %k
    %%%sig

    %rename necessary variables to prevent being overwritten
    com = sprintf('%s.IC%02d = IC_tmp;', mn, i); eval(com);
    com = sprintf('%s.session_count = session_count;', mn); eval(com);
    com = sprintf('%s.cls_length = cls_length;', mn); eval(com);
    com = sprintf('%s.icawinv = icawinv;', mn); eval(com);
    com = sprintf('%s.chanlocs = chanlocs;', mn); eval(com);
    com = sprintf('%s.freqs = freqs;', mn); eval(com);
    com = sprintf('%s.RT_s = RT_s;', mn); eval(com);
    com = sprintf('%s.subj_seq = subj_seq;', mn); eval(com);
    com = sprintf('%s.PB_mean = PB_mean;', mn); eval(com);
    com = sprintf('%s.PB_alert = PB_alert;', mn); eval(com);
    com = sprintf('%s.PB_alert_subj = PB_alert_subj;', mn); eval(com);
    com = sprintf('%s.PB_n = PB_n;', mn); eval(com);
    com = sprintf('%s.alert = alert;', mn); eval(com);
    com = sprintf('%s.RT_s_mov = RT_s_mov;', mn); eval(com);
    com = sprintf('%s.PB_mov = PB_mov;', mn); eval(com);
    com = sprintf('%s.FREQ_INC = FREQ_INC;', mn); eval(com);
    com = sprintf('%s.H_mask = H_mask;', mn); eval(com);
    com = sprintf('%s.P_mask = P_mask;', mn); eval(com);
  end  %j (motionless/motion)
  %find indices for overlapped RT
  for j = 1 : size(MN, 1)
    mn = MN{j};
    com = sprintf('RT_s = %s.RT_s;', mn); eval(com);
    com = sprintf('alert = %s.alert;', mn); eval(com);
    RT_s_overlapIdx = find(RT_s_overlap(1) <= RT_s & RT_s <= RT_s_overlap(2));
    RT_s_mov_overlapIdx = RT_s_overlapIdx;
    %if all trials = 101, last trial wanted = 80 => winsize = 11 => last window = 70-80 => last idx = 70
    %=> discard trials 71-80 => 80 - 11 + 2 = 71
    %if all trials = 100, last trial wanted = 80 => winsize = 10 => last window = 71-80 => last idx = 71
    %=> discard trials 71-80 => 80 - 10 + 1 = 71
    if (mod(RT_s, alert.trials) ~= 0)
      RT_s_mov_overlapIdx(length(RT_s_mov_overlapIdx) - alert.trials + 2 : length(RT_s_mov_overlapIdx)) = [];
    else
      RT_s_mov_overlapIdx(length(RT_s_mov_overlapIdx) - alert.trials + 1 : length(RT_s_mov_overlapIdx)) = [];
    end
    com = sprintf('%s.RT_s_overlapIdx = RT_s_overlapIdx;', mn); eval(com);
    com = sprintf('%s.RT_s_mov_overlapIdx = RT_s_mov_overlapIdx;', mn); eval(com);
  end

%% plot figure for comparing motionless and motion conditions
  figure(1058); hold on;
  set(gcf, 'Renderer', 'ZBuffer');
  %title
  subplot('position', [.115 .9 .77 .1]); axis off;   %title
  title_text_tmp = ['\color[rgb]' FONT_COLOR 'Moving Averaged '];
  switch epoch_type
    case 'all'  %baseline
      title_text_tmp = [title_text_tmp 'Mixed '];
    case 'dev_on'
      title_text_tmp = [title_text_tmp 'Phasic '];
    otherwise
      title_text_tmp = [title_text_tmp 'Tonic '];
  end
  title_text_tmp = [title_text_tmp 'Power of the \color[rgb]{0 0 1}' IC_tmp{1} '\color[rgb]' FONT_COLOR  ' Cluster\rm\fontsize{' int2str(FONT_SIZE) '}'];
%   if strcmp(epoch_type, 'all')  %whole epoch
%     title_text_tmp = [title_text_tmp ' (the Whole Epoch)'];
%   elseif strcmp(epoch_type, 'dev_on')  %after dev_on
%     title_text_tmp = [title_text_tmp ' (After Dev\_on)'];
%   end
%  title_text(1) = {[title_text_tmp '\rm\fontsize{' int2str(FONT_SIZE) '}']};
 title_text(1) = {title_text_tmp};
  for j = 1 : size(MN, 1)
    mn = MN{j};
    com = sprintf('MN_tmp = MN{%d};', j); eval(com);
    com = sprintf('MN_COLOR = MN_COLOR%d;', j); eval(com);
    com = sprintf('RT_s = %s.RT_s;', mn); eval(com);
    com = sprintf('cls_length = %s.cls_length;', mn); eval(com);
    com = sprintf('session_count = %s.session_count;', mn); eval(com);
    title_text(j + 1) = {['\color[rgb]' MN_COLOR upper(MN_tmp) '\color[rgb]' FONT_COLOR ': ' ...
        int2str(length(RT_s)) ' trials (' int2str(cls_length) ' components from ' int2str(session_count) ' sessions)']};
  end
  text(.5, .5, title_text, 'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
      'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');

  RT_s_mov_overlap = [0 Inf];
  for j = 1 : size(MN, 1)
    %reloading necessary variables
    mn = MN{j};
    com = sprintf('MN_COLOR = MN_COLOR%d;', j); eval(com);
    com = sprintf('icawinv = %s.icawinv;', mn); eval(com);
    com = sprintf('chanlocs = %s.chanlocs;', mn); eval(com);
    com = sprintf('freqs = %s.freqs;', mn); eval(com);
    com = sprintf('RT_s = %s.RT_s;', mn); eval(com);
    com = sprintf('RT_s_mov = %s.RT_s_mov;', mn); eval(com);
    com = sprintf('PB_mov = %s.PB_mov;', mn); eval(com);
    com = sprintf('FREQ_INC = %s.FREQ_INC;', mn); eval(com);
    com = sprintf('H_mask = %s.H_mask;', mn); eval(com);
    com = sprintf('RT_s_overlapIdx = %s.RT_s_overlapIdx;', mn); eval(com);
    com = sprintf('RT_s_mov_overlapIdx = %s.RT_s_mov_overlapIdx;', mn); eval(com);
    RT_s_mov_overlap = ...
        [max(RT_s_mov_overlap(1), RT_s_mov(RT_s_mov_overlapIdx(1))) min(RT_s_mov_overlap(end), RT_s_mov(RT_s_mov_overlapIdx(end)))];
        
    %component map
    if size(MN, 1) <= 2
      label_pos = [(.01 + (j - 1) * .875) .97 .025 .03];
      comp_width = .08;
      comp_pos = [(.875 * (j - 1) + .035) .92 comp_width .08];
      comp_txt = [(.875 * (j - 1) + .035) .9 comp_width .02];
    else
      label_pos = [(.01 + (j - 1) * .875) .97 .025 .025];
      comp_width = .24 / size(MN, 1);
      comp_pos = [(.03 + comp_width * (j - 1)) .92 comp_width comp_width];
      comp_txt = [(.03 + comp_width * (j - 1)) .9 comp_width .02];
    end
    subplot('position', label_pos); axis off;  %plot sub-label
    text(.5, .25, ['\color[rgb]' FONT_COLOR 'A' + (j - 1)], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'BackgroundColor', FONT_BKCOLOR, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'FontWeight', 'bold');
    subplot('position', comp_pos); axis off;  %plot component map
    try
      DR_topoplot(icawinv, chanlocs, 'electrodes', 'off', 'shrink', 'force');
    catch
      topoplot(icawinv, chanlocs, 'electrodes', 'off', 'shrink', 'force');
    end
    subplot('position', comp_txt); axis off;
    text(.5, 1, ['\color[rgb]' MN_COLOR  upper(mn(1)) mn(2:end)], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'Cap');
    if j == size(MN, 1)
      set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');  %set after topoplot to preserve backgound color
    end

    %extract dataset (discard trials with RT not in RT_s_mov_overlap
    RT_s_mov_extract = RT_s_mov(RT_s_mov_overlapIdx);
    PB_mov_extract = PB_mov(:, RT_s_mov_overlapIdx);
    H_mask_extract = H_mask(:, RT_s_mov_overlapIdx);
    FREQ_INC_extract = FREQ_INC;
    for k = 1 : size(FREQ_INC, 1)
      pow_inc_tmp = FREQ_INC{k, 4};
      pow_SD_tmp = FREQ_INC{k, 5};
      FREQ_INC_extract(k, 4) ={pow_inc_tmp(RT_s_mov_overlapIdx)};
      FREQ_INC_extract(k, 5) ={pow_SD_tmp(RT_s_mov_overlapIdx)};
    end
    xstep_mov = size(RT_s_mov_extract, 2) / xstep_int;
    
    if j == 1
      %dimensions of figures
      %width of power image. .055: text; .045: colobar; .015: blank
      pbase_width = (1 - .055 - .045 - .015 * size(MN, 1)) / size(MN, 1);
      splt_h = .28;
      splt_w = (.98 - .055 - .015 * (size(FREQ_INC_extract, 1))) / size(FREQ_INC_extract, 1);
      %title and sub-label
      subplot('position', [.01 .86 .025 .025]); axis off;
      text(.5, .5, ['\color[rgb]' FONT_COLOR 'C'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'BackgroundColor', FONT_BKCOLOR, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'FontWeight', 'bold');
      subplot('position', [.055 .86 .89 .025]); axis off;
      text(.5, .5, ['\color[rgb]' FONT_COLOR 'Moving Averaged Power Images'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'FontWeight', 'bold');
    end

    %plot moving avg. power image (inside contour: p < p_val)
    subplot('position', [.055 + (j - 1) * (pbase_width + 0.015), .55, pbase_width, splt_h]); hold on;
    imagesc(1 : size(RT_s_mov_extract, 2), freqs, PB_mov_extract, [-3 6]);
    contour(1 : size(RT_s_mov_extract, 2), freqs, H_mask_extract, 1, ...
        'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
    set(gca, 'XColor', AXIS_COLOR, ...
        'Xlim', [1 size(RT_s_mov_extract, 2)], 'XTick', xstep_mov : xstep_mov : size(RT_s_mov_extract, 2) - xstep_mov, ...
        'XTickLabel', roundn(RT_s_mov_extract(xstep_mov : xstep_mov : size(RT_s_mov_extract, 2) - xstep_mov), -2), ...
        'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
    %mark x ticks
    for k = xstep_mov : xstep_mov : size(RT_s_mov_extract, 2) - xstep_mov
      plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
    end
    %mark frequency
    for k = 10 : 10 : 40
      plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
    end
    %plot a vertical line with x axis on RT = 3 sec trial
    if (RT_s_mov_extract(end) >= 3)
      plot([find(RT_s_mov_extract <= 3, 1, 'last') find(RT_s_mov_extract <= 3, 1, 'last')], get(gca, 'Ylim'), ...
          'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
    end
    %labels
    if j == 1
      %y label
      ylabel('Frequency (Hz)', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'baseline');
      %xlabel
      subplot('position', [.055 .49 .895 .03]); axis off;
      text(.5, .5, 'Moving Averaged Reaction Time (sec)', ...
          'FontSize', AXIS_FSIZE, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
      %colorbar
      subplot('position', [.955 .55 .01 splt_h]); axis off;
      imagesc(1, 1 : 65, (65 : -1 : 1)', [1 65]);
      title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
          'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Baseline');
      set(gca, 'XTick', [], 'YTick', 1 : 64/3 : 65, 'YTickLabel', 6 : -3 : -3, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);
    else
      set(gca, 'YTickLabel', []);
    end
    %title
    subplot('position', [.055 + (j - 1) * (pbase_width + 0.015), .83, pbase_width, .03]); axis off;
    text(.5, 0, ['\color[rgb]' MN_COLOR upper(mn(1)) mn(2 : end) '\color[rgb]' FONT_COLOR ...
        '\rm\fontsize{' int2str(STITLE_FSIZE - 2) '}  ' int2str(size(RT_s_overlapIdx, 2)) ' of ' int2str(size(RT_s, 2)) ' trials (' ...
        num2str(size(RT_s_overlapIdx, 2) / size(RT_s, 2) * 100, '%.1f') '% extracted)'], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'FontWeight', 'bold', 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'bottom');

    %plot power increase over different frequent bands
    if j == 1
      subplot('position', [.01 .455 .025 .025]); axis off;
      text(.5, .5, ['\color[rgb]' FONT_COLOR 'D'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'BackgroundColor', FONT_BKCOLOR, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'FontWeight', 'bold');
      subplot('position', [.055 .455 .89 .025]); axis off;
      text(.5, .5, ['\color[rgb]' FONT_COLOR 'Power Increase'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'FontWeight', 'bold');
    end
    for k = 1 : size(FREQ_INC, 1)
      splt_x = .055 + (splt_w + 0.015) * (k - 1);
      splt_y = .15;
      splt(k) = subplot('position', [splt_x splt_y splt_w splt_h]); hold on;
      %dummy, for legend
      if j == 1 && strcmpi(SD, '_SD')
        for m = 1 : size(MN, 1)
          com = sprintf('MN_COLOR = MN_COLOR%d;', m); eval(com);
          plot(0, 0, 'Color', str2num(['[' MN_COLOR(2 : end - 1) ']']), 'LineWidth', 1);
        end
        if RT_s_mov_overlap(end) >= 3
          plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);  %dummy, for RT
        end
      end
      freq_name = FREQ_INC_extract{k, 1};
      freq_band = FREQ_INC_extract{k, 2};
      freq_color = FREQ_INC_extract{k, 3}; freq_color = mat2str(freq_color);
      freq_inc = FREQ_INC_extract{k, 4};
      freq_SD = FREQ_INC_extract{k, 5};
      com = sprintf('MN_COLOR = MN_COLOR%d;', j); eval(com);
      plot(RT_s_mov_extract, freq_inc, 'Color', str2num(['[' MN_COLOR(2 : end - 1) ']']), 'LineWidth', 1);
      if strcmpi(SD, '_SD')
        plot(RT_s_mov_extract, freq_inc + freq_SD, 'Color', str2num(['[' MN_COLOR(2 : end - 1) ']']) / 2, 'LineWidth', .5);
      end
      if j == size(MN, 1)
        %deal with legend
        if k == 1
          legend_string = 'legend(';
          for m = 1 : size(MN, 1)
            legend_string = [legend_string '''' MN{m} ''', '];
          end
        end
        plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);  %dummy, for RT
        set(gca, 'Xlim', RT_s_mov_overlap, ...
            'XColor', AXIS_COLOR, 'XScale', 'log', 'XTick', 1 : 2 : RT_s_mov_overlap(end), ...
            'YLim', ylim_tmp, 'YTick', -1 : 6, 'YTickLabel', {'', '  0', '', '  2', '', '  4', '', '  6'}, ...
            'YColor', AXIS_COLOR, 'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
        if k ~= 1
          set(gca, 'YTickLabel', []);
        end
        %plot a vertical line with x axis on RT = 3 sec
        if RT_s_mov_overlap(end) >= 3
          plot([3 3], ylim_tmp, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
          if k == 1
            legend_string = [legend_string '''RT = 3 sec'', ''Location'', ''NorthWest'');'];
          end
        else
          if k == 1
            legend_string = [legend_string '''Location'', ''NorthEast'');'];
          end
        end
        if k == 1
          legend_handle = eval(legend_string);
          set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off');
        end
        box on;
        if ~strcmpi(freq_name, '\alpha + \theta');
        title(['\color[rgb]{' freq_color(2 : end - 1) '}' freq_name '\color[rgb]' FONT_COLOR ' band'], ...
            'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'middle');%, 'FontWeight', 'bold');
        else
        title(['(\color[rgb]{' freq_color(2 : end - 1) '}' freq_name '\color[rgb]' FONT_COLOR ') bands'], ...
            'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'middle');%, 'FontWeight', 'bold');
        end
        %x and y labels
        if k == 1
          %y label
          ylabel('Power Increase (dB)', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'baseline', 'FontSize', AXIS_FSIZE);
          %x label
          subplot('position', [.055 .07 .89 .04]); axis off;
          text(.5, .5, 'Moving Averaged Reaction Time (sec)', ...
              'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', 'FontSize', AXIS_FSIZE);
        end
      end  %if j == size(MN, 1)
    end  %k (# of freq bands)
  end  %j  (motionless/motion)

  %adding notes for information of RT
  text_string = ['\color[rgb]' FONT_COLOR 'Original range of RT: '];
  for j = 1 : size(MN, 1)
    mn = MN{j};
    com = sprintf('MN_COLOR = MN_COLOR%d;', j); eval(com);
    com = sprintf('RT_s = %s.RT_s;', mn); eval(com);
    text_string = [text_string '\color[rgb]' MN_COLOR upper(mn(1)) mn(2 : end) '\color[rgb]' FONT_COLOR ' - ' ...
        num2str(RT_s(1), '%.2f') '~' num2str(RT_s(end), '%.2f') ' sec'];
    if j ~= size(MN, 1)
      text_string = [text_string '; '];
%     else
%       text_string = [text_string '. '];
    end
  end
  text_string = {text_string};
  text_string(2) = {['Extracted range: ' ...
      num2str(RT_s_overlap(1), '%.2f') '~' num2str(RT_s_overlap(2), '%.2f') ' sec']};
  subplot('position', [.055 .01 .89 .05]); axis off;
  text(0, .5, text_string, 'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle', 'FontSize', FONT_SIZE);

%% save figure;
  figure(1058);
  if ~strcmp(epoch_type, 'all') && ~strcmp(epoch_type, 'dev_on')
    if isempty(noband) && isempty(SD)
      save([FilePathOld epoch_type SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_motionless+motion.mat'], ...
          'motionless', 'motion', 'RT_s_overlap', 'RT_s_mov_overlap');
    end
    saveas(1058, [FilePathOld epoch_type SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_motionless+motion' SD noband '.fig']);
%     print('-dpng', [FilePathOld epoch_type SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_motionless+motion' SD noband '.png']);
  else
    if isempty(noband)
      save([FilePathOld epoch_type SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_motionless+motion_' epoch_type '.mat'], ...
          'motionless', 'motion', 'RT_s_overlap', 'RT_s_mov_overlap');
    end
    print('-dpng', [FilePathOld epoch_type SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_motionless+motion_' epoch_type SD noband '.png']);
  end
  close(1058);

%%
end