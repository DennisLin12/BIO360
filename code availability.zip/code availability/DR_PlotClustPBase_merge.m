%power spectra cross subjects (just plotting, no computation)
%merge dipole and spectra (for slide)
%run after DR_PlotClustPBase and DR_PlotClustCompPowerDipole
%mostly base on RS_powbase
%This version: 200903 by poem

%% set parameters (initialize)
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/RS/';  %directory
  SL = '/';
end
DR_PBase_setup;  %load setup file
MN = 'motion';
p_val = 1E-10;
if strcmpi(MN, 'motionless')
  MN_COLOR = '{0 0 1}';
elseif strcmpi(MN, 'motion')
  MN_COLOR = '{1 0 0}';
else
  MN_COLOR = '{0 1 0}';
end
movstep = 1;  %stepping for moving avg
xstep_int = 5;
FilePathOld = FilePath;
epoch_type = '';  %'' => baseline, all => all epoch, dev_on => after dev_on
rj = '_rj';
SD = '_SD';  %'' => not plotting SD on power traces; '_SD': plotting
noband = '';  %1: alpha + theta

try
  close(196);
end
try
  close(169);
end
power_xlim = [min_freq max_freq];
power_ylim = [0 30];
ylim_tmp = [-2 7];
nor = 1;
%font size
FONT_SIZE = 12;  %text
TITLE_FSIZE = 14;  %title
STITLE_FSIZE = 12;  %subtitle
AXIS_FSIZE = 12;  %axis
CBAR_FSIZE = 12;  %color bar

%% load data
for i = 1 : size(ClsLabel, 1)
  load([FilePath MN SL 'IC' num2str(i, '%02d') '_component_' cls_ver '_' MN ]); %component map, dipole and spectra
  if isempty(epoch_type)
    load([FilePath SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_' MN]); %baseline power spectra, etc.
  else
    load([FilePath SL epoch_type SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_' MN '_' epoch_type]); %baseline power spectra, etc.
  end
%   load(['~/IC' num2str(i, '%02d') '_component_' cls_ver '_' MN]); %component map, dipole and spectra
%   load(['~/IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_' MN]); %baseline power spectra, etc.
  switch noband
    case '1'
      FREQ_INC(3, :) = [];
  end
  if cls_length > 0
   com = sprintf('IC_tmp = IC%02d;', i); eval(com);
%% plot figure
    xstep = size(RT_s, 2) / xstep_int;
    xstep_mov = size(RT_s_mov, 2) / xstep_int;
    xticks_mov = ...
        (2 * .1 - alert.rate - 0.01) / (2 - 2 * alert.rate) * size(RT_s_mov, 2) - 1 : xstep / movstep : size(RT_s_mov, 2);
    figure(169); hold on;
    set(gcf, 'Renderer', 'ZBuffer');
%     subplot('position', [.03 .88 .94 .12]); axis off;  %title
    subplot('position', [.03 .9 .94 .1]); axis off;  %title
%     subplot('position', [.15 .88 .8 .12]); axis off;  %title
    switch epoch_type
      case 'all'
        text(.5, .6, ...
            {['\color[rgb]' FONT_COLOR 'Moving Averaged Mixed Power of the \color[rgb]{0 0 1}' IC_tmp{1} '\color[rgb]' FONT_COLOR  ' Cluster']; ...
            ['\fontsize{' int2str(TITLE_FSIZE) '}\rm(\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' int2str(length(RT_s)) ' trials, ' int2str(cls_length) ...
            ' components from ' int2str(session_count) ' sessions)']}, ...
            'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE + 2, 'FontWeight', 'bold', ...
            'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
      case 'dev_on'
        text(.5, .6, ...
            {['\color[rgb]' FONT_COLOR 'Moving Averaged Phasic Power of the \color[rgb]{0 0 1}' IC_tmp{1} '\color[rgb]' FONT_COLOR  ' Cluster']; ...
            ['\fontsize{' int2str(TITLE_FSIZE) '}\rm(\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' int2str(length(RT_s)) ' trials, ' int2str(cls_length) ...
            ' components from ' int2str(session_count) ' sessions)']}, ...
            'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE + 2, 'FontWeight', 'bold', ...
            'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
        otherwise
         text(.5, .6, ...
            {['\color[rgb]' FONT_COLOR 'Moving Averaged Tonic Power of the \color[rgb]{0 0 1}' IC_tmp{1} '\color[rgb]' FONT_COLOR  ' Cluster']; ...
            ['\fontsize{' int2str(TITLE_FSIZE) '}\rm(\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' int2str(length(RT_s)) ' trials, ' int2str(cls_length) ...
            ' components from ' int2str(session_count) ' sessions)']}, ...
            'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE + 2, 'FontWeight', 'bold', ...
            'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
    end
    
    %plot scalp map
    subplot('position', [0 .87 .04 .03]); axis off;  %for sub-label
    text(.375, .5, ['\color[rgb]' FONT_COLOR 'A'], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'BackgroundColor', FONT_BKCOLOR, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'FontWeight', 'bold');
    subplot('position', [.04 .66 .24 .24]);
%     subplot('position', [.03 .88 .12 .12]);
    DR_topoplot(icawinv, chanlocs, 'electrodes', 'off', 'shrink', 'force');
    
    %plot avg spectra of alert trials
    subplot('position', [0 .63 .06 .03]); axis off;  %for sub-label
    text(.25, 1, ['\color[rgb]' FONT_COLOR 'B'], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'BackgroundColor', FONT_BKCOLOR, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Baseline', 'FontWeight', 'bold');
    subplot('position', [.06 .385 .24 .25]); hold on;
%     subplot('position', [.05 .47 .25 .355]); hold on;
    avg_spec = trimmean(spec_all, 10, 1);
    plot(freqs(1), avg_spec(1), '-b', 'LineWidth', 1.5);  %dummy, for legend
    plot(freqs, spec_all', 'LineStyle', '-', 'Color', [.75 .75 .75]);  %every spectrum
    plot(freqs, avg_spec, '-b', 'LineWidth', 1.5);  %avg spectrum (plot after each spectra to prevent being covered)
%     legend_handle = legend('Avg. Spectra', 'Spectra of Each Dataset', 'location', 'NorthEast');
    legend_handle = legend('Average', 'Each Dataset', 'location', 'NorthEast');
    set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off');
    title('Spectra of Alert Trials', 'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'FontWeight', 'bold');
    hold off;
    xlim(power_xlim);
    ylim(power_ylim);
    set(gca, 'Box', 'off', 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, ...
        'XTick', 10 : 10 : power_xlim(2), 'YTick', power_ylim(1) : 10 : power_ylim(2));
    xlabel('Frequency (Hz)', 'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'VerticalAlignment', 'middle');
    ylabel('Power (dB)', 'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'VerticalAlignment', 'Baseline');

    %plot dipoles
    subplot('position', [0 .287 .06 .03]); axis off;  %for sub-label
    text(.25, 0, ['\color[rgb]' FONT_COLOR 'C'], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'BackgroundColor', FONT_BKCOLOR, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Bottom', 'FontWeight', 'bold');
    subplot('position', [.05 .037 .25 .25]); axis off;
%     subplot('position', [.01 .055 .3 .3]); axis off;
    target = gca;
    for j = 1 : cls_length
      dip_color_tmp = mat2str(dip_color{mod(j, size(dip_color, 1)) + 1});
      if j ~= 1
        figure(196);
        subplot('position', [.05 .037 .25 .25]);
%         subplot('position', [.01 .055 .3 .3]);
      end
      eval(['dipplot(dipole_all{j}, ''mri'', mrifile, ''view'', view_angle_single, ''color'', {' ...
          '[.4 .8 1]}, ''dipolesize'', 10, ''dipolelength'', 0, ' [dip_option ...
          ', ''projimg'', ''off'', ''projlines'', ''off'', ''coordformat'', ''spherical'''] ');']);
      if (j ~= 1)
        h2 = findobj(gcf,'Type','line');
        copyobj(h2, target);
        close(196);
      end
    end
    %avg dipole
    figure(196);
    subplot('position', [.05 .037 .25 .25]);
%     subplot('position', [.01 .055 .3 .3]);
    eval(['dipplot(dipole_avg, ''mri'', mrifile, ''view'', view_angle_single, ''color'', {' ...
        '[1 1 0]}, ''dipolesize'', 15, ''dipolelength'', 0, ' [dip_option ...
        ', ''projimg'', ''off'', ''projlines'', ''on'', ''projcol'', {[1 1 0]}, ''coordformat'', ''spherical'''] ');']);
    h2 = findobj(gcf,'Type','line');
    copyobj(h2, target);
    close(196);
    
    %plot moving avg. power image (inside contour: p < p_val)
    subplot('position', [.315 .87 .055 .03]); axis off;  %for sub-label
    text(.2, .5, ['\color[rgb]' FONT_COLOR 'D'], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'BackgroundColor', FONT_BKCOLOR, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'FontWeight', 'bold');
    subplot('position', [.37 .45 .58 .34]); hold on;
    imagesc(1 : size(RT_s_mov, 2), freqs, PB_mov, [-3 6]);
    contour(1 : size(RT_s_mov, 2), freqs, H_mask, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
%     set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2, ...
%         'XTickLabel', (1 / 2 : xstep_int - 1 / 2) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
%         'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
    set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xticks_mov, ...
        'XTickLabel', (1 / 2 : xstep_int - 1 / 2) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
        'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
    %mark x ticks
%     for k = xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2
    for k = xticks_mov
      plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
    end
    %mark frequency
    for k = 10 : 10 : 40
      plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
    end
    xlabel('Reaction-Time-Sorted Trial Index (%)', 'VerticalAlignment', 'Baseline');
    ylabel('Frequency (Hz)');
    %title
    subplot('position', [.37 .87 .58 .03]); axis off;
    text(.5, 0, ['\color[rgb]' FONT_COLOR 'Moving Averaged Baseline Power Image\rm\fontsize {' int2str(STITLE_FSIZE - 2) '} (Countour: \itp\rm < ' num2str(p_val, '%.e') ')'], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
    %colorbar
    subplot('position', [.955 .45 .01 .34]); axis off;
    imagesc(1, 1:65, (65 : -1 : 1)', [1 65]);
    title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
        'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Baseline');
    set(gca, 'XTick', [], 'YTick', 1 : 64/3 : 65, 'YTickLabel', 6 : -3 : -3, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);

    %plot power increases in different frequent bands
    subplot('position', [.315 .42 .055 .03]); axis off;  %for sub-label
    text(.2, .5, ['\color[rgb]' FONT_COLOR 'E'], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'BackgroundColor', FONT_BKCOLOR, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'FontWeight', 'bold');
    subplot('position', [.37 .07 .58 .34]); hold on;
    %dummy, for legend
    if strcmpi(SD, '_SD')
      for k = 1 : size(FREQ_INC, 1)
        freq_color = FREQ_INC{k, 3};
        plot(0, 0, 'Color', freq_color, 'LineWidth', 1.5);
      end
      %RT
      if find(RT_s_mov <= 3, 1, 'last') ~= size(RT_s_mov, 2) || RT_s_mov(find(RT_s_mov <= 3, 1, 'last')) >= 2.995
        plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
      end
    end
    legend_string = 'legend(';
    for k = 1 : size(FREQ_INC, 1)
      freq_name = FREQ_INC{k, 1};
      freq_band = FREQ_INC{k, 2};
      freq_color = FREQ_INC{k, 3};
      freq_inc = FREQ_INC{k, 4};
      freq_SD = FREQ_INC{k, 5};
      freq_sigh = FREQ_INC{k, 7};
      plot(freq_inc, 'Color', freq_color, 'LineWidth', 1.5);
      if strcmpi(SD, '_SD')
        plot(freq_inc + freq_SD, 'Color', freq_color, 'LineStyle', '-', 'LineWidth', 0.5);
      end
      %deal with legend
      legend_string = [legend_string '''' freq_name ' (' int2str(freq_band(1)) '~' int2str(freq_band(2)) ' Hz)'', '];
    end
    plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', .5);  %dummy, for RT
%     set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2, ...
%         'XTickLabel', roundn(RT_s_mov(xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2), -2), 'XColor', AXIS_COLOR, ...
%         'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
    set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xticks_mov, 'XTickLabel', ...
        roundn(RT_s_mov((2 * .1 - alert.rate - 0.01) / (2 - 2 * alert.rate) * size(RT_s_mov, 2) - 1 : xstep / movstep : size(RT_s_mov, 2)), -2), ...
        'XColor', AXIS_COLOR, 'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
    %mark x ticks
%     for k = xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2
    for k = xticks_mov
      plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
    end
    %plot a vertical line with x axis on RT = 3 sec
    if find(RT_s_mov <= 3, 1, 'last') ~= size(RT_s_mov, 2) || RT_s_mov(find(RT_s_mov <= 3, 1, 'last')) >= 2.995
      plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
          'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
      legend_string = [legend_string '''RT = 3 sec'', ''Location'', ''NorthWest'');'];
    else
      legend_string = [legend_string '''Location'', ''NorthWest'');'];
    end
    legend_handle = eval(legend_string);
    set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off');
%     xlabel('Moving Averaged Reaction Time (sec)', 'VerticalAlignment', 'cap');
    ylabel('Power Increase (dB)', 'VerticalAlignment', 'bottom');
    title(['\color[rgb]' FONT_COLOR 'Power Increase'], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
    subplot('position', [.37 .01 .58 .03]); axis off;
    text(.5, 0, ['\color[rgb]' FONT_COLOR 'Moving Averaged Reaction Time (sec)'], ...
        'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Baseline');
    set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');  %set after topoplot to preserve backgound color

%% save figure
    figure(169);
    if ~strcmp(epoch_type, 'all') && ~strcmp(epoch_type, 'dev_on')
      saveas(gcf, [FilePathOld epoch_type SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_result_' MN SD noband '.fig']);
%       print('-dpng', [FilePathOld epoch_type SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_result_' MN SD noband '.png']);
%       print('-dpng', ['~/IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_result_' MN SD '.png']);
    else
      print('-dpng', [FilePathOld epoch_type SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_result_' MN '_' epoch_type SD noband '.png']);
%       print('-dpng', ['~/IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_result_' MN '_' epoch_type SD '.png']);
    end
    close(169);
  else
    fprintf('IC%02d: No components in this cluster. Omit this cluster.', i);
  end
%%
end