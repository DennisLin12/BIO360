%power spectra cross subjects (comparing motionless and motion)
%mostly base on RS_powbase
%This version: 2009/3 by poem

%% set parameters (initialize)
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/RS/';  %directory
  SL = '/';
end
DR_PBase_setup;  %load setup file
%datasets
PLOT_SET = {
            's31_061103';  %motionless
            's32_061031';  %motionless
            's35_070322';  %motionless
            's36_061221';  %motionless
%             's37_071213';  %motionless
%             's39_070117';  %motionless
            's40_070207';  %motionless
            's41_061225';  %motionless
            's42_070105';  %motionless
            's43_070208';  %motionless
            's44_070325';  %motionless
            's31_061020';  %motion
            's35_070115';  %motion
            's36_061122';  %motion
%             's39_061218';  %motion
            's40_070131';  %motion
            's43_070202';  %motion
            's44_070126';  %motion
           };
MN = {'motionless'; 'motion'};
p_val = 1E-10;
for i = 1 : size(MN, 1)  %deciding color
  mn = MN{i};
  switch mn
    case 'motionless'
      mn_color = '{0 0 1}';  %blue
    case 'motion'
      mn_color = '{1 0 0}';  %red
    otherwise
      mn_color = '{0 1 0}';  %green
  end
  com = sprintf('MN_COLOR%d = mn_color;', i); eval(com);
end
movstep = 1;  %stepping for moving avg
xstep_int = 5;
FilePathOld = FilePath;
epoch_type = 'all';  %'' => baseline, all => all epoch, dev_on => after dev_on
% FilePathOld = [FilePath 'dev_on' SL];
try
  close(1058);
end
rj = '_rj';
ylim_tmp = [-2 7];
nor = 1;
%font size
FONT_SIZE = 12;  %text
TITLE_FSIZE = 14;  %title
STITLE_FSIZE = 12;  %subtitle
AXIS_FSIZE = 12;  %axis
CBAR_FSIZE = 12;  %color bar

%% modify database (create new database from the original one)
for i = 1 : size(MN, 1)
  com = sprintf('SET%d = {}; SUBJ%d = {};', i, i); eval(com);
end 
%split datasets to motionless and motion subsets
for i = 1 : size(SET, 1)
  if strcmp(SET{i, 3}, MN{1})
    SET1 = [SET1; SET(i, :)];
    SUBJ1 = [SUBJ1; {strtok(SET{i, 1}, '_')}];
  elseif strcmp(SET{i, 3}, MN{2})
    SET2 = [SET2; SET(i, :)];
    SUBJ2 = [SUBJ2; {strtok(SET{i, 1}, '_')}];
  end
end
%find the subjects who have done motionless and motion sessions (in database)
SUBJ_tmp = intersect(SUBJ1, SUBJ2);
for i = 1 : size(MN, 1)
  com =  sprintf('SET%d = SET%d(ismember(SUBJ%d, SUBJ_tmp), :);', i, i, i); eval(com);
end
clear SET SUBJ_tmp;
%till now, new database = SET1 and SET2

%% check subject list and split it into sub-list according to condition
for i = 1 : size(MN, 1)
  com = sprintf('PLOT_SET%d = {}; SUBJ%d = {};', i, i); eval(com);
end
for i = 1 : size(PLOT_SET, 1)
  %check if the plot_set is valid
  plot_set = PLOT_SET{i};
  check_ok = false;
  for j = 1 : size(MN, 1)  
    if check_ok  %in previous dataset
      break;
    else
      com = sprintf('SET_tmp = SET%d;', j); eval(com);
      for k = 1 : size(SET_tmp, 1)
        Set = SET_tmp{k, 1};
        condition = SET_tmp{k, 3};
        if strcmp(Set, plot_set)  %dataset found in database, assign to correct subset
          check_ok = true;
%           if strcmp(condition, MN{j})  %condition ok => assign to appropriate sub-list
            com = sprintf('PLOT_SET%d = [PLOT_SET%d; SET_tmp(k, :)];', j, j); eval(com);
            com = sprintf('SUBJ%d = [SUBJ%d; {strtok(Set, ''_'')}];', j, j); eval(com);
%           else  %codition not ok => invalid
%             fprintf('%s: not valid, check set name or condition (should be motion/motionless).\n', plot_set);
%           end
          break;
        end
        if k == size(SET_tmp, 1) && j == size(MN, 1)  %not able to find dataset
          fprintf('%s: not valid. Subject Not finishing all experiments or error set name/condition.\n', plot_set);
        end
      end                                                                                                                                                                                                    
    end
  end
end
SUBJ_tmp = intersect(SUBJ1, SUBJ2);
for i = 1 : size(MN, 1)
  com =  sprintf('PLOT_SET%d = PLOT_SET%d(ismember(SUBJ%d, SUBJ_tmp), :);', i, i, i); eval(com);
end
clear PLOT_SET SUBJ_tmp;

%% assign component to cluster
for i = 1 :size(ClsLabel, 1)
  for j = 1 : size(MN, 1)
    com = sprintf('IC%02d_%d = {ClsLabel{%d}};', i, j, i); eval(com);
%     com = sprintf('subj_seq%02d_%d = {};', i, j); eval(com);  %# of sessions in a cluster
    com = sprintf('session_count%02d_%d = 0;', i, j); eval(com);
  end
end
for i = 1 : size(MN, 1)
  com = sprintf('SET_tmp = SET%d;', i); eval(com);  %database
  com = sprintf('PLOT_SET_tmp = PLOT_SET%d;', i); eval(com);  %plot list
  for j = 1 : size(PLOT_SET_tmp, 1)
    plot_set = PLOT_SET_tmp{j};
    for k = 1 : size(SET_tmp, 1)
      Set = SET_tmp{k, 1};
      if strcmp(Set, plot_set)  %dataset found in database, assign to correct subset
        oldcls = zeros(1, size(ClsLabel, 1));  %register to memorize if the cluster shown before
        COMP = SET_tmp{k, 2};
        for m = 1 : size(COMP, 2)  %assign to cluster
          comp = COMP(1, m);  %componet #
          comp_cls = COMP(2, m);  %which cluster
          if comp_cls > 0
            IC_tmp = {Set, comp};
            com = sprintf('IC%02d_%d = [IC%02d_%d IC_tmp];', comp_cls, i, comp_cls, i); eval(com);
            if ~oldcls(comp_cls)  %first appearing
              oldcls(comp_cls) = true;
              com = sprintf('session_count%02d_%d = session_count%02d_%d + 1;', comp_cls, i, comp_cls, i); eval(com);
            end
          end
        end
        break;
      end
    end
  end
end

%% process data
for i = 1 : size(ClsLabel, 1)
  for j = 1 : size(MN, 1)
    FilePath = FilePathOld;
    com = sprintf('IC_tmp = IC%02d_%d;', i, j); eval(com);  %IC_tmp: sorted by subject list given above
    com = sprintf('session_count = session_count%02d_%d;', i, j); eval(com);
    subj_seq = {};
    session_id = 0;  %the same dataset => session id NOT the same across clusters
    old_set = '';

    %load icawinv for plotting component maps
    tmp_icawinv = load([FilePath MN{j} SL 'IC' num2str(i, '%02d') '_component_' cls_ver '_' MN{j}], 'avg_icawinv', 'std_chanlocs');  %tmp_set.PB_mean: row: freq, col: trial  
    icawinv = tmp_icawinv.avg_icawinv;
    chanlocs = tmp_icawinv.std_chanlocs;
    clear tmp_icawinv;
    FilePath = [FilePath epoch_type SL MN{j} SL 'IC' num2str(i, '%02d') SL];
    cls_length = (size(IC_tmp, 2) - 1) / 2;
    allAlpha = [];
    allTheta = [];
    allRT_s = [];
    RT_s = [];
    PB_mean = [];
    PB_alert_subj = [];  %baseline power for alert trials of each subject. only for the first normalize method
    if nor == 3 || nor == 4
      PB_alert = 0;
    else
      PB_alert = [];
    end
    PB_n = [];
    for k = 1 : cls_length
      plot_set = IC_tmp{1, 2 * k};
      plot_comp = IC_tmp{1, 2 * k + 1};
      tmp_cell = {};  %for storing session
      tmp_arr = [];  %for storing session ID (easy to access when calculating);
      %counting session id
      if ~strcmp(old_set, plot_set)  %new dataset
        session_id = session_id + 1;
      end
      %load dataset
      if ~isempty(epoch_type)
        tmp_set = load([FilePath plot_set '_PBaseRT_' num2str(plot_comp, '%02d') rj '_' epoch_type], 'RT_s', 'PB_mean', 'freqs');  %tmp_set.PB_mean: row: freq, col: trial
      else
        tmp_set = load([FilePath plot_set '_PBaseRT_' num2str(plot_comp, '%02d') rj], 'RT_s', 'PB_mean', 'freqs');  %tmp_set.PB_mean: row: freq, col: trial
      end
      RT_s = [RT_s tmp_set.RT_s];
      PB_mean = [PB_mean tmp_set.PB_mean];
      freqs = tmp_set.freqs;
      %recording session according to trials (length of PB_mean or RT_s)
      tmp_cell(1 : size(tmp_set.PB_mean, 2)) = {plot_set};
      tmp_arr(1 : size(tmp_set.PB_mean, 2)) = session_id;
      tmp_arr_cell = mat2cell(tmp_arr, ones(1, size(tmp_arr, 1)), ones(1, size(tmp_arr, 2)));
      subj_seq = [subj_seq [tmp_cell; tmp_arr_cell]];

      %normalize
      switch nor
        case 1
          alert.trials = ceil(size(tmp_set.PB_mean, 2) * alert.rate);  %find baseline
          PB_alert_tmp = tmp_set.PB_mean(:, 1 : alert.trials);  %calculating power of alert trials
          PB_alert_tmp = mean(PB_alert_tmp, 2) * ones(1, length(tmp_set.RT_s));  %padding
          PB_n_tmp = tmp_set.PB_mean - PB_alert_tmp;  %normalized by power in alert stage
          PB_alert = [PB_alert PB_alert_tmp];
          PB_n = [PB_n PB_n_tmp];
          if k == cls_length  %finish loading dataset, calculate baseline
            [RT_s ur_idx] = sort(RT_s, 2);  %sort by RT
            PB_mean = PB_mean(:, ur_idx);
%             PB_alert = PB_alert(:, ur_idx);
            PB_n = PB_n(:, ur_idx);
            PB_alert = PB_alert(:, ur_idx);
            subj_seq = subj_seq(:, ur_idx);
            subj_seq_id = cell2mat(subj_seq(2, :));
          end
          if ~strcmp(old_set, plot_set)
            PB_alert_subj = [PB_alert_subj PB_alert_tmp(:, 1)];
          end
        case 2
          if k == cls_length  %finish loading dataset, calculate baseline
            [RT_s ur_idx] = sort(RT_s, 2);  %sort by RT
            PB_mean = PB_mean(:, ur_idx);
%             PB_mean = sortrows(PB_mean', size(PB_mean, 1))';  %sort by RT
%             RT_s = PB_mean(end, :);
%             PB_mean(end, :) = [];
            alert.trials = ceil(size(PB_mean, 2) * alert.rate);  %find baseline
            PB_alert = PB_mean(:, 1 : alert.trials);  %calculating power of alert trials
            PB_alert_mean = trimmean(PB_alert, 10, 2) * ones(1, length(RT_s));  %padding
            PB_n = PB_mean - PB_alert_mean;  %normalized by power in alert stage
          end
        case {3, 4}
          alert.trials = ceil(size(tmp_set.PB_mean, 2) * alert.rate);  %find baseline
          PB_alert_tmp = tmp_set.PB_mean(:, 1 : alert.trials);  %calculating power of alert trials
          if nor == 4
            PB_alert = PB_alert + length(tmp_set.RT_s) * mean(PB_alert_tmp, 2);  %weighted sum
          else
            PB_alert = PB_alert + mean(PB_alert_tmp, 2);  %direct sum
          end
          if k == cls_length  %finish loading dataset, calculate baseline
            [RT_s ur_idx] = sort(RT_s, 2);  %sort by RT
            PB_mean = PB_mean(:, ur_idx);
            if nor == 4
              PB_alert_mean = PB_alert / length(RT_s) * ones(1, length(RT_s));
            else
              PB_alert_mean = PB_alert / cls_length * ones(1, length(RT_s));  %averaging baseline and padding
            end
            PB_n = PB_mean - PB_alert_mean;
          end
      end  %switch
      old_set = plot_set;
    end  %k
    alert.trials = ceil(size(RT_s, 2) * alert.rate);
  
    %moving average
    PB_mov = [];
    RT_s_mov = [];
    for k = 1 : movstep : size(PB_n, 2) - (alert.trials - 1)
%       PB_mov = [PB_mov mean(PB_n(:, k : k + alert.trials - 1), 2)];
%       RT_s_mov = [RT_s_mov mean(RT_s(:, k : k + alert.trials - 1), 2)];
      PB_mov = [PB_mov trimmean(PB_n(:, k : k + alert.trials - 1), 10, 2)];
      RT_s_mov = [RT_s_mov trimmean(RT_s(:, k : k + alert.trials - 1), 10, 2)];
    end

    %compute power over different freq bands
    FREQ_INC = {};
    for k = 1 : size(FREQ_BAND, 1)
      freq_band = FREQ_BAND{k, 2};
      FREQ_INC(k, 1) = FREQ_BAND(k, 1);
      FREQ_INC(k, 2) = FREQ_BAND(k, 2);
      FREQ_INC(k, 3) = {mean(PB_mov(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :))};
      FREQ_INC(k, 4) = FREQ_BAND(k, 3);
      %curve fitting
%       tmp_inc_freq = mean(PB_n(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :));
      tmp_inc_freq = trimmean(PB_n(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :), 10);
      [tmp_p tmp_S] = polyfit(RT_s, tmp_inc_freq, curfit_order);
      tmp_p_val = polyval(tmp_p, RT_s);
      tmp_p_mov = [];
%       tmp_inc_freq_mov = [];
      for m = 1 : movstep : size(PB_n, 2) - (alert.trials - 1)
%         tmp_p_mov = [tmp_p_mov mean(tmp_p_val(:, m : m + alert.trials - 1), 2)];
        tmp_p_mov = [tmp_p_mov trimmean(tmp_p_val(:, m : m + alert.trials - 1), 10, 2)];
%         tmp_inc_freq_mov = [tmp_inc_freq_mov mean(tmp_inc_freq(:, m : m + alert.trials - 1), 2)];
      end  %m
      FREQ_INC(k, 5) = {tmp_p};
      FREQ_INC(k, 6) = {tmp_S};
      FREQ_INC(k, 7) = {tmp_p_mov};
    end  %k
  
    %statistics
    fprintf('Performing 2-sample T-test (p = %g): \n', p_val);
    P_mask = zeros(size(PB_mov));
    H_mask = P_mask;
    sig_idx = 1 : movstep : floor(size(PB_n, 2) / movstep) - (alert.trials - 1);
    for k = 1 : size(PB_mov, 2)
      PB_tmp = PB_mean(:, sig_idx(k) : sig_idx(k) + alert.trials - 1);
      PB_alert_tmp = 0;
      if nor == 1
        subj_seq_id_tmp = subj_seq_id(:, sig_idx(k) : sig_idx(k) + alert.trials - 1);
        %counting how many trials of each subject in this window
        n_of_subj_win = 0;  %number of subjects in a moving window
        for m = 1 : session_count
          n_of_trial = length(find(subj_seq_id_tmp == m));
          if ~isempty(n_of_trial)
            PB_alert_tmp = PB_alert_tmp + PB_alert_subj(:, m) * n_of_trial;  %adding the power of alert trials according to propotion
            n_of_subj_win = n_of_subj_win + 1;
          else
            keyboard;
          end
        end
        PB_alert_tmp = PB_alert_tmp * ones(1, alert.trials) / alert.trials;
      else
        n_of_subject_win = 1;  %use the same baseline, no need do consider the difference between subjects
        PB_alert_tmp = PB_alert(:, 1 : alert.trials);
      end
      %corrected p_val: / 2: 2-tail; / size(freqs, 2): freq bins;
%       [H, P] = ttest2(PB_tmp', PB_alert_tmp', p_val / 2 / size(freqs, 2) / alert.trials, 'both');
      [H, P] = ttest2(PB_tmp', PB_alert_tmp', p_val / 2 / size(freqs, 2) / n_of_subj_win, 'both');
      H_mask(:, k) = H';
      P_mask(:, k) = P';
    end  %k

    %rename necessary variables to prevent being overwritten
    com = sprintf('cls_length%d = cls_length;', j); eval(com);
    com = sprintf('session_count%d = session_count;', j); eval(com);
    com = sprintf('icawinv%d = icawinv;', j); eval(com);
    com = sprintf('chanlocs%d = chanlocs;', j); eval(com);
    com = sprintf('freqs%d = freqs;', j); eval(com);  %???
    com = sprintf('RT_s%d = RT_s;', j); eval(com);  %???
    com = sprintf('RT_s_mov%d = RT_s_mov;', j); eval(com);
    com = sprintf('subj_seq%d = subj_seq;', j); eval(com);
    com = sprintf('PB_mean%d = PB_mean;', j); eval(com);
    com = sprintf('PB_alert%d = PB_alert;', j); eval(com);
    com = sprintf('PB_alert_subj%d = PB_alert_subj;', j); eval(com);
    com = sprintf('PB_n%d = PB_n;', j); eval(com);
    com = sprintf('PB_mov%d = PB_mov;', j); eval(com);
    com = sprintf('FREQ_INC%d = FREQ_INC;', j); eval(com);
    com = sprintf('H_mask%d = H_mask;', j); eval(com);
    com = sprintf('P_mask%d = P_mask;', j); eval(com);
  end  %j

  %find the overlapped range of RT_s_mov
  %since the RT_s_mov are sorted, just compare tje first and last elements
  RT_s_mov_overlap = [max(RT_s_mov1(1), RT_s_mov2(1)) min(RT_s_mov1(end), RT_s_mov2(end))];
  for j = 1 : size(MN, 1)
    com = sprintf(...
        'RT_s_mov_overlapIdx%d = find(RT_s_mov_overlap(1) <= RT_s_mov%d & RT_s_mov%d <= RT_s_mov_overlap(2));', j, j, j); eval(com);
  end

%% plot figure for comparing motionless and motion conditions
  figure(1058); hold on;
  set(gcf, 'Render', 'ZBuffer');
  %title
%   subplot('position', [.1 .88 .8 .12]); axis off;   %title
  subplot('position', [.135 .88 .73 .12]); axis off;   %title
  title_text_tmp = ['\color[rgb]' FONT_COLOR '\rmMoving Averaged '];
  if isempty(epoch_type)  %baseline
    title_text_tmp = [title_text_tmp 'Baseline '];
  end
  title_text_tmp = [title_text_tmp 'Power Spectra of \color[rgb]{0 0 1}' IC_tmp{1} '\color[rgb]' FONT_COLOR  ' Cluster'];
  if strcmp(epoch_type, 'all')  %whole epoch
    title_text_tmp = [title_text_tmp ' (Whole Epoch)'];
  elseif strcmp(epoch_type, 'dev_on')  %after dev_on
    title_text_tmp = [title_text_tmp ' (After Dev\_on)'];
  end
  title_text(1) = {[title_text_tmp '\rm\fontsize{' int2str(FONT_SIZE) '}']};
  for j = 1 : size(MN, 1)
    com = sprintf('MN_tmp = MN{%d};', j); eval(com);
    com = sprintf('MN_COLOR = MN_COLOR%d;', j); eval(com);
    com = sprintf('RT_s = RT_s%d;', j); eval(com);
    com = sprintf('cls_length = cls_length%d;', j); eval(com);
    com = sprintf('session_count = session_count%d;', j); eval(com);
%     if j == 1
%       title_text_tmp = ['\rm\fontsize{' int2str(FONT_SIZE) '}('];
%     else
%       title_text_tmp = '';
%     end
%     title_text_tmp = [title_text_tmp '\color[rgb]' MN_COLOR upper(MN_tmp) '\color[rgb]' FONT_COLOR ': ' ...
%         int2str(length(RT_s)) ' Trials from ' int2str(cls_length) ' Components in ' int2str(session_count) ' Sessions'];
%     if j == 1
%       title_text_tmp = [title_text_tmp ';'];
%     else
%       title_text_tmp = [title_text_tmp ')'];
%     end
%     title_text(j + 1) = {title_text_tmp};
  title_text(j + 1) = {['\color[rgb]' MN_COLOR upper(MN_tmp) '\color[rgb]' FONT_COLOR ': ' ...
      int2str(length(RT_s)) ' trials (' int2str(cls_length) ' components from ' int2str(session_count) ' sessions)']};
  end
  text(.5, .5, title_text, 'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
      'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');

  for j = 1 : size(MN, 1)
    %reloading necessary variables
    com = sprintf('MN_tmp = MN{%d};', j); eval(com);
    com = sprintf('MN_COLOR = MN_COLOR%d;', j); eval(com);
    com = sprintf('icawinv = icawinv%d;', j); eval(com);
    com = sprintf('chanlocs = chanlocs%d;', j); eval(com);
    com = sprintf('freqs = freqs%d;', j); eval(com);
    com = sprintf('RT_s_mov = RT_s_mov%d;', j); eval(com);
    com = sprintf('PB_mov = PB_mov%d;', j); eval(com);
    com = sprintf('FREQ_INC = FREQ_INC%d;', j); eval(com);
    com = sprintf('H_mask = H_mask%d;', j); eval(com);
    com = sprintf('RT_s_mov_overlapIdx = RT_s_mov_overlapIdx%d;', j); eval(com);
    
    %component map
    if size(MN, 1) <= 2
      label_pos = [(.01 + (j - 1) * .855) .97 .025 .03];
      comp_width = .10;
%       comp_pos = [(.01 + .88 * (j - 1)) .9 .10 .10];
%       comp_txt = [(.01 + .88 * (j - 1)) .88 .10 .02];
      comp_pos = [(.855 * (j - 1) + .035) .9 .10 .10];
      comp_txt = [(.855 * (j - 1) + .035) .88 .10 .02];
    else
      label_pos = [(.01 + (j - 1) * .855) .97 .025 .025];
      comp_width = .24 / size(MN, 1);
      comp_pos = [(.03 + comp_width * (j - 1)) .9 comp_width comp_width];
      comp_txt = [(.03 + comp_width * (j - 1)) .88 comp_width .02];
    end
    subplot('position', label_pos); axis off;  %plot sub-label
    text(.5, .25, ['\color[rgb]' FONT_COLOR 'A' + (j - 1)], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'BackgroundColor', FONT_BKCOLOR, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'FontWeight', 'bold');
    subplot('position', comp_pos); axis off;  %plot component map
    topoplot(icawinv, chanlocs, 'electrodes', 'off', 'shrink', 'force');
    subplot('position', comp_txt); axis off;
    text(.5, 1, ['\color[rgb]' MN_COLOR  upper(MN_tmp(1)) MN_tmp(2:end)], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'Cap');
    if j == size(MN, 1)
      set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');  %set after topoplot to preserve backgound color
    end

    %extract dataset (discard trials with RT not in RT_s_mov_overlap
    RT_s_mov_extract = RT_s_mov(RT_s_mov_overlapIdx);
    PB_mov_extract = PB_mov(:, RT_s_mov_overlapIdx);
    H_mask_extract = H_mask(:, RT_s_mov_overlapIdx);
    FREQ_INC_extract = FREQ_INC;
    for k = 1 : size(FREQ_INC, 1)
      pow_inc_tmp = FREQ_INC{k, 3};
      FREQ_INC_extract(k, 3) ={pow_inc_tmp(RT_s_mov_overlapIdx)};
    end
    xstep_mov = size(RT_s_mov_extract, 2) / xstep_int;
    
    %dimensions of figures
    if j == 1  %only decide once
%       pbase_width = (.955 - .055 - .01 * size(MN, 1)) / size(MN, 1);  %width of power image
      pbase_width = (.95 - .055 - .025 * (size(MN, 1) - 1)) / size(MN, 1);  %width of power image
%       splt_h = .315;
      splt_h = .27;
      splt_w = (.98 - .055 - .015 * (size(FREQ_INC_extract, 1))) / size(FREQ_INC_extract, 1);
    end

    %plot moving avg. power image (inside contour: p < p_val)
    subplot('position', [.03 + (j - 1) * (pbase_width + 0.025), .84, .025, .025]); axis off;
    text(.5, .5, ['\color[rgb]' FONT_COLOR 'C' + (j - 1)], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'BackgroundColor', FONT_BKCOLOR, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'FontWeight', 'bold');
%     subplot('position', [.055 + (j - 1) * (pbase_width + 0.01), .495, pbase_width, splt_h]); hold on;
    subplot('position', [.055 + (j - 1) * (pbase_width + 0.025), .54, pbase_width, splt_h]); hold on;
    imagesc(1 : size(RT_s_mov_extract, 2), freqs, PB_mov_extract, [-3 6]);
    contour(1 : size(RT_s_mov_extract, 2), freqs, H_mask_extract, 1, ...
        'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
    set(gca, 'XColor', AXIS_COLOR, ...
        'Xlim', [1 size(RT_s_mov_extract, 2)], 'XTick', xstep_mov : xstep_mov : size(RT_s_mov_extract, 2) - xstep_mov, ...
        'XTickLabel', roundn(RT_s_mov_extract(xstep_mov : xstep_mov : size(RT_s_mov_extract, 2) - xstep_mov), -2), ...
        'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
    %mark x ticks
%     for k = xstep_mov / 2 : xstep_mov : size(RT_s_mov_extract, 2) - xstep_mov / 2
    for k = xstep_mov : xstep_mov : size(RT_s_mov_extract, 2) - xstep_mov
      plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
    end
    %mark frequency
    for k = 10 : 10 : 40
      plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
    end
    %plot a vertical line with x axis on RT = 3 sec trial
    if (RT_s_mov_extract(end) >= 3)
      plot([find(RT_s_mov_extract <= 3, 1, 'last') find(RT_s_mov_extract <= 3, 1, 'last')], get(gca, 'Ylim'), ...
          'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
    end
    %labels
    if j == 1
      %y label
      ylabel('Frequency (Hz)', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'baseline');
      %xlabel
%       subplot('position', [.055 .425 .895 .04]); axis off;
      subplot('position', [.055 .47 .895 .04]); axis off;
      text(.5, .5, 'Moving Averaged Reaction Time (sec)', ...
          'FontSize', AXIS_FSIZE, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
      %colorbar
%       subplot('position', [.955 .495 .01 splt_h]); axis off;
      subplot('position', [.955 .54 .01 splt_h]); axis off;
      imagesc(1, 1 : 65, (65 : -1 : 1)', [1 65]);
      title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE, ...
          'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
      set(gca, 'XTick', [], 'YTick', 1 : 64/3 : 65, 'YTickLabel', 6 : -3 : -3, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);
    else
      set(gca, 'YTickLabel', []);
    end
    %title
    subplot('position', [.055 + (j - 1) * (pbase_width + 0.025), .81, pbase_width, .07]); axis off;
    text(.5, 0, {['\color[rgb]' MN_COLOR upper(MN_tmp(1)) MN_tmp(2 : end) '\color[rgb]' FONT_COLOR]; ...
        ['\rm\fontsize{' int2str(STITLE_FSIZE) '}(' int2str(size(RT_s_mov_extract, 2)) ' Time Points, ' ...
        num2str(size(RT_s_mov_extract, 2) / size(RT_s_mov, 2) * 100, '%.1f') '% of ' int2str(size(RT_s_mov, 2)) ' Time Points)']}, ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'FontWeight', 'bold', 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'bottom');

    %plot power increase over different frequent bands
    if j == 1
      subplot('position', [.03 .435 .025 .025]); axis off;
      text(.5, .5, ['\color[rgb]' FONT_COLOR 'E'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'BackgroundColor', FONT_BKCOLOR, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'FontWeight', 'bold');
    end
    for k = 1 : size(FREQ_INC, 1)
      splt_x = .055 + (splt_w + 0.015) * (k - 1);
%       splt_y = .07;
      splt_y = .16;
      splt(k) = subplot('position', [splt_x splt_y splt_w splt_h]); hold on;
      freq_name = FREQ_INC_extract{k, 1};
      freq_band = FREQ_INC_extract{k, 2};
      freq_inc = FREQ_INC_extract{k, 3};
      freq_color = FREQ_INC_extract{k, 4}; freq_color = mat2str(freq_color);
      plot(RT_s_mov_extract, freq_inc, 'Color', str2num(['[' MN_COLOR(2 : end - 1) ']']), 'LineWidth', 1);
      if j == size(MN, 1)
        %deal with legend
        if k == 1
          legend_string = 'legend(';
          for m = 1 : size(MN, 1)
            legend_string = [legend_string '''' MN{m} ''', '];
          end
        end
        plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);  %dummy, for RT
        set(gca, 'Xlim', [RT_s_mov_overlap(1) RT_s_mov_overlap(end)], ...
            'XColor', AXIS_COLOR, 'XScale', 'log', 'XTick', 1 : 2 : RT_s_mov_overlap(end), ...
            'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, 'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
%         set(gca, 'XTickLabel', 10 .^ str2double(get(gca, 'XTickLabel')));
%         if mod(k, subplt_width) ~= 1
        if k ~= 1
          set(gca, 'YTickLabel', []);
        end
        %plot a vertical line with x axis on RT = 3 sec
        if RT_s_mov_overlap(end) >= 3
          plot([3 3], ylim_tmp, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
          if k == 1
            legend_string = [legend_string '''RT = 3 sec'', ''Location'', ''NorthWest'');'];
          end
        else
          if k == 1
            legend_string = [legend_string '''Location'', ''NorthEast'');'];
          end
        end
        if k == 1
          legend_handle = eval(legend_string);
          set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off');
        end
        box on;
      end  %j == size(MN, 1)
      if j == 1
        title(['Power Inc in \color[rgb]{' freq_color(2 : end - 1) '}' freq_name '\color[rgb]' FONT_COLOR ' Band'], ...
            'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE - 2 , 'VerticalAlignment', 'middle');%, 'FontWeight', 'bold');
        %x and y labels
        if k == 1
          %y label
          ylabel('Power Increase (dB)', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'baseline', 'FontSize', AXIS_FSIZE);
          %x label
%           subplot('position', [.055 0 .895 .04]); axis off;
          subplot('position', [.055 .09 .895 .04]); axis off;
          text(.5, .5, 'Moving Averaged Reaction Time (sec)', ...
              'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', 'FontSize', AXIS_FSIZE);
        end
      end
    end  %k
  end  %j

  %adding notes for information of RT
  text_string = ['\color[rgb]' FONT_COLOR 'Original range of moving avg. RT: '];
  for j = 1 : size(MN, 1)
    com = sprintf('MN_tmp = MN{%d};', j); eval(com);
    com = sprintf('MN_COLOR = MN_COLOR%d;', j); eval(com);
    com = sprintf('RT_s_mov = RT_s_mov%d;', j); eval(com);
    text_string = [text_string '\color[rgb]' MN_COLOR upper(MN_tmp(1)) MN_tmp(2 : end) '\color[rgb]' FONT_COLOR ' - ' ...
        num2str(RT_s_mov(1), '%.2f') '~' num2str(RT_s_mov(end), '%.2f') ' sec'];
    if j ~= size(MN, 1)
      text_string = [text_string '; '];
    else
      text_string = [text_string '. '];
    end
  end
  text_string = {text_string};
%   text_string = [text_string 'Extracted range: ' ...
%       num2str(RT_s_mov_overlap(1), '%.2f') '~' num2str(RT_s_mov_overlap(end), '%.2f') ' sec'];
  text_string(2) = {['Extracted range: ' ...
      num2str(RT_s_mov_overlap(1), '%.2f') '~' num2str(RT_s_mov_overlap(end), '%.2f') ' sec']};
  subplot('position', [.055 0 .89 .08]); axis off;
  text(0, .5, text_string, 'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle', 'FontSize', FONT_SIZE);

%% save figure;
  figure(1058);
  if ~strcmp(epoch_type, 'all') && ~strcmp(epoch_type, 'dev_on')
    save([FilePathOld epoch_type SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_motionless+motion.mat'], ...
        'cls_length1', 'session_count1', 'icawinv1', 'chanlocs1', 'freqs1', 'RT_s1', 'RT_s_mov1', 'subj_seq1', ...
        'PB_mean1', 'PB_alert1', 'PB_alert_subj1', 'PB_n1', 'PB_mov1', 'FREQ_INC1', 'H_mask1', 'P_mask1', ['IC' num2str(i, '%02d') '_1'], ...
        'cls_length2', 'session_count2', 'icawinv2', 'chanlocs2', 'freqs2', 'RT_s2', 'RT_s_mov2', 'subj_seq2', ...
        'PB_mean2', 'PB_alert2', 'PB_alert_subj2', 'PB_n2', 'PB_mov2', 'FREQ_INC2', 'H_mask2', 'P_mask2', ['IC' num2str(i, '%02d') '_1']);
    saveas(1058, [FilePathOld epoch_type SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_motionless+motion.fig']);
    print('-dpng', [FilePathOld epoch_type SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_motionless+motion.png']);
  else
    save([FilePathOld epoch_type SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_motionless+motion_' epoch_type '.mat'], ...
        'cls_length1', 'session_count1', 'icawinv1', 'chanlocs1', 'freqs1', 'RT_s1', 'RT_s_mov1', 'subj_seq1', ...
        'PB_mean1', 'PB_alert1', 'PB_alert_subj1', 'PB_n1', 'PB_mov1', 'FREQ_INC1', 'H_mask1', 'P_mask1', ['IC' num2str(i, '%02d') '_1'], ...
        'cls_length2', 'session_count2', 'icawinv2', 'chanlocs2', 'freqs2', 'RT_s2', 'RT_s_mov2', 'subj_seq2', ...
        'PB_mean2', 'PB_alert2', 'PB_alert_subj2', 'PB_n2', 'PB_mov2', 'FREQ_INC2', 'H_mask2', 'P_mask2', ['IC' num2str(i, '%02d') '_1']);
    print('-dpng', [FilePathOld epoch_type SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_motionless+motion_' epoch_type '.png']);
  end
  close(1058);

%%
end