% op_arr = DR_movavg(ip_arr, window, stepping, SR, mov_key)
%   Input parameters:
%     ip_arr: m * n array
%     window: length of window in sec.
%     stepping: the next window is step sec. after ini. time of this window
%     SR: sampling rate
%     mov_key: the column of time point
%   Output parameters:
%     op_arr: p * (n + 1) array
%       1st column: index
%       qth column: the same as (q - 1)th column of ip_arr

function op_arr = DR_movavg(ip_arr, window, stepping, SR, mov_key)
 
op_arr = [];
window = window * SR;
stepping = stepping * SR;
start_time = ip_arr(1, mov_key);
start_idx = 1;
go = 1;
i = 1;
while (go)
  end_time = start_time + window;
  if end_time >= ip_arr(end, mov_key)
    end_time = ip_arr(end, mov_key);
    go = 0;
  end
  if go
    end_idx = find(ip_arr(:, mov_key) <= end_time, 1, 'last');
  else
    end_idx = size(ip_arr, 1);  %index of the last time point
  end
  op_arr = [op_arr; mean(ip_arr(start_idx : end_idx, :))];
  start_idx = find(ip_arr(:, mov_key) >= start_time + stepping, 1, 'first');
  start_time = ip_arr(start_idx, mov_key);
end
op_arr = [(1 : size(op_arr, 1))'  op_arr];