% Comparing power between 2 of the followings: baseline, whole epoch, and after dev_on [single subject]%This version: 2009/1 by poem
% ver 200901 by poem

%% set parameters (initialize)
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/RS/';  %directory
  SL = '/';
end
DR_PBase_setup;  %load setup file
MN = 'motionless';
p_val = 1E-10;
if strcmp(MN, 'motionless')
  MN_COLOR = '{0 0 1}';
elseif strcmp(MN, 'motion')
  MN_COLOR = '{1 0 0}';
else
  MN_COLOR = '{0 1 0}';
end
movstep = 1;  %stepping for moving avg
xstep_int = 5;
EPOCH_TYPE = {'', 'all'};  %'' => baseline, all => all epoch, dev_on => after dev_on; allowing 2 types
try
  close(1053);
end
rj = '_rj';
ylim_tmp = [-2 7];
nor = 1;                  

%% process data
for i = 1 : size(ClsLabel, 1)
  if ~isempty(EPOCH_TYPE{1})
    epoch_type1 = load([FilePath ...
        EPOCH_TYPE{1} SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_' MN '_' EPOCH_TYPE{1}]);
  else
    epoch_type1 = load([FilePath ...
        EPOCH_TYPE{1} SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_' MN]);
  end
  if ~isempty(EPOCH_TYPE{2})
    epoch_type2 = load([FilePath ...
        EPOCH_TYPE{2} SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_' MN '_' EPOCH_TYPE{2}]);
  else
    epoch_type2 = load([FilePath ...
        EPOCH_TYPE{2} SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_' MN]);
  end
  alert.trials = ceil(size(epoch_type1.PB_mean, 2) * alert.rate);
  %calculate differences
  PB_mov_diff = epoch_type1.PB_mov - epoch_type2.PB_mov;  %these two PB_mov with the same dimension
  FREQ_INC_DIFF = epoch_type1.FREQ_INC;
  for k = 1 : size(FREQ_INC_DIFF, 1)
    FREQ_INC_DIFF{k, 3} = FREQ_INC_DIFF{k, 3} - epoch_type2.FREQ_INC{k, 3};
  end
  %statistics test (2-sample t-test)
  %courtesy Ruey-Song Huang in UCSD
  fprintf('Performing 2-sample T-test (p = %g): \n', p_val);
  P_mask_diff = zeros(size(epoch_type1.PB_mov));
  H_mask_diff = P_mask_diff;
  sig_idx = 1 : movstep : floor(size(epoch_type1.PB_n, 2) / movstep) - (alert.trials - 1);
  for j = 1 : size(epoch_type1.PB_mov, 2)
    PB_tmp1 = epoch_type1.PB_mean(:, sig_idx(j) : sig_idx(j) + alert.trials - 1);
    PB_tmp2 = epoch_type2.PB_mean(:, sig_idx(j) : sig_idx(j) + alert.trials - 1);
    %corrected p_val: / 2: 2-tail; / size(freqs, 2): freq bins;  / epoch_type1.cls_length: # of subjects in this cluster
%     [H, P] = ttest2(PB_tmp1', PB_tmp2', p_val / 2 / size(epoch_type1.freqs, 2) / epoch_type1.cls_length / alert.trials, 'both');
    [H, P] = ttest2(PB_tmp1', PB_tmp2', p_val / 2 / size(epoch_type1.freqs, 2) / epoch_type1.cls_length, 'both');
    H_mask_diff(:, j) = H';
    P_mask_diff(:, j) = P';
  end

%% plot figure for moving averaged power image and power increase
  figure(1053); hold on;
  %title for whole figure
  subplot('position', [.03 .88 .12 .12]); axis off;  %plot component map
  topoplot(epoch_type1.icawinv, epoch_type1.chanlocs, 'electrodes', 'on', 'shrink', 'force');
  set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');  %set after topoplot to preserve backgound color
  subplot('position', [.15 .88 .8 .12]); axis off;   %title
  text(.5, .6, {['\color[rgb]' FONT_COLOR 'Comparison of Moving Avg. Power Spectra Between "Baseline" and "Whole Epoch" of']; ...
      ['\color[rgb]{0 0 1}' ClsLabel{i} '\color[rgb]' FONT_COLOR  ' Cluster (\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' ...
      int2str(length(epoch_type1.PB_mean)) ' Trials from ' int2str(epoch_type1.cls_length) ' Components in ' int2str(epoch_type1.session_count) ' Sessions)']}, ...
      'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');

%   xstep = (size(epoch_type1.RT_s, 2) - 1) / xstep_int;
%   xstep_mov = (size(epoch_type1.RT_s_mov, 2) - 1) / xstep_int;
  xstep_mov = size(epoch_type1.RT_s_mov, 2) / xstep_int;
  for j = 1 : 3
    %1: baseline power; 2: power of the whole epoch; 3: power differences
    if j ~= 3
      eval(['epoch_type_tmp = epoch_type' int2str(j) ';']);
      PB_mov = epoch_type_tmp.PB_mov;
      RT_s_mov = epoch_type_tmp.RT_s_mov;
      freqs = epoch_type_tmp.freqs;
      PB_mov = epoch_type_tmp.PB_mov;
      FREQ_INC = epoch_type_tmp.FREQ_INC;
      clear epoch_type_tmp;
    else
      PB_mov = PB_mov_diff;
      RT_s_mov = epoch_type1.RT_s_mov;
      freqs = epoch_type1.freqs;
      FREQ_INC = FREQ_INC_DIFF;
    end
    %power image
    subplot('position', [.055 + .3 * (j - 1) .44 .275 .355]); hold on;
    imagesc(1 : size(RT_s_mov, 2), freqs, PB_mov, [-3 6]);
    %adding significant region
    if j == 3
      contour(1 : size(RT_s_mov, 2), freqs, H_mask_diff, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
    end
    set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2, ...
        'XTickLabel', (1 / 2 : xstep_int - 1 / 2) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
        'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
    if j ~= 1
      set(gca, 'YTickLabel', []);
    end
    %mark x ticks
    for k = xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2
      plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
    end
    %mark frequency
    for k = 10 : 10 : 40
      plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
    end
%     %plot a vertical line with x axis on RT = 3 sec
%     try
%       plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
%           'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
%     end
    %axis labels
    if j == 1
      ylabel('Frequency (Hz)');
    elseif j == 2
      xlabel('Reaction-Time-Sorted Trial Index (%)', 'VerticalAlignment', 'Baseline');
    end
    subplot('position', [.055 + .3 * (j - 1) .85 .275 .03]); axis off;
    %title and colorbar
    if j == 1
      text(.5, 0, ['\color[rgb]' FONT_COLOR 'Baseline Power Image'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
    elseif j == 2
      %title
      text(.5, 0, ['\color[rgb]' FONT_COLOR 'Power Image of the Whole Epoch'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
    else
      text(.5, 0, ['\color[rgb]' FONT_COLOR 'Power Differences\rm\fontsize {' int2str(STITLE_FSIZE - 2) '} (Countour: p < ' num2str(p_val, '%.e') ')'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
      %colorbar
      subplot('position', [.935 .44 .01 .355]); axis off;
      imagesc(1, 1:65, (65 : -1 : 1)', [1 65]);
      title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
          'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
      set(gca, 'XTick', [], 'YTick', 1 : 64/3 : 65, 'YTickLabel', 6 : -3 : -3, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);
    end

    %plot power increase over different frequent bands
    subplot('position', [.055 + .3 * (j - 1) .06 .275 .355]); hold on;
    if j == 1
      legend_string = 'legend(';
    end
    for k = 1 : size(FREQ_INC, 1)
      freq_name = FREQ_INC{k, 1};
      freq_band = FREQ_INC{k, 2};
      freq_inc = FREQ_INC{k, 3};
      freq_color = FREQ_INC{k, 4};
      plot(freq_inc, 'Color', freq_color, 'LineWidth', .5);
      if j == 1
        %deal with legend
        legend_string = [legend_string '''' freq_name ' (' int2str(freq_band(1)) '~' int2str(freq_band(2)) ' Hz)'', '];
      end
    end
    plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', .5);  %dummy, for RT
    set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XColor', AXIS_COLOR, ...
        'XTick', xstep_mov / 2 : xstep_mov : size(RT_s_mov - xstep_mov, 2) - xstep_mov / 2, ...
        'XTickLabel', roundn(RT_s_mov(xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2), -2), ...
        'YLim', ylim_tmp, 'YTick', -1 : 6, 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
    if j ~= 1
      set(gca, 'YTickLabel', []);
    end
    %mark x ticks
    for k = xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2
      plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
    end
    %plot a vertical line with x axis on RT = 3 sec
    if find(RT_s_mov <= 3, 1, 'last') ~= size(RT_s_mov, 2) || RT_s_mov(find(RT_s_mov <= 3, 1, 'last')) >= 2.995
      plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
          'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
      if j == 1
        legend_string = [legend_string '''RT = 3 sec'', ''Location'', ''NorthWest'');'];
      end
    else
      if j == 1
        legend_string = [legend_string '''Location'', ''NorthWest'');'];
      end
    end
    if j == 1
      legend_handle = eval(legend_string);
      set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off');
    end
    %axis labels and titles
    if j == 1
      ylabel('Power (dB)', 'VerticalAlignment', 'middle');
      title(['\color[rgb]' FONT_COLOR 'Baseline Power Increase'], ...
        'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
    elseif j == 2
      xlabel('Moving Avg. Reaction Time (sec)');
      title(['\color[rgb]' FONT_COLOR 'Power Increase of the Whole Epoch'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
    else
      title(['\color[rgb]' FONT_COLOR 'Differences Between Power Increases'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
    end
  end

%% save figure;
  str1 = EPOCH_TYPE{1};
  str2 = EPOCH_TYPE{2};
  if isempty(str1)
    str1 = 'baseline';
  end
  if isempty(str2)
    str2 = 'baseline';
  end
  save([FilePath MN SL ...
      'IC' num2str(i, '%02d') '_compare_' str1 '_' str2 '_' MN '_' int2str(nor) rj], ...
         'PB_mov_diff', 'FREQ_INC_DIFF', 'H_mask_diff', 'P_mask_diff');
  saveas(1053, [FilePath MN SL ...
      'IC' num2str(i, '%02d') '_compare_' str1 '_' str2 '_' MN '_' int2str(nor) rj '.fig']);
  print('-dpng', [FilePath MN SL ...
      'IC' num2str(i, '%02d') '_compare_' str1 '_' str2 '_' MN '_' int2str(nor) rj '.png']);
  close(1053);

%%
end