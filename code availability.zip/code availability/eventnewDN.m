tic
subj = 's36';
ExpDate = '061130';
MainDIR = ['~/liang/' subj '_' ExpDate '/'];
% subj = 's31';
% ExpDate = '061020';
% MainDIR = ['~/liang/' subj '_' ExpDate '/'];
SR = 500;  %sampling rate of EEG when RECORDING

A=[];
B=[];
C=[];
D=[];
E=[];
F=[];
A3=[];
A4=[];
A = importdata([MainDIR subj '_' ExpDate '.ev2']);
% A = importdata([MainDIR 's42nm-070105.ev2']);
if isstruct(A)
  A = A.data;
end
% B = load([MainDIR subj '_' ExpDate '_log.txt']);
B = load([MainDIR subj '_' ExpDate '.txt']);
% B = load([MainDIR subj '_' ExpDate '.txt']);
% B = load([MainDIR 's42nm-070105.txt']);

A = sortrows(A, 6);
for i = size(A, 1) : -1 : 2
  if A(i, 6) == A(i - 1, 6)
    A(i, 7) = 1;
  end
end
idx = find(A(:, 7) == 1); A(idx, :) = [];
A(:, 7) = [];
idx = find(A(:, 2) == B(1, 2), 1, 'first'); A(1 : idx - 1, :) = [];

if A(1,2)==2

A2 = zeros( size(B,1), size(A,2)-4 );
k1=1;
k2=1;
A2(1,2) = A(1,6);
A2(1,1) = 2;

fprintf('remove redundant event...\n');
%while k2 <= length(A)
for i=2:length(A)    
    if A(i,6) > A2(k1,2)        
        k1 = k1+1;%new
       A2(k1,1)=A(i,2);
        A2(k1,2)=A(i,6);%time  
    end        
end
A3 = A2( 1:k1 , : );
A4 =A3(:,1);

%C=find(A3(1:end-1)>A3(2:end) & A3(1:end-1)~=60 & A3(2:end)~=1 );
C=find(A4(1:end-1)>=A4(2:end) & A4(1:end-1)~=60 & A4(2:end)~=1 );
%C=find(A3(1:end-1)>A3(2:end) & (A3(1:end-1)~=60 & A3(2:end)~=1) & (A3(1:end-1)~=59 & A3(2:end)~=1) & (A3(1:end-1)~=60 & A3(2:end)~=2) );
D=C+1;
E=[D;C];
A3(E,:)=[];
A4(E,:)=[];

F=find(A4(1:end-1)>A4(2:end));

for i=1:length(F)-1
    A3(F(i)+1:F(i+1),1)=A3(F(i)+1:F(i+1),1)+60*i;
end
i=length(F);
A3(F(i)+1:end,1)=A3(F(i)+1:end,1)+60*i;
A3(:,1)=A3(:,1)-1;
% for i=1:length(A3)-1
%     if A3(i,1)~=60 & A3(i+1,1)~=1
%         C(k2)=find(A3(i,1)>A3(i+1,1));
%         k2=k2+1;
%     end
% end
% A3(C,:)=[];
%   
% for i=1:length(A3)-1
%     D=find(A3(i,1)>A3(i+1,1));
% end
% 
% for i=1:length(D)-1
%     A3(D(i)+1:D(i+1),1)=A3(D(i)+1:D(i+1),1)+60*i;
% end
A3(:,3)=0;
A3(:,4)=0;
A3(:,5)=A3(:,2);
A3(:,2)=B(A3(:,1),3);
A3(:, 6) = B(A3(:,1), 4);  %steering wheel
A3(:, 9) = B(A3(:,1), 1);  %original time in log file
%add difference between frames
for i = 1 : size(A3, 1) - 1
  if A3(i, 2) < 250 && A3(i + 1, 2) < 250
    A3(i, 7) = A3(i + 1, 2) - A3(i, 2);  %comparing with the NEXT frame
  else
    A3(i, 7) = NaN;
  end
end
A3(end, 7) = 0;
for i = size(A3, 1) : -1 : 2
  if A3(i, 2) < 250 && A3(i - 1, 2) < 250
    A3(i, 8) = A3(i, 2) - A3(i - 1, 2);  %comparing with the PREVIOUS frame
  else
    A3(i, 8) = NaN;
  end
end
A3(1, 8) = 0;
%fix deviation onset and response offset (drowsiness)
A3 = [A3; 0 251 0 0 Inf 0 0 0 0];  %dummy
idx = find(A3(:, 2) == 251 | A3(:, 2) == 252);
% idx1 = find(A3(2 : end, 2) == 254) + 1;  %dev_off
for i = 1 : size(idx, 1)
  %correcting dev_on
  if i ~= size(idx, 1)  %the last one: dummy; for finding act_off
    dev_on_tmp = A3(idx(i), 2);
    if A3(idx(i) + 1, 2) < 250
      traj_tmp = round((A3(idx(i) - 1, 2) + A3(idx(i) + 1, 2)) / 2);
    elseif A3(idx(i) + 2, 2) < 250
      traj_tmp = round((A3(idx(i) - 1, 2) + A3(idx(i) + 2, 2)) / 2);
    else
      traj_tmp = round((A3(idx(i) - 1, 2) + A3(idx(i) + 3, 2)) / 2);
    end
%     j = find(A3(idx(i) + 1 : end, 7) ~= 0, 1, 'first');  %find the first deviation
    %old (using degree of steering wheel)
    j = find(A3(:, 5) >= A3(idx(i), 5) + 0.25 * SR, 1, 'first');  %0.25: platform react after 0.25s
    while A3(j, 7) == 0  %still in baseline
      j = j + 1;
    end
%     A3(j, 2) = dev_tmp;
    A3(j, 2) = dev_on_tmp;
    A3(idx(i), 2) = traj_tmp;
  end
%   %convert dev_off into act_off
%   if i > 1  %i == 1: 1st deviation; no need to convert dev_off into act_off
%     dev_off_tmp = find(A3(idx(i) - 1 : -1 : 1, 2) == 254, 1, 'first');  %original dev_off
%     j = find(A3(idx(i) - 1 : -1 : idx(i) - dev_off_tmp, 8) ~= 0, 1, 'first');  %find the first action offset
%     if j < dev_off_tmp  %find act_off, correct
%       A3(idx(i) - j, 2) = A3(idx(i) - dev_off_tmp, 2);  %change the value into 254
%       %change 254 into trajectory
%       if A3(idx(i) - dev_off_tmp - 1, 2) < 250
%         traj_tmp1 = A3(idx(i) - dev_off_tmp - 1, 2);
%       elseif A3(idx(i) - dev_off_tmp - 2, 2) < 250  %A3(idx(i) - dev_off_tmp - 1, 2): 253
%         traj_tmp1 = A3(idx(i) - dev_off_tmp - 2, 2);
%       else  %A3(idx(i) - dev_off_tmp - 2, 2): 251/252
%         traj_tmp1 = A3(idx(i) - dev_off_tmp - 3, 2);
%       end
%       if A3(idx(i) - dev_off_tmp + 1, 2) < 250
%         traj_tmp2 = A3(idx(i) - dev_off_tmp + 1, 2);
%       else  %A3(idx(i) - dev_off_tmp + 1, 2): 251/252
%         traj_tmp2 = A3(idx(i) - dev_off_tmp + 2, 2);
%       end
%        A3(idx(i) - dev_off_tmp, 2) = round((traj_tmp1 + traj_tmp2) / 2);
%     else  %change 254 into 255 (255: original dev_off; not corrected)
%         A3(idx(i) - dev_off_tmp, 2) = 255;
%     end
%   end
end
A3(end, :) = [];

% %convert dev_off into act_off (old)
% for i = 1 : size(idx, 1)
%   if idx(i) >= 10
%     Prev = find(A3(idx(i) - 10 : idx(i) - 1, 2) < 250, 1, 'last');
%     Prev = A3(idx(i) - 11 + Prev, 2);
%   else
%     Prev = find(A3(1 : idx(i) - 1, 2) < 250, 1, 'last');
%     Prev = A3(Prev, 2);
%   end
%   if idx(i) <= size(A3, 1) - 10
%     Next = find(A3(idx(i) + 1 : idx(i) + 10, 2) < 250, 1, 'first');
%   else
%     Next = find(A3(idx(i) + 1 : end, 2) < 250, 1, 'first');
%   end
%   Next = A3(idx(i) + Next, 2);
%   traj_tmp = round((Prev + Next) / 2);
%   idx_tmp1 = find(A3(idx(i) + 1 : end, 2) > 250, 1, 'first');  %find next event
%   idx_tmp2 = find(A3(idx(i) + 1 : end, 6) == 0, 1, 'first');  %find angle of steering wheel == 0
%   if ~isempty(idx_tmp1)  %not in the last trial
%     if idx_tmp2 < idx_tmp1  %correct trial
%       A3(idx(i) + idx_tmp2, 2) = 254;
%       A3(idx(i), 2) = traj_tmp;
%     else  %error trial (not return to baseline)
%       A3(idx(i), 2) = 255;
%     end
%   else
%     if ~isempty(idx_tmp2)  %steering wheel in the position 0
%       A3(idx(i) + idx_tmp2, 2) = 254;
%       A3(idx(i), 2) = traj_tmp;
%     else  %not in baseline
%       A3(idx(i), 2) = 255;
%     end
%   end
% end
% A3(:, 6 : 8) = [];
A3(:, 1) = (1 : size(A3, 1))';
fid=fopen([MainDIR subj '_' ExpDate '_event.txt'], 'w');
fprintf(fid,'%d\t%d\t%d\t%d\t%d\n', A3(:, 1 : 5)' );
fclose(fid);
% end
end

toc