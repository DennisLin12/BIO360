% Comparing power between 2 of the followings: tonic, mixed, and phasic
% This version: 200905 by poem

%% set parameters (initialize)
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/RS/';  %directory
  SL = '/';
end
DR_PBase_setup;  %load setup file
MN = 'motionless';
p_val = 1E-10;
if strcmpi(MN, 'motionless')
  MN_COLOR = '{0 0 1}';
elseif strcmpi(MN, 'motion')
  MN_COLOR = '{1 0 0}';
else
  MN_COLOR = '{0 1 0}';
end
movstep = 1;  %stepping for moving avg
xstep_int = 5;
EPOCH_TYPE = {'', 'all'};  %'' => baseline, all => all epoch, dev_on => after dev_on; allowing 2 types
try
  close(1053);
end
rj = '_rj';
noband = '';  %1: alpha + theta
SD = '';
ylim_tmp = [-2 7];
nor = 1;
%font size
FONT_SIZE = 12;  %text
TITLE_FSIZE = 14;  %title
STITLE_FSIZE = 12;  %subtitle
AXIS_FSIZE = 12;  %axis
CBAR_FSIZE = 12;  %color bar

%% process data
for i = 1 : size(ClsLabel, 1)
  for j = 1 : 2
    if ~isempty(EPOCH_TYPE{j})
      epoch_type_tmp = load([FilePath ...
          EPOCH_TYPE{j} SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_' MN '_' EPOCH_TYPE{j}]);
    else
      epoch_type_tmp = load([FilePath ...
          EPOCH_TYPE{j} SL MN SL 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '_' MN]);
    end
    switch noband
      case '1'
        epoch_type_tmp.FREQ_INC(3, :) = [];
    end
    com = sprintf('epoch_type%d = epoch_type_tmp;', j); eval(com);
  end
  alert.trials = ceil(size(epoch_type1.PB_mean, 2) * alert.rate);
%   %calculate differences
%   PB_mov_diff = epoch_type1.PB_mov - epoch_type2.PB_mov;  %these two PB_mov with the same dimension
%   FREQ_INC_DIFF = epoch_type1.FREQ_INC;
%   for k = 1 : size(FREQ_INC_DIFF, 1)
%     FREQ_INC_DIFF{k, 3} = FREQ_INC_DIFF{k, 3} - epoch_type2.FREQ_INC{k, 3};
%   end
%   %statistics test (2-sample t-test)
%   %courtesy Ruey-Song Huang in UCSD
%   fprintf('Performing 2-sample T-test (p = %g): \n', p_val);
%   P_mask_diff = zeros(size(epoch_type1.PB_mov));
%   H_mask_diff = P_mask_diff;
%   sig_idx = 1 : movstep : floor(size(epoch_type1.PB_n, 2) / movstep) - (alert.trials - 1);
%   for j = 1 : size(epoch_type1.PB_mov, 2)
%     PB_tmp1 = epoch_type1.PB_mean(:, sig_idx(j) : sig_idx(j) + alert.trials - 1);
%     PB_tmp2 = epoch_type2.PB_mean(:, sig_idx(j) : sig_idx(j) + alert.trials - 1);
%     %corrected p_val: / 2: 2-tail; / size(freqs, 2): freq bins;  / epoch_type1.cls_length: # of subjects in this cluster
% %     [H, P] = ttest2(PB_tmp1', PB_tmp2', p_val / 2 / size(epoch_type1.freqs, 2) / epoch_type1.cls_length / alert.trials, 'both');
%     [H, P] = ttest2(PB_tmp1', PB_tmp2', p_val / 2 / size(epoch_type1.freqs, 2) / epoch_type1.cls_length, 'both');
%     H_mask_diff(:, j) = H';
%     P_mask_diff(:, j) = P';
%   end

%% plot figure for moving averaged power image and power increase
  figure(1053); hold on;
  set(gcf, 'Renderer', 'Zbuffer');
  %title for whole figure
%   subplot('position', [.03 .88 .12 .12]); axis off;  %plot component map
  subplot('position', [0 .9 .1 .1]); axis off;  %plot component map
  try
    DR_topoplot(epoch_type1.icawinv, epoch_type1.chanlocs, 'electrodes', 'off', 'shrink', 'force');
  catch
    topoplot(epoch_type1.icawinv, epoch_type1.chanlocs, 'electrodes', 'off', 'shrink', 'force');
  end
  set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');  %set after topoplot to preserve backgound color
%   subplot('position', [.15 .88 .8 .12]); axis off;   %title
  subplot('position', [.1 .9 .9 .1]); axis off;   %title
  text(.5, .6, {['\color[rgb]' FONT_COLOR ...
      'Comparison of Moving Averaged ' 8220 '\color[rgb]{0 .5 1}Tonic\color[rgb]' FONT_COLOR 8221 ' and ' 8220 '\color[rgb]{0 .66 0}Mixed\color[rgb]' FONT_COLOR 8221 ' Power of the ']; ...
      ['\color[rgb]{0 0 1}' ClsLabel{i} '\color[rgb]' FONT_COLOR  ' Cluster \fontsize{' int2str(FONT_SIZE) '}\rm(\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' ...
      int2str(length(epoch_type1.PB_mean)) ' trials, ' int2str(epoch_type1.cls_length) ' components from ' int2str(epoch_type1.session_count) ' sessions)']}, ...
      'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');

  xstep = size(epoch_type1.RT_s, 2) / xstep_int;
  xstep_mov = size(epoch_type1.RT_s_mov, 2) / xstep_int;
  for j = 1 : 2%3
    %1: tonic power; 2: mixed power; 3: power differences (obsolete)
%     if j ~= 3
    eval(['epoch_type_tmp = epoch_type' int2str(j) ';']);
    PB_mov = epoch_type_tmp.PB_mov;
    RT_s_mov = epoch_type_tmp.RT_s_mov;
    freqs = epoch_type_tmp.freqs;
    PB_mov = epoch_type_tmp.PB_mov;
    H_mask = epoch_type_tmp.H_mask;
    FREQ_INC = epoch_type_tmp.FREQ_INC;
    clear epoch_type_tmp;
    if j == 1
    end
    xticks_mov = ...
        (2 * .1 - alert.rate - 0.01) / (2 - 2 * alert.rate) * size(RT_s_mov, 2) - 1 : xstep / movstep : size(RT_s_mov, 2);
%     else
%       PB_mov = PB_mov_diff;
%       RT_s_mov = epoch_type1.RT_s_mov;
%       freqs = epoch_type1.freqs;
%       FREQ_INC = FREQ_INC_DIFF;
%     end
    if j == 1
      %dimension of figures
      blank = .015;
      %width of power image. .055: text; .045: colobar; .015: blank
      pbase_width = (1 - .055 - .045 - .015 * size(EPOCH_TYPE, 2)) / size(EPOCH_TYPE, 2);
      splt_h = .28;
%       splt_w = (.98 - .055 - .015 * (size(FREQ_INC, 1))) / size(FREQ_INC, 1);
      %sub-label
      subplot('position', [.03 + .46 * (j - 1) .87 .025 .03]); axis off;
      text(.5, .5, ['\color[rgb]' FONT_COLOR 'A' + (j - 1) * 2], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'BackgroundColor', FONT_BKCOLOR, ...
          'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'FontWeight', 'bold');
    end
    %power image
%     subplot('position', [.055 + .3 * (j - 1) .44 .275 .355]); hold on;
%     subplot('position', [.055 + .45 * (j - 1) .44 .425 .355]); hold on;
%     subplot('position', [.055 + .46 * (j - 1) .49 .435 .32]); hold on;
    subplot('position', [.055 + (pbase_width + blank) * (j - 1), .49, pbase_width, .32]); hold on;
    imagesc(1 : size(RT_s_mov, 2), freqs, PB_mov, [-3 6]);
    contour(1 : size(RT_s_mov, 2), freqs, H_mask, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
%     %adding significant region
%     if j == 3
%       contour(1 : size(RT_s_mov, 2), freqs, H_mask_diff, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
%     end
%     set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xstep_mov / 2 : xstep_mov : size(RT_s_mov, 2) - xstep_mov / 2, ...
%         'XTickLabel', (1 / 2 : xstep_int - 1 / 2) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
%         'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
    set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', xticks_mov, ...
        'XTickLabel', (1 / 2 : xstep_int - 1 / 2) / xstep_int * 100, 'XColor', AXIS_COLOR, 'XAxisLocation', 'Top', ...
        'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
    if j ~= 1
      set(gca, 'YTickLabel', []);
    end
    %mark x ticks
    for k = xticks_mov
      plot([k k], get(gca, 'Ylim'), ':k', 'LineWidth', 1);
    end
    %mark frequency
    for k = 10 : 10 : 40
      plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
    end
%     %plot a vertical line with x axis on RT = 3 sec
%     try
%       plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
%           'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
%     end
    %axis labels
    if j == 1
      ylabel('Frequency (Hz)', 'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'VerticalAlignment', 'Baseline');
      %xlabel
      subplot('position', [.055 .855 .895 .02]); axis off;
      text(.5, 0, ['\color[rgb]' FONT_COLOR 'Reaction-Time-Sorted Trial Index (%)'], ...
          'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'middle');
%     else%if j == 2
%       xlabel('Reaction-Time-Sorted Trial Index (%)', 'VerticalAlignment', 'Baseline');
    end
    %another x ticks (bottom)
    subplot('position', [.055 + (pbase_width + blank) * (j - 1), .465, pbase_width, .02]); axis off;
    xlim([1 size(RT_s_mov, 2)]);
    tmp_xtick = roundn(RT_s_mov((2 * .1 - alert.rate - 0.01) / (2 - 2 * alert.rate) * size(RT_s_mov, 2) - 1 : xstep / movstep : size(RT_s_mov, 2)), -2);
    m = 1;
    for k = xticks_mov
      text(k, .5, num2str(tmp_xtick(m), '%0.2f'), 'FontSize', AXIS_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'middle');
      m = m + 1;
    end
    clear m;
    %another x label (bottom)
    if j == 1
      subplot('position', [.055 .445 .895 .02]); axis off;
      text(.5, .5, ['\color[rgb]' FONT_COLOR 'Moving Averaged Reaction Time (sec)'], ...
          'FontName', FONT_FACE, 'FontSize', AXIS_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'middle');
    end
    
    %title and colorbar
    subplot('position', [.055 + (pbase_width + blank) * (j - 1), .88, pbase_width, .02]); axis off;
    if j == 1
      text(.5, 0, ['\color[rgb]' FONT_COLOR 8220 '\color[rgb]{0 .5 1}Tonic\color[rgb]' FONT_COLOR 8221 ' Power Image'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
    else%if j == 2
      %title
      text(.5, 0, ['\color[rgb]' FONT_COLOR 8220 '\color[rgb]{0 .66 0}Mixed\color[rgb]' FONT_COLOR 8221 ' Power Image'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
%     else
%       text(.5, 0, ['\color[rgb]' FONT_COLOR 'Power Differences\rm\fontsize {' int2str(STITLE_FSIZE - 2) '} (Countour: p < ' num2str(p_val, '%.e') ')'], ...
%           'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
      %colorbar
      subplot('position', [.955 .49 .01 .32]); axis off;
      imagesc(1, 1:65, (65 : -1 : 1)', [1 65]);
      title(['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', CBAR_FSIZE, ...
          'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Bottom');
      set(gca, 'XTick', [], 'YTick', 1 : 64/3 : 65, 'YTickLabel', 6 : -3 : -3, 'YAxisLocation', 'Right', 'FontSize', CBAR_FSIZE);
    end

    %plot power increase in different frequent bands
    if j == 1
      subplot('position', [.03 + .46 * (j - 1) .415 .025 .03]); axis off;
      text(.5, .5, ['\color[rgb]' FONT_COLOR 'B' + (j - 1) * 2], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'BackgroundColor', FONT_BKCOLOR, ...
          'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Cap', 'FontWeight', 'bold');
      %sub-title
      subplot('position', [.055 .415 .895 .025]); axis off;
      text(.5, .5, ['\color[rgb]' FONT_COLOR 'Power Increase'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, ...
          'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle', 'FontWeight', 'bold');
      splt_h = .32;
      splt_w = (.98 - .055 - .015 * (size(FREQ_INC, 1))) / size(FREQ_INC, 1);
    end
    for k = 1 : size(FREQ_INC, 1)
      splt_x = .055 + (splt_w + 0.015) * (k - 1);
      splt_y = .07;
      splt(k) = subplot('position', [splt_x splt_y splt_w splt_h]); hold on;
      %dummy, for legend
      if j == 1 && strcmpi(SD, '_SD')
        plot(0, 0, 'Color', [0 .5 1], 'LineWidth', 1);
        plot(0, 0, 'Color', [0 .66 0], 'LineWidth', 1);
        if RT_s_mov(end) >= 3
          plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);  %dummy, for RT
        end
      end
      freq_name = FREQ_INC{k, 1};
      freq_band = FREQ_INC{k, 2};
      freq_color = FREQ_INC{k, 3}; freq_color = mat2str(freq_color);
      freq_inc = FREQ_INC{k, 4};
      freq_SD = FREQ_INC{k, 5};
      if j == 1
        epoch_cl = [0 .5 1];
      else
        epoch_cl = [0 .66 0];
      end
      plot(RT_s_mov, freq_inc, 'Color', epoch_cl, 'LineWidth', 1);
      if strcmpi(SD, '_SD')
        plot(RT_s_mov, freq_inc + freq_SD, 'Color', epoch_cl / 2, 'LineWidth', .5);
      end
      if j == 2
        %deal with legend
        if k == 1
          legend_string = 'legend([8220 ''Tonic'' 8221], [8220 ''Mixed'' 8221], ';
        end
        plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);  %dummy, for RT
        if RT_s_mov(end) < 13
          xticklabel = 1 : 2 : RT_s_mov(end);
          if xticklabel(end) == 11
            xticklabel(end) = [];
          end
        else%if RT_s_mov(end) >= 11 && RT_s_mov(end) < 21
          xticklabel = 1 : 4 : RT_s_mov(end);
%         else
        end
        set(gca, 'Xlim', [RT_s_mov(1) RT_s_mov(end)], ...
            'XColor', AXIS_COLOR, 'XScale', 'log', 'XTick', xticklabel, ...
            'YLim', ylim_tmp, 'YTick', -1 : 6, 'YTickLabel', {'', '  0', '', '  2', '', '  4', '', '  6'}, ...
            'YColor', AXIS_COLOR, 'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
        if k ~= 1
          set(gca, 'YTickLabel', []);
        end
        %plot a vertical line with x axis on RT = 3 sec
        if RT_s_mov(end) >= 3
          plot([3 3], ylim_tmp, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
          if k == 1
            legend_string = [legend_string '''RT = 3 sec'', ''Location'', ''NorthWest'');'];
          end
        else
          if k == 1
            legend_string = [legend_string '''Location'', ''NorthEast'');'];
          end
        end
        if k == 1
          legend_handle = eval(legend_string);
          set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, 'box', 'off');
        end
        box on;
        if ~strcmpi(freq_name, '\alpha + \theta');
        title(['\color[rgb]{' freq_color(2 : end - 1) '}' freq_name '\color[rgb]' FONT_COLOR ' band'], ...
            'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'middle');%, 'FontWeight', 'bold');
        else
        title(['(\color[rgb]{' freq_color(2 : end - 1) '}' freq_name '\color[rgb]' FONT_COLOR ') bands'], ...
            'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'middle');%, 'FontWeight', 'bold');
        end
        %x and y labels
        if k == 1
          %y label
          ylabel('Power Increase (dB)', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'baseline', 'FontSize', AXIS_FSIZE);
          %x label
          subplot('position', [.055 .01 .89 .025]); axis off;
          text(.5, .5, 'Moving Averaged Reaction Time (sec)', ...
              'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', 'FontSize', AXIS_FSIZE);
        end
      end  %if j == 2
    end  %k (# of freq bands)
  end

%% save figure;
  str1 = EPOCH_TYPE{1};
  str2 = EPOCH_TYPE{2};
  if isempty(str1)
    str1 = 'baseline';
  end
  if isempty(str2)
    str2 = 'baseline';
  end
%   save([FilePath MN SL ...  %no need to save the variables now
%       'IC' num2str(i, '%02d') '_compare_' str1 '_' str2 '_' MN '_' int2str(nor) rj], ...
%          'PB_mov_diff', 'FREQ_INC_DIFF', 'H_mask_diff', 'P_mask_diff');
  saveas(1053, [FilePath MN SL ...
      'IC' num2str(i, '%02d') '_compare_' str1 '_' str2 '_' MN '_' int2str(nor) rj SD noband '.fig']);
%   print('-dpng', [FilePath MN SL ...
%       'IC' num2str(i, '%02d') '_compare_' str1 '_' str2 '_' MN '_' int2str(nor) rj '.png']);
  close(1053);

%%
end