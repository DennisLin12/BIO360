% Preprocessing for drowsiness (long-term and single trial) in BRC
% by poem
% ver 200809

clear all;
FilePath = '';
if isunix
  mypath;
%   FilePath = '~/Drowsiness/';
  FilePath = '~/liang/';
  HeadFilePath = '/home/eeglab5.03/eeglab5.03/plugins/dipfit2.0/standard_BESA/';  %.4
  SL = '/';
end
hdmfile = [HeadFilePath 'standard_BESA.mat'];
mrifile = [HeadFilePath 'avg152t1.mat'];
chanfile = [HeadFilePath 'standard-10-5-cap385.elp'];
DataFormat = '16';
SET = {
%        's05_061019';
%        's05_061101';
%        's18_060120';
%        's18_060121';
%        's18_060228';
%        's22_060718A';
%        's23_060707';
%        's23_060711B';
%        's31_061020m';
       's41_061225';
%        's41_070117';
%        's48_080501n';
%        's22_080513m';
%        's48_080516m';
%        's41_080520m';
%        's49_080527n';
%        's22_080529n';
%        's41_080530n';
%        's49_080602m';
%        's50_080725n';
%        's50_080731m';
%        's45_070321';
%        's32_061031';
%        's31_061103';
%        's30_061121';
%        's35_070322';
%        's36_061221';
%        's39_070117';
%        's40_070124';
%        's40_070207';
%        's44_070325';
%        's43_070202';
%        's43_070205';
%        's43_070208';
%        's39_061218';
%        's35_070115';
%        's40_070131';
%        's44_070126';
%        's36_061122';
%        's45_070307';
      };
% CASE = {
%         'penta';
%        };
ExtractEpoch = {%{epoch type}, 'epoch type name', [from m sec before], [to n sec after];
                {'1251', '1252', '2251', '2252', '3251', '3252', ...
                '4251', '4252', '5251', '5252', '6251', '6252'}, '_dev_on', -1, 7;  %1 sec before dev_on, 7 sec after dev_on
                {'1253', '2253', '3253', '4253', '5253', '6253'}, '_act_on', -2, 4;  %2 sec before act_on, 4 sec after act_on
                {'1254', '2254', '3254', '4254', '5254', '6254'}, '_act_off', -2, 4;  %2 sec before act_off, 4 sec after act_off
               };
EpochType = {
             '01';
             '02';
             '03';
             '04';
             '05';
             '06';
            };
DeleteChannel = [1 2 5 6 27 33];
rj = '_rj';

FilePathOld = FilePath; 

%% begin preprocessing 
for i = 1 : size(SET, 1)
  RT = [];  %reaction time of each trial
  [ALLEEG EEG CURRENTSET ALLCOM] = eeglab;
  FilePath = FilePathOld;
  Set = SET{i, 1};
  FilePath = [FilePath Set SL];
  ChanLoc = [Set '.xyz'];
  CNT_FILE = [Set '.cnt'];
  %CNT_FILE = ['s45nm-070321.cnt'];
  EVENT_FILE = [Set '_event.txt'];
  [subj ExpDate] = strtok(Set, '_'); ExpDate = ExpDate(2 : end);
  rj_latency1 = []; rj_latency2 = [];% rj_latency2A = []; rj_latency3 = [];  %for storing rejected EEG intervals
  
%% interpolate events
  try
    evt = load([FilePath EVENT_FILE]);  %sxx_yymmdd_event_new.txt
  catch
    error('Fail to load modified event file');
  end
  evt(:, [3 4]) = [];
  %calculate time difference between 2 events for future use
  evt(1, 4) = 8;
  for j = 2 : size(evt, 1)
    evt(j, 4) = evt(j, 3) - evt(j - 1, 3);
  end
  %interpolate  (no event when crashing => interpolate)
  evt_tmp1 = [];
  idx = find((evt(:, 2) == 0 | evt(:, 2) == 233) & evt(:, 4) > 10);
  for j = 1 : size(idx, 1)
    evt_tmp1 = [evt_tmp1; evt(idx(j) - 1, :); evt(idx(j), :)];
  end
  evt_tmp2 = [];
  for j = 1 : 2 : size(evt_tmp1, 1)
    for k = evt_tmp1(j, 3) + 8 : 8 : evt_tmp1(j + 1, 3) - 1
      evt_tmp2 = [evt_tmp2; evt_tmp1(j + 1, 1 : 2) k 8];
    end
  end
  evt = [evt; evt_tmp2];
  evt = sortrows(evt, 3);
  %fix index of event
  if ~isequal(evt(:, 1), (1 : size(evt(:, 1), 1))')
    evt(:, 1) = (1 : size(evt(:, 1), 1))';
  end
  evt(:, 4) = [];
  evt = sortrows(evt, [1 3]);
  clear evt_compact_idx evt_tmp1 evt_tmp2;

%% check if incomplete or error trial exists
  %fix the first and the last events
  if evt(1, 2) > 250  %1st point
    evt(1, 2) = evt(2, 2);
  end
  if evt(end, 2) > 250 && evt(end, 2) ~= 254  %last point
    evt(end, 2) = evt(end - 1, 2);
  end
  %extract event mark
  evt_tmp = find(evt(:, 2) >= 250);  %evt: event file
  evt_mark = evt(evt_tmp, :);
  help DR_check_incomplete;
  [evt_mark evt_tmp] = DR_check_incomplete(evt_mark, 2);
  if ~isempty(evt_tmp)
    fprintf('Manually remove incomplete trials:\n');
    fprintf('Save rj_latency1:\n');
    fprintf('');  
    keyboard;  %setting breakpoint
  end
  rj_latency1 = round(rj_latency1 / 2);  %downsampling to 250 Hz
  fprintf('Press "Continue" in "Debug" menu or type "dbcont" in command line to save file.\n');  %confirm to prevent overwriting files
  keyboard;
  try
    save([FilePath Set '_rejected_trials'], 'rj_latency1', '-append');  %save rejected information
  catch
    save([FilePath Set '_rejected_trials'], 'rj_latency1');
  end
  %after this step, evt_mark should be [(251/252) - 253 - 254] + [(251/252) - 253 - 254] ...
  %save information of each epoch (behavior time)

%% modify event value according to reaction time
  epoch_inf = [];
  for j = 1 : 3 : size(evt_mark, 1)
    RT_tmp = (evt_mark(j + 1, 3) - evt_mark(j, 3)) / 500;
    epoch_inf_tmp = [
                     (j + 2) / 3, ...  %evt_idx
                     evt_mark(j, 1), ...  %original index of dev_on
                     evt_mark(j, 2), ...  %original event type of dev_on
                     evt_mark(j, 3), ...  %latency of dev_on
                     evt_mark(j + 1, 1), ...  %original index of act_on
                     evt_mark(j + 1, 2), ...  %original event type of act_on
                     evt_mark(j + 1, 3), ...  %latency of act_on
                     evt_mark(j + 2, 1), ...  %original index of dev_off
                     evt_mark(j + 2, 2), ...  %original event type of dev_off
                     evt_mark(j + 2, 3), ...   %latency of dev_off
                     RT_tmp  %RT
                    ]';
    if RT_tmp < 0.4
      epoch_inf_tmp([3 6 9]) = epoch_inf_tmp([3 6 9]) + 1000;
      evt_mark(j : j + 2, 2) = evt_mark(j : j + 2, 2) + 1000;
    elseif 0.4 <= RT_tmp && RT_tmp <= 0.65
      epoch_inf_tmp([3 6 9]) = epoch_inf_tmp([3 6 9]) + 2000;
      evt_mark(j : j + 2, 2) = evt_mark(j : j + 2, 2) + 2000;
    elseif 0.65 < RT_tmp && RT_tmp < 0.95
      epoch_inf_tmp([3 6 9]) = epoch_inf_tmp([3 6 9]) + 3000;
      evt_mark(j : j + 2, 2) = evt_mark(j : j + 2, 2) + 3000;
    elseif 0.95 <= RT_tmp && RT_tmp <= 1.25
      epoch_inf_tmp([3 6 9]) = epoch_inf_tmp([3 6 9]) + 4000;
      evt_mark(j : j + 2, 2) = evt_mark(j : j + 2, 2) + 4000;
    elseif 1.25 < RT_tmp && RT_tmp <= 5
      epoch_inf_tmp([3 6 9]) = epoch_inf_tmp([3 6 9]) + 5000;
      evt_mark(j : j + 2, 2) = evt_mark(j : j + 2, 2) + 5000;
    else
      epoch_inf_tmp([3 6 9]) = epoch_inf_tmp([3 6 9]) + 6000;
      evt_mark(j : j + 2, 2) = evt_mark(j : j + 2, 2) + 6000;
    end
    for k = 2 : 3 : 8
      evt(epoch_inf_tmp(k), 2) =  epoch_inf_tmp(k + 1);
    end
    RT = [RT; [RT_tmp epoch_inf_tmp(4)]];
    %save latency of each event in each trial
    %1: trial idx; 5, 6, and 7: dev_on act_on act_off; 10: retain; others: kept for futher use
    epoch_inf = [epoch_inf; epoch_inf_tmp(1) -Inf -Inf -Inf epoch_inf_tmp(4 : 3 : 10)' Inf Inf Inf 1];
  end
  for j = 1 : size(epoch_inf, 1)
    if j > 1
      epoch_inf(j, 2 : 4) = epoch_inf(j - 1, 5 : 7);  %latency of the PREVIOUS epoch
    end
    if j ~= size(epoch_inf, 1)
      epoch_inf(j, 8 : 10) = epoch_inf(j + 1, 5 : 7);  %latency of the NEXT epoch
    end
  end
  clear epoch_inf_tmp;
  RT_original = RT;
  RT = RT(:, 1)';

%% EEG preprocessing: phase I
  %load raw EEG data
  EEG = DR_pop_loadcnt(CNT_FILE, 'dataformat', ['int' DataFormat]);
  [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', Set, 'overwrite', 'on');
  EEG = eeg_retrieve(ALLEEG, 1);
  CURRENTSET = 1;
  eeglab redraw;
  %clear event
  EEG.event = [];
  eeglab redraw;
  %select channel
  if ~isempty(DeleteChannel)
    EEG = pop_select(EEG, 'nochannel', DeleteChannel);
  end
%   EEG.chanlocs = pop_chanedit(EEG.chanlocs, 'load',{ChanLoc, 'filetype', 'xyz eeglab'}, 'delete', 1 : 5);
%   eeglab redraw;
  [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', Set, 'overwrite', 'on');
  %50Hz LPF
  EEG = pop_eegfilt(EEG, 0, 50, [], 0);
  eeglab redraw;
  fprintf('\n');
  [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', Set, 'overwrite', 'on');
  %0.5Hz HPF
  EEG = pop_eegfilt(EEG, 0.5, 0, [], 0);
  eeglab redraw;
  fprintf('\n');
  [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', Set, 'overwrite', 'on');
  %down sampling
  EEG = pop_resample(EEG, 250);
  eeglab redraw;
  fprintf('\n');
  %save dataset ("_pre")
  EEG = pop_editset(EEG, 'setname',  [Set '_pre']);
  [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
%   EEG = pop_saveset(EEG, [FilePath Set '_pre.set']);
  %import eventfile
%   %make fake channel (35, 39, and 40)
%   evt(:, 4) = round(evt(:, 3) / 2);  %original 500 Hz => 250 Hz
%   RT(:, 2) = round(RT(:, 2) / 2);
%   %for event file
%   EEG.data(40, :) = -1;
%   EEG.data(40, evt(:, 4)') = -evt(:, 2)';
%   EEG.data(39, RT(:, 2)) = RT(:, 1);
  %for checking abnormal behavior
  traj = [evt(:, 2) evt(:, 3)];
  dev_on = []; act_on = []; act_off = [];
  pre_dev_on = []; post_act_off = [];
%   dev_on = traj(find(mod(traj(:, 1), 1000) == 251 | mod(traj(:, 1), 1000) == 252), :);  %deviation onset
%   act_on = traj(find(mod(traj(:, 1), 1000) == 253), :);  %response onset
%   act_off = traj(find(mod(traj(:, 1), 1000) == 254 | mod(traj(:, 1), 1000) == 255), :);  %response offset
%   clear evt;
  %remove event points
  if mod(traj(1, 1), 1000) == 251 || mod(traj(1, 1), 1000) == 252  %must be dev_on; checked before
    traj(1, 1) = traj(2, 1);
  end
  if mod(traj(end, 1), 1000) == 254  %must be act_off; checked before
    traj(end, 1) = traj(end - 1, 1);
  end
  for j = 2 : size(traj, 1) - 1
    if mod(traj(j, 1), 1000) == 251  %dev_on
      traj(j, 1) = traj(j - 1, 1);
      direct = 0;  %left
      dev_on = [dev_on; j traj(j, :)];
    elseif mod(traj(j, 1), 1000) == 252  %dev_on
      traj(j, 1) = traj(j - 1, 1);
      direct = 1;  %right
      dev_on = [dev_on; j traj(j, :)];
    elseif mod(traj(j, 1), 1000) == 253 || mod(traj(j, 1), 1000) == 254 || mod(traj(j, 1), 1000) == 255  %act_on and dev_off
      if j > 10
        Prev = find(traj(j - 10 : j - 1, 1) < 250, 1, 'last');
        Prev = traj(j - 11 + Prev, 1);
      else
        Prev = find(traj(1 : j - 1, 1) < 250, 1, 'last');
        Prev = traj(Prev, 1);
      end
      if j <= size(traj, 1) - 10
        Next = find(traj(j + 1 : j + 10, 1) < 250, 1, 'first');
      else
        Next = find(traj(j + 1 : end, 1) < 250, 1, 'first');
      end
      Next = traj(j + Next, 1);
      if mod(traj(j, 1), 1000) == 253  %act_on
        if direct == 0  %left
          traj(j, 1) = min(Prev, Next);
        else  %right
          traj(j, 1) = max(Prev, Next);
        end
        act_on = [act_on; j traj(j, :)];
      else  %act_off
        traj(j, 1) = round((Prev + Next) / 2);
        act_off = [act_off; j traj(j, :)];
      end
    end
  end
  for j = 1 : size(dev_on, 1)  %labeling pre_dev_on
    pre_dev_on_tmp = dev_on(j, 3) + ExtractEpoch{1, 3} * 500;  %use + since dev_on_start < 0
    if j == 1
      pre_dev_on_tmp2 = find(traj(1 : dev_on(j, 1), 2) <= pre_dev_on_tmp, 1, 'last');
      if ~isempty(pre_dev_on_tmp2)
        pre_dev_on = [pre_dev_on; traj(pre_dev_on_tmp2, :)];
      else
        pre_dev_on = [pre_dev_on; NaN traj(1, 3)];
      end
    else
      pre_dev_on_tmp2 = find(traj(dev_on(j - 1, 1) : dev_on(j, 1), 2) <= pre_dev_on_tmp, 1, 'last');
      pre_dev_on = [pre_dev_on; traj(dev_on(j - 1, 1) + pre_dev_on_tmp2 - 1, :)];
    end
  end
  for j = 1 : size(act_off, 1)  %labeling post_act_off
    post_act_off_tmp = act_off(j, 3) + ExtractEpoch{3, 4} * 500;
    if j == size(act_off, 1)
      post_act_off_tmp2 = find(traj(act_off(j, 1) : end, 2) >= post_act_off_tmp, 1, 'first');
      if ~isempty(post_act_off_tmp2)
        post_act_off = [post_act_off; traj(act_off(j, 1) + post_act_off_tmp2, :)];
      else
        post_act_off = [post_act_off; Inf traj(end, 2)];
      end
    else
      post_act_off_tmp2 = find(traj(act_off(j, 1) : act_off(j + 1, 1), 2) >= post_act_off_tmp, 1, 'first');
      if isempty(post_act_off_tmp2)
        post_act_off_tmp2 = find(traj(act_off(j, 1) : end, 2) >= post_act_off_tmp, 1, 'first');
      end
      post_act_off = [post_act_off; traj(act_off(j, 1) + post_act_off_tmp2 - 1, :)];
    end
  end
  %plot trajectory for inspection behavior data
  figure; hold on;
  plot(traj(:, 2) / 500, traj(:, 1), 'Color', [.5 .5 .5], 'LineWidth', 1.5);  %plot trajectory
  plot(dev_on(:, 3) / 500, dev_on(:, 2), 'LineStyle', 'none', ...
      'Marker', 'o', 'MarkerEdgeColor', 'r', 'MarkerFaceColor', 'r', 'MarkerSize', 3);  %mark dev_on
  plot(act_on(:, 3) / 500, act_on(:, 2), 'LineStyle', 'none', ...
      'Marker', 'o', 'MarkerEdgeColor', 'g', 'MarkerFaceColor', 'g', 'MarkerSize', 3);  %mark act_on
  plot(act_off(:, 3) / 500, act_off(:, 2), 'LineStyle', 'none', ...
      'Marker', 'o', 'MarkerEdgeColor', 'b', 'MarkerFaceColor', 'b', 'MarkerSize', 3);  %mark dev_off
  %marking pre_dev_on and post_dev_off
  for j = 1 : size(pre_dev_on, 1)
    try
    plot([pre_dev_on(j, 2) / 500 pre_dev_on(j, 2) / 500], [0 250], 'Color', [0 0 0], 'LineWidth', 1, 'LineStyle', ':');
    plot([post_act_off(j, 2) / 500 post_act_off(j, 2) / 500], [0 250], 'Color', [.75 .75 .75], 'LineWidth', 1, 'LineStyle', '-.');
    %adding # of trial
    text((pre_dev_on(j, 2) + post_act_off(j, 2)) / 2 / 500, 250, int2str(j), 'FontSize', 12, 'FontWeight', 'bold', ...
        'FontName', 'Helvetica', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'cap');
    text(dev_on(j, 3) / 500, dev_on(j, 2) - 15, num2str(RT(j), '%0.2f'), 'FontSize', 12, 'FontWeight', 'bold', ...
        'FontName', 'Helvetica', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'cap');
    end
  end
  %adding boundary of the 3rd lane
  plot([0 traj(end, 2) / 500], [130 130], 'Color', [.75 .75 .75], 'LineWidth', .5, 'LineStyle', '--');  %left bound
  plot([0 traj(end, 2) / 500], [175 175], 'Color', [.75 .75 .75], 'LineWidth', .5, 'LineStyle', '--');  %right bound
  saveas(gcf, [FilePath Set '_raw_traj.fig']);
  rj_behave = input('Input the indices of bad behavior trials. 0: no bad trials: ');
  if ~rj_behave
    rj_behave = [];
  end
  EEG = pop_importevent(EEG, 'append', 'no', 'event', [evt_mark(:, [1 2]), round(evt_mark(:, 3) / 2)], ...
      'fields', {'index', 'type', 'latency'}, 'skipline', 0, 'timeunit', 0.004, 'align', NaN);
  eeglab redraw;
  EEG = eeg_eegrej(EEG, rj_latency1);
  try
    %read digitized one
    try
      EEG.chanlocs = pop_chanedit(EEG.chanlocs, 'load',{ChanLoc, 'filetype', 'xyz eeglab'}, 'delete', [1:7 10 11 32 38], 'eval', 'chantmp = pop_chancenter(chantmp, [], []);');
    catch
      EEG.chanlocs = pop_chanedit(EEG.chanlocs, 'load',{ChanLoc, 'filetype', 'xyz eeglab'}, 'eval', 'chantmp = pop_chancenter(chantmp, [], []);');
    end
  catch
  %read channel locations (standard)
    EEG.chanlocs = pop_chanedit(EEG.chanlocs, 'load', {'~/30ch.xyz', 'filetype', 'xyz eeglab'}, ...
        'eval', 'chantmp = pop_chancenter(chantmp, [], []);');
  end
  eeglab redraw;
  EEG_old = EEG;  %keep original EEG for further use
  for j = 1 : size(ExtractEpoch, 1)
    Epoch = ExtractEpoch{j, 1};
    EEG = pop_epoch(EEG, Epoch, [ExtractEpoch{j, 3} ExtractEpoch{j, 4}], 'newname',  [Set ExtractEpoch{j, 2}], 'epochinfo', 'yes');
%   EEGtmp = EEG.data;  %keep fake channels
%   EEG = pop_select(EEG, 'nochannel', 31 : 40);  %temporarily remove fake channels
    EEG = pop_rmbase(EEG, [ExtractEpoch{j, 3} * 1000 0]);
%   for j = 1 : size(EEG.data, 3)  %reload fake channels
%     EEG.data([35 39 40], :, j) = EEGtmp([35 39 40], :, j);
%   end
%   clear EEGtmp
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', [Set ExtractEpoch{j, 2}], 'overwrite', 'off');
    eeglab redraw;
    %save dataset with designated epoch
    EEG = pop_saveset(EEG, [FilePath Set ExtractEpoch{j, 2} '.set']);
%   [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
    if j == 1
      alltrialtag = [0 (1 : EEG.trials) * EEG.pnts];
      eegplot(EEG.data, 'srate', 250, 'dispchans', 29, 'spacing', 100, 'winlength', 5, 'events', EEG.event, 'command', ...
          'TMPREJ = sortrows(TMPREJ, 1); rj_tmp = TMPREJ(:, 2) / (EEG.pnts);', 'position', [0, 0, 1024, 768], 'wincolor', [1 1 .783]);
      keyboard;
      eeglab redraw;
      eval(['rj' ExtractEpoch{j, 2} ' = rj_tmp'';']);
    end
    EEG = EEG_old;
  end
%%
  clear EEG_old;
  eeglab;  %clear EEG dataset; reload later
  %merge all rejected trials in each criterion
  rj_latency2 = union(rj_behave, rj_dev_on);
%   rj_latency2 = union(rj_latency2, rj_act_on);
%   rj_latency2 = union(rj_latency2, rj_act_off);
  RT(rj_latency2) = [];
  keyboard;
  epoch_inf(rj_latency2, 11) = 0;  %0: this epoch will be rejected
  save([FilePath Set '_RT_of_trials'], 'RT', 'RT_original');
%   save([FilePath Set '_rejected_trials'], 'rj_latency2', 'rj_behave', 'rj_dev_on', 'rj_act_on', 'rj_act_off', '-append');  %save rejected trials
  save([FilePath Set '_rejected_trials'], 'rj_latency2', 'rj_behave', 'rj_dev_on', '-append');  %save rejected trials
  save([FilePath Set '_epoch_inf'], 'epoch_inf');  %save latency of each event in eachtrial
  for j = 1 : size(ExtractEpoch, 1)  %extract epoch
    EEG = pop_loadset([FilePath Set ExtractEpoch{j, 2} '.set']);
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', [Set ExtractEpoch{j, 2}], 'overwrite', 'on');
    eeglab redraw;
    EEG = pop_select(EEG, 'notrial', rj_latency2);
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', [Set ExtractEpoch{j, 2} rj], 'overwrite', 'on');
    EEG = pop_editset(EEG, 'setname',  [Set ExtractEpoch{j, 2} rj]);
    eeglab redraw;
    EEG = pop_saveset(EEG, [FilePath Set ExtractEpoch{j, 2} rj '.set']);

%% run ICA and fit dipole   
    if j == 1
      %run ICA
      diary([FilePath Set '_ICA_log.txt']);
      %ALLEEG = pop_runica(ALLEEG, 'icatype', 'runica', 'dataset', 1 : 3, 'options', {'extended', 1});
      EEG = pop_runica(EEG, 'icatype', 'runica', 'options', {'extended', 1, 'maxsteps', 1024, 'stop', 1e-7});
      diary off;
      EEG = pop_saveset(EEG, [FilePath Set ExtractEpoch{j, 2} rj '.set']);
      pop_topoplot(EEG, 0, 1 : size(EEG.icaact, 1), [subj '\_' ExpDate], [5 6], 0, 'electrodes', 'off', 'masksurf', 'on');
      print('-dpng', [FilePath Set '_component_map_intrial' rj '.png']);
      %fit dipole
      EEG = pop_dipfit_settings(EEG, 'hdmfile', hdmfile, 'coordformat', 'Spherical', 'mrifile', mrifile, 'chanfile', chanfile, 'chansel', 1 : size(EEG.data, 1));
      %fit the headshape (coarse fit)
      EEG = pop_dipfit_gridsearch(EEG, 1 : size(EEG.icaact, 1), -85 : 5 : 85, -85 : 5 : 85, 0 : 5 : 85, 0.4);
      pop_dipfit_nonlinear(EEG);  %finefit.
      keyboard;  %seting breakpoint
      %assign weight vectors and dipole information to the other datasets
%       icaact = EEG.icaact;
      icawinv = EEG.icawinv;
      icasphere = EEG.icasphere;
      icaweights = EEG.icaweights;
      icachansind = EEG.icachansind;
      dipfit = EEG.dipfit;
    else
%       EEG.icaact = icaact;  %%%WRONG!!
      EEG.icaact = icaweights * icasphere * reshape(EEG.data, size(EEG.data, 1), size(EEG.data, 2) * size(EEG.data, 3));
      EEG.icaact = reshape(EEG.icaact, size(EEG.data, 1), size(EEG.data, 2), size(EEG.data, 3));
      EEG.icawinv = icawinv;
      EEG.icasphere = icasphere;
      EEG.icaweights = icaweights;
      EEG.icachansind = icachansind;
      EEG.dipfit = dipfit;
      eeglab redraw;
%       [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
    end
    EEG = pop_saveset(EEG, [FilePath Set ExtractEpoch{j, 2} rj '.set']);

%% split dataset into groups
%     EPOCH = ExtractEpoch{j, 1};
%     Epoch_name = ExtractEpoch{j, 2};
%     Epoch_start = ExtractEpoch{j, 3};
%     Epoch_end = ExtractEpoch{j, 4};
%     for k = 1 : size(EpochType, 1)
%       condition = EpochType{k};
%       if j == 1  %dev_on, x251 and x252
%         Epoch = [EPOCH(2 * k - 1) EPOCH(2 * k)];
%       else
%         Epoch = EPOCH(k);
%       end
%       try
%         if j == 1
%           fprintf(['Epoching epoch type ' EPOCH{2 * k - 1} ' and/or ' EPOCH{2 * k} '...\n']);
%         else
%           fprintf(['Epoching epoch type ' EPOCH{k} '...\n']);
%         end
%         EEG = pop_epoch(EEG, Epoch, [Epoch_start Epoch_end], 'newname',  [Set Epoch_name condition rj], 'epochinfo', 'yes');
%         EEG = pop_rmbase(EEG, [Epoch_start * 1000 0]);
%         [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', [Set Epoch_name condition rj], 'overwrite', 'off');
%         [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
%         eeglab redraw;
%         EEG.icaact = icaact;
%         EEG.icawinv = icawinv;
%         EEG.icasphere = icasphere;
%         EEG.icaweights = icaweights;
%         EEG.icachansind = icachansind;
%         EEG.dipfit = dipfit;
%         eeglab redraw;
%         EEG = pop_saveset(EEG, [FilePath Set Epoch_name condition rj]);
%         ALLEEG = pop_delset(ALLEEG, 2);
%         eeglab redraw;
%       catch
%         if j == 1
%           fprintf(['Event epoch type ' EPOCH{2 * k - 1} ' and/or ' EPOCH{2 * k} ': no such events\n']);
%         else
%           fprintf(['Event epoch type ' EPOCH{k} ': no such events\n']);
%         end
%       end
%     end
  end
end