%component maps, dipoles and power spectra in a cluster
%ver 200903
%pre_ver: DR_PlotCompPowerDipole_200902_final

%% set parameters (initialize)
try
  close(4001);
end
try
  close(4002);
end
try
  close(4003);
end
try
  close(4004);
end
try
  close(4009);
end
try
  close(166);
end
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/';  %directory
  SL = '/';
end
DR_PBase_setup;  %load setup file
%datasets
PLOT_SET = {
            's01_061102';  %motionless
            's05_061101';  %motionless
            's31_061103';  %motionless
            's32_061031';  %motionless
            's35_070322';  %motionless
            's36_061221';  %motionless
%             's37_071213';  %motionless
%             's39_070117';  %motionless
            's40_070207';  %motionless
            's41_061225';  %motionless
            's42_070105';  %motionless
            's43_070208';  %motionless
            's44_070325';  %motionless
            's05_061019';  %motion
            's31_061020';  %motion
            's35_070115';  %motion
            's36_061122';  %motion
%             's39_061218';  %motion
            's40_070131';  %motion
            's43_070202';  %motion
%             's44_070126';  %motion
            's44_070209';  %motion
           };
MN = 'motionless';
if strcmpi(MN, 'motionless')
  MN_COLOR = '{0 0 1}';
elseif strcmpi(MN, 'motion')
  MN_COLOR = '{1 0 0}';
else
  MN_COLOR = '{0 1 0}';
end
FilePathOld = FilePath;
rj = '_rj';
n_of_cls = size(ClsLabel, 1);  %# of cluster
undef_cls = n_of_cls + 1;
%axes limites for plotting power spectra
% power_xlim = [0 50];
power_xlim = [min_freq max_freq];  %frequency
% power_ylim = [-30 10];
power_ylim = [0 30];  %dB
avg = '_trim';  %method for averaging

%for component map
%load standard channel labels
switch(allchans)
  case 30
    std_chanlocs = '/home/poem/30ch.xyz';  %standard channel location file  **notice directory
  case 36
    std_chanlocs = '/home/poem/36ch.xyz';  %standard channel location file
%   case 64
%   case 128
  otherwise
    std_chanlocs = '/home/poem/30ch.xyz';  %standard channel location file
end
chanlocs_tmp = textread(std_chanlocs, '%s')';
chanlocs_tmp = reshape(chanlocs_tmp, 5, length(chanlocs_tmp) / 5);
% std_chanlabel = {'Fp1', 'Fp2', ...
%     'F7', 'F3', 'Fz', 'F4', 'F8', ...
%     'FT7', 'FC3', 'FCz', 'FC4', 'FT8', ...
%     'T3', 'C3', 'Cz', 'C4', 'T4', ...
%     'TP7', 'CP3', 'CPz', 'CP4', 'TP8', ...
%     'T5', 'P3', 'Pz', 'P4', 'T6', ...
%     'O1', 'Oz', 'O2'};
std_chanlabel = chanlocs_tmp(5, :);
clear chanlocs_tmp

%% assign component to cluster
for i = 1 :size(ClsLabel, 1)
  com = sprintf('IC%02d = {ClsLabel{%d}};', i, i); eval(com);
end
for i = 1 : size(PLOT_SET, 1)
  FilePath = FilePathOld;
  plot_set = PLOT_SET{i, 1};
  %check if the plot_set is valid
  for j = 1 : size(SET, 1)
    Set = SET{j, 1};
    condition = SET{j, 3};
    if strcmp(Set, plot_set)  %dataset found in database, checking if condition is ok
%       oldcls = zeros(1, size(ClsLabel, 1));  %register to memorize if the cluster shown before
      if strcmp(condition, MN)  %condition ok => dataset valid => process
        COMP = SET{j, 2};
        EEG = pop_loadset([FilePath Set SL Set '_dev_on' rj '.set']);
        stmp = EEG;
%         stmp.chanlocs = EEG.chanlocs;
%         if i == 1  %load standard channel location
        if ~isstruct(std_chanlocs)  %load standard channel location
          EEG.chanlocs = pop_chanedit(EEG.chanlocs, 'load', {std_chanlocs, 'filetype', 'xyz eeglab'}, ...
              'eval', 'chantmp = pop_chancenter(chantmp, [], []);');
          std_chanlocs = EEG.chanlocs;
        end
        if ~isfield(EEG, 'dipfit') || isempty(EEG.dipfit)
          fprintf('Dipole not fitted in this dataset. Press "Continue" in Debug menu or type "dbcont" in command line to continue: \n');
          keyboard;
          %register channel
          EEG = pop_dipfit_settings(EEG, 'hdmfile', hdmfile, 'coordformat', 'Spherical', 'mrifile', mrifile, 'chanfile', chanfile, 'chansel', allcomp);
          %fit the headshape (coarse fit)
          EEG = pop_dipfit_gridsearch(EEG, allcomp, -85 : 5 : 85, -85 : 5 : 85, 0 : 5 : 85, 0.4);
          pop_dipfit_nonlinear(EEG);  %finefit.
          keyboard;  %seting breakpoint
          %save the fitted dataset
          EEG = pop_saveset(EEG, [FilePath Set SL Set '_intrial' rj '.set']);
        end
        stmp.dipfit = EEG.dipfit;
        com = sprintf('%s = stmp;', Set); eval(com);
        clear EEG stmp;
        for k = 1 : size(COMP, 2)
          comp = COMP(1, k);  %componet #
          comp_cls = COMP(2, k);  %#which cluster
          if comp_cls > 0
            IC_tmp = {Set, comp};
            com = sprintf('IC%02d = [IC%02d IC_tmp];', comp_cls, comp_cls); eval(com);
          end
        end
      else  %codition not ok => invalid
        fprintf('%s: not valid, check set name or condition (motion/motionless).\n', plot_set);
      end
      break;
    end
    if j == size(SET, 1)  %not able to find dataset
      fprintf('%s: not valid, check set name or condition (motion/motionless).\n', plot_set);
    end
  end
end

for i = 1 : size(ClsLabel, 1)
%% computation - setups
  eval(['IC_tmp = IC' num2str(i, '%02d') ';']);
  cls_length = (size(IC_tmp, 2) - 1) / 2;
  subplt_width = ceil(sqrt(cls_length + 1));
  subplt_height = floor(sqrt(cls_length + 1));
  if cls_length + 1 > subplt_width * subplt_height
    subplt_height = subplt_height + 1;
  end
  %for dipoles
  subplt_x_dip = floor(10000 / subplt_width) / 10000;  %floor(10000 / 3) / 10000 = .3333
  subplt_y_dip = floor(10000 / subplt_height) / 10000;  %floor(10000 / 6) / 10000 = .1666 < roundn(1/6, -4) = .1667
  blank_x_dip = (1 - subplt_x_dip * subplt_width) / 2;
  blank_y_dip = (1 - subplt_y_dip * subplt_height) / 2;
  chan_all = {};  %cell for storing channel locations
  negate = 0;
  figs = [];
  icawinv = [];  %column: icawinv of each component
  spec_all = [];  %array for storing spectra
  dipole_all = {};  %cell for storing dipole
  diffmap = [];
  rv_all = 0;
  diffmap_all = [];
  fp = fopen([FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_ClsDipole_' cls_ver '_' MN '.txt'], 'w');  %for saving talairach coordinates in a text file
%   fp = fopen(['~/IC' num2str(i, '%02d'), '_ClsDipole_' cls_ver '_' MN '.txt'], 'w');  %for saving talairach coordinates in a text file
  if i ~= 9 && i ~= 10
    posxyz_all = NaN(cls_length + 2, 3) ;  %for making tables of Talairach coordinates, etc. last 2 rows: avg & SD
    momxyz_all = NaN(cls_length + 2, 3) ;
    eleccoord_all = NaN(cls_length + 2, 3) ;
    mnicoord_all = NaN(cls_length + 2, 3) ;
    talcoord_all = NaN(cls_length + 2, 3) ;
    fprintf(fp, 'Set\tComponent\tTalairach Coordinates\r\n');
    fprintf(fp, '\t\tX\tY\tZ\r\n');
  else
    posxyz_all = NaN(cls_length + 2, 6) ;  %may have 2 dipoles
    momxyz_all = NaN(cls_length + 2, 6) ;
    eleccoord_all = NaN(cls_length + 2, 6) ;
    mnicoord_all = NaN(cls_length + 2, 6) ;
    talcoord_all = NaN(cls_length + 2, 6) ;
    fprintf(fp, 'Set\tComponent\tTalairach Coordinates (Left)\tTalairach Coordinates (Right)\r\n');
    fprintf(fp, '\t\tX\tY\tZ\tX\tY\tZ\r\n');
  end

  for j = 1 : cls_length
    plot_set = IC_tmp{1, 2 * j};
    plot_comp = IC_tmp{1, 2 * j + 1};
    com = sprintf('EEG = %s;', plot_set); eval(com);
    [subj ExpDate] = strtok(plot_set, '_'); ExpDate = ExpDate(2 : end);
    
%% computation - tackling component map
    chanlocs = EEG.chanlocs;
    chanlabel = {};
    for k = 1 : length(chanlocs)
      chanlabel(k) = {chanlocs(k).labels};
    end
    [tmp_chanlabel chanlabel_diff] = setdiff(upper(std_chanlabel), upper(chanlabel));  %tmp_chanlabel = std_chanlabel - chanlabels
    %negate the weights
%     if size(chanlocs, 2) ~= 30  %missing channel
    if ~isempty(tmp_chanlabel)  %missing channel
%       icawinv_tmp = ones(30, 1) * NaN;
      icawinv_tmp = zeros(30, 1); icawinv_tmp(chanlabel_diff) = NaN;  %NaN: missing channels
      %fill missing channels with NaN
%       for k = 1 : size(chanlocs, 2)
%         icawinv_tmp(chanlocs(k).urchan) = EEG.icawinv(k, plot_comp);
%       end
      icawinv_tmp(find(~isnan(icawinv_tmp))) = EEG.icawinv(:, plot_comp);
      [abs_max max_idx] = max(abs(icawinv_tmp));  % [tmp1 tmp2] = max([1 3 7 5]) => tmp1 = 7, tmp2 = 3
      icawinv = [icawinv icawinv_tmp / icawinv_tmp(max_idx)];
    else
      [abs_max max_idx] = max(abs(EEG.icawinv(:, plot_comp)));  % [tmp1 tmp2] = max([1 3 7 5]) => tmp1 = 7, tmp2 = 3
      icawinv = [icawinv (EEG.icawinv(:, plot_comp)) / (EEG.icawinv(max_idx, plot_comp))];
    end
    chan_all = [chan_all chanlocs];
    %plot a component map
    figure(4009);
    subplot(subplt_height, subplt_width, j);
    DR_topoplot(icawinv(find(~isnan(icawinv(:, j))), j), chanlocs, 'electrodes', 'off', 'shrink', 'force');
    title(int2str(j));
    if j == cls_length
      figure(4009);
      if strcmp(MN, 'motionless')
        if i == 8
          negate = 3;
        elseif i == 9
          negate = [1 2 5:8 10 13 14];
        elseif i == 10
          negate = [3 4 6 7];
        else
          negate = 0;
        end
      elseif strcmp(MN, 'motion')
        if i == 8
          negate = 1;
        elseif i == 9
          negate = [2 4:7];
        elseif i == 10
          negate = [1 3 4];
        else
          negate = 0;
        end
      else
      negate = input('Input index of component to negate corresponding icawinv (0: no need to do this): ');
      end
      if negate
        icawinv(:, negate) = -icawinv(:, negate);
      end
      close(4009);
      comp_corr = triu(corrcoef(icawinv));  %upper triangle matrix of corrcoef(icawinv)
      diag_matrix = zeros(size(comp_corr));
      for k = 1 : size(comp_corr, 1)
        diag_matrix(k, k) = comp_corr(k, k);
      end
      tmp = find(comp_corr > 0);
      avg_corr = mean(comp_corr(tmp));
      sd_corr = std(comp_corr(tmp));
      %computing avg. scalp
      if isempty(find(isnan(icawinv)))  %no missing channels
        avg_icawinv = mean(icawinv, 2);
      else
        avg_icawinv = [];
        for k = 1 : size(icawinv, 1)
          icawinv_tmp = find(~isnan(icawinv(k, :)));  %~isnan([1 NaN 1]) = [1 0 1] => find(~isnan([1 NaN 1])) = [1 3]
          icawinv_tmp = mean(icawinv(k, icawinv_tmp));
          avg_icawinv = [avg_icawinv; icawinv_tmp];
        end
      end
    end

    %tackling power spectra
%     try
    load([FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d') SL ...
        plot_set '_PBaseRT_' num2str(plot_comp, '%02d') rj], 'PB_alert_mean', 'freqs');
%     catch
%     diary('~/1111.txt');
%     fprintf([plot_set '-' num2str(plot_comp, '%02d') ': ' num2str(i, '%02d') '\r\n']);
%     diary off;
%     load([FilePath 'RS' SL MN SL 'IC00' SL ...
%         plot_set '_PBaseRT_' num2str(plot_comp, '%02d') rj], 'PB_alert_mean', 'freqs');
%     end
    PB_alert_mean = PB_alert_mean(:, 1)';  %PB_alert_mean: padded
    spec_all = [spec_all; PB_alert_mean];

%% plotting
    %plot dipole (brighter color)
    subplt_pos_dip = [blank_x_dip + subplt_x_dip * mod((j - 1), subplt_width) + subplt_x_dip * 0.1, ...
                  blank_y_dip + subplt_y_dip * (subplt_height - ceil(j / subplt_width)) + subplt_y_dip * 0.1];
    figure(4001);
    set(gcf, 'Renderer', 'ZBuffer');
    dh(j) = subplot('position', [subplt_pos_dip subplt_x_dip * .8 subplt_y_dip * .75]);% axis tight;
    eval(['dip_tmp = dipplot(EEG.dipfit.model(plot_comp), ''mri'', mrifile, ''view'', view_angle, ''color'', {[1 1 0]}, ' ...
        '''dipolesize'', 20, ''dipolelength'', 0, ' [dip_option ...
        ', ''projimg'', ''off'', ''projlines'', ''on'', ''coordformat'', ''spherical'''] ');']);
    th(j) = subplot('position', [subplt_pos_dip(1) subplt_pos_dip(2) + subplt_y_dip * .75 subplt_x_dip * .8 subplt_y_dip * .15]); axis off;
    text(0.05, .5, ['\color[rgb]{0 0 0}' subj '-' num2str(plot_comp, '%02d')], 'FontName', FONT_FACE, 'FontSize', 8, ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'baseline');
    if ~isfield(EEG.dipfit.model(plot_comp), 'eleccoord') || ~isfield(EEG.dipfit.model(plot_comp), 'talcoord') || ...
            ~isfield(EEG.dipfit.model(plot_comp), 'mnicoord')  %not exist in the original dataset, update the original
      EEG.dipfit.model(plot_comp).eleccoord = dip_tmp.eleccoord;
      EEG.dipfit.model(plot_comp).mnicoord = dip_tmp.mnicoord;
      EEG.dipfit.model(plot_comp).talcoord = dip_tmp.talcoord;
      EEG = pop_saveset(EEG, [FilePath plot_set SL plot_set EpochType{1} rj '.set']);
    end
    dipole_all = [dipole_all dip_tmp];
    rv_all = rv_all + dip_tmp.rv;
    if i ~= 9 && i ~= 10
      posxyz_all(j, :) = dip_tmp.posxyz(1, :);
      momxyz_all(j, :) = dip_tmp.momxyz(1, :);
      eleccoord_all(j, :) = dip_tmp.eleccoord(1, :);
      mnicoord_all(j, :) = dip_tmp.mnicoord(1, :);
      talcoord_all(j, :) = dip_tmp.talcoord(1, :);
    else
      for k = 1 : size(dip_tmp.talcoord, 1)
        if dip_tmp.talcoord(k, 1) < 0  %left
          posxyz_all(j, 1:3) = dip_tmp.posxyz(k, :);
          momxyz_all(j, 1:3) = dip_tmp.momxyz(k, :);
          eleccoord_all(j, 1:3) = dip_tmp.eleccoord(k, :);
          mnicoord_all(j, 1:3) = dip_tmp.mnicoord(k, :);
          talcoord_all(j, 1:3) = dip_tmp.talcoord(k, :);
        else  %right
          posxyz_all(j, 4:6) = dip_tmp.posxyz(k, :);
          momxyz_all(j, 4:6) = dip_tmp.momxyz(k, :);
          eleccoord_all(j, 4:6) = dip_tmp.eleccoord(k, :);
          mnicoord_all(j, 4:6) = dip_tmp.mnicoord(k, :);
          talcoord_all(j, 4:6) = dip_tmp.talcoord(k, :);
        end
      end
    end
    fprintf(fp, '%s\t%d\t', plot_set, plot_comp);
    for k = 1 : size(talcoord_all(j, :), 2)
      if ~isnan(talcoord_all(j, k))
        fprintf(fp, '%.2f', talcoord_all(j, k));
      else
        fprintf(fp, '--');
      end
      if k ~= size(talcoord_all(j, :), 2)
        fprintf(fp, '\t');
      else
        fprintf(fp, '\r\n');
      end
    end
    if ~isempty(tmp_chanlabel)  %missing channel
      diffmap_tmp = zeros(30, 1); diffmap_tmp(chanlabel_diff) = NaN;  %NaN: missing channels
      diffmap_tmp(find(~isnan(diffmap_tmp))) = dip_tmp.diffmap;
      diffmap = [diffmap diffmap_tmp];
    else
      diffmap = [diffmap dip_tmp.diffmap];
    end
  end
  rv_all = rv_all / cls_length;
  %compute mean and SD of talairach coordinate in each cluster
  for k = 1 : size(talcoord_all, 2)  %j: still in use, not able to be overwritten
    posxyz_all(j + 1, k) = mean(posxyz_all(find(~isnan(posxyz_all(1 : j, k))), k));
    posxyz_all(j + 2, k) = std(posxyz_all(find(~isnan(posxyz_all(1 : j, k))), k));
    momxyz_all(j + 1, k) = mean(momxyz_all(find(~isnan(momxyz_all(1 : j, k))), k));
    momxyz_all(j + 2, k) = std(momxyz_all(find(~isnan(momxyz_all(1 : j, k))), k));
    eleccoord_all(j + 1, k) = mean(eleccoord_all(find(~isnan(eleccoord_all(1 : j, k))), k));
    eleccoord_all(j + 2, k) = std(eleccoord_all(find(~isnan(eleccoord_all(1 : j, k))), k));
    mnicoord_all(j + 1, k) = mean(mnicoord_all(find(~isnan(mnicoord_all(1 : j, k))), k));
    mnicoord_all(j + 2, k) = std(mnicoord_all(find(~isnan(mnicoord_all(1 : j, k))), k));
    talcoord_all(j + 1, k) = mean(talcoord_all(find(~isnan(talcoord_all(1 : j, k))), k));
    talcoord_all(j + 2, k) = std(talcoord_all(find(~isnan(talcoord_all(1 : j, k))), k));
  end
  fprintf(fp, 'Avg.\t\t');
  for k = 1 : size(talcoord_all(j + 1, :), 2)
    if ~isnan(talcoord_all(j + 1, k))
      fprintf(fp, '%.2f', talcoord_all(j + 1, k));
    else
      fprintf(fp, '--');
     end
    if k ~= size(talcoord_all(j + 1, :), 2)
      fprintf(fp, '\t');
    else
      fprintf(fp, '\r\n');
    end
  end
  fprintf(fp, 'SD\t\t');
  for k = 1 : size(talcoord_all(j + 2, :), 2)
    if ~isnan(talcoord_all(j + 2, k))
      fprintf(fp, '%.2f', talcoord_all(j + 2, k));
    else
      fprintf(fp, '--');
     end
    if k ~= size(talcoord_all(j + 2, :), 2)
      fprintf(fp, '\t');
    end
  end
  fclose(fp);
  %computing avg. diffmap
  if isempty(find(isnan(diffmap)))  %no missing channels
    avg_diffmap = mean(diffmap, 2);
  else
    avg_diffmap = [];
    for k = 1 : size(diffmap, 1)
      diffmap_tmp = find(~isnan(diffmap(k, :)));  %~isnan([1 NaN 1]) = [1 0 1] => find(~isnan([1 NaN 1])) = [1 3]
      diffmap_tmp = mean(diffmap(k, diffmap_tmp));
      avg_diffmap = [avg_diffmap; diffmap_tmp];
    end
  end
  diffmap = avg_diffmap;
  dipole_avg.rv = rv_all;
  dipole_avg.diffmap = avg_diffmap;
  if size(talcoord_all(j + 2, :), 2) == 3  %one dipole
    dipole_avg.posxyz = posxyz_all(j + 1, :);
    dipole_avg.momxyz = momxyz_all(j + 1, :);
    dipole_avg.eleccoord = eleccoord_all(j + 1, :);
    dipole_avg.mnicoord = mnicoord_all(j + 1, :);
    dipole_avg.talcoord = talcoord_all(j + 1, :);
  else
    dipole_avg.posxyz(1, :) = posxyz_all(j + 1, 1 : 3); dipole_avg.posxyz(2, :) = posxyz_all(j + 1, 4 : 6);
    dipole_avg.momxyz(1, :) = momxyz_all(j + 1, 1 : 3); dipole_avg.momxyz(2, :) = momxyz_all(j + 1, 4 : 6);
    dipole_avg.eleccoord(1, :) = eleccoord_all(j + 1, 1 : 3); dipole_avg.eleccoord(2, :) = eleccoord_all(j + 1, 4 : 6);
    dipole_avg.mnicoord(1, :) = mnicoord_all(j + 1, 1 : 3); dipole_avg.mnicoord(2, :) = mnicoord_all(j + 1, 4 : 6);
    dipole_avg.talcoord(1, :) = talcoord_all(j + 1, 1 : 3); dipole_avg.talcoord(2, :) = talcoord_all(j + 1, 4 : 6);
  end

  %dimensions of component map and spectra
  avg_splt = 2;  %size of avg comp map = 2 * 2
  while cls_length > avg_splt * avg_splt * 3
    avg_splt = avg_splt + 1;
  end
  subplt_width = ceil(sqrt(cls_length + avg_splt * avg_splt));
  subplt_height = floor(sqrt(cls_length + avg_splt * avg_splt));
  if  cls_length + avg_splt * avg_splt > subplt_width * subplt_height
    subplt_height = subplt_height + 1;
  end
  subplt_x_comp = floor(10000 / subplt_width) / 10000;
  subplt_y_comp = floor(10000 / subplt_height) / 10000;
  blank_x_comp = (1 - subplt_x_comp * subplt_width) / 2;
  blank_y_comp = (1 - subplt_y_comp * subplt_height) / 2;
  subplt_x_spec = floor(9500 / subplt_width) / 10000;  %.025: for x and y labels
  subplt_y_spec = floor(9500 / subplt_height) / 10000;
  blank_x_spec = (.95 - subplt_x_spec * subplt_width) / 2;
  blank_y_spec = (.95 - subplt_y_spec * subplt_height) / 2;

  %plot avg. scalp map and avg. spectra in a cluster
  figure(4009);  %scalp map
  set(gcf, 'Renderer', 'ZBuffer');
  subplot('position', [blank_x_comp, blank_y_comp + subplt_y_comp * (subplt_height - avg_splt), ...
      subplt_x_comp * avg_splt, subplt_y_comp * avg_splt - .07]); axis off;  %0.07: title
  DR_topoplot(avg_icawinv, std_chanlocs, 'electrodes', 'off', 'shrink', 'force');
  subplot('position', [blank_x_comp, blank_y_comp + subplt_y_comp * (subplt_height - avg_splt) + subplt_y_comp * avg_splt - .07, ...
      subplt_x_comp * avg_splt, .07]); axis off;
  text(.5, 1, ...
      {['Avg. Scalp Map of \color{blue}' ClsLabel{i} '\color{black} Cluster']; ...
      ['\fontsize{' int2str(TITLE_FSIZE) '}(\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' int2str(cls_length) ' Components)']; ...
      ['Paired Corr. Coef.: ' num2str(avg_corr, '%0.2f') ' \pm ' num2str(sd_corr, '%0.2f')]}, ...
      'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE + 2, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'Cap');
%   title({'Avg. Scalp Map of \color{red}'; [ClsLabel{i} '\color{black} Cluster (' int2str(cls_length) ' Components)']});

  figure(166);  %spectra
  set(gcf, 'Renderer', 'ZBuffer');
  subplot('position', [blank_x_spec + .05, blank_y_spec + subplt_y_spec * (subplt_height - avg_splt) + .05, ...
      subplt_x_spec * avg_splt - .025, subplt_y_spec * avg_splt - .075]);
%   subplot('position', [blank_x_spec, blank_y_spec + subplt_y_spec * (subplt_height - 2), subplt_x_spec * 2, subplt_y_spec * 2]);
  hold on;
  plot(freqs, trimmean(spec_all, 10, 1), '-b', 'LineWidth', 1.5);  %avg spectrum
  plot(freqs, spec_all', 'LineStyle', '-', 'Color', [.75 .75 .75]);  %every spectrum
  legend_handle = legend('Avg. Spectra', 'Spectra of Each Dataset', 'location', 'NorthEast');
  set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE + 2, 'box', 'off');
%   text(power_xlim(2), power_ylim(2), {'\color{red}Avg. Spectra'}, ...
%       'FontName', FONT_FACE, 'FontSize', 8, 'HorizontalAlignment', 'right', 'VerticalAlignment', 'cap');
%   text(power_xlim(2), power_ylim(2), [subj '\_' ExpDate '-' num2str(plot_comp, '%02d')], ...
%       'FontName', FONT_FACE, 'FontSize', 8, 'HorizontalAlignment', 'right', 'VerticalAlignment', 'cap');
  title({['Spectra of Alert Trials in \color{blue}' ClsLabel{i} '\color{black} Cluster ']; ...
      ['\rm(\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' int2str(cls_length) ' Components)']}, ...
      'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', 'VerticalAlignment', 'Bottom');
  hold off;
  xlim(power_xlim);
  ylim(power_ylim);
  set(gca, 'Box', 'off', 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE + 2, ...
      'XTick', 10 : 10 : power_xlim(2), 'YTick', power_ylim(1) : 10 : power_ylim(2));
%   xlabel('Frequency (Hz)', 'FontName', FONT_FACE, 'FontSize', FONT_SIZE + 2, 'VerticalAlignment', 'middle');
%   ylabel('Power (dB)', 'FontName', FONT_FACE, 'FontSize', FONT_SIZE + 2, 'VerticalAlignment', 'middle');

%% plot each scalp map, spectrum, and dipole
  for j = 1 : cls_length
    plot_set = IC_tmp{1, 2 * j};
    plot_comp = IC_tmp{1, 2 * j + 1};
    com = sprintf('EEG = %s;', plot_set); eval(com);
    [subj ExpDate] = strtok(plot_set, '_'); ExpDate = ExpDate(2 : end);
    if ceil(j / (subplt_width - avg_splt)) < avg_splt
      plot_shift = avg_splt * ceil(j / (subplt_width - avg_splt));
    else
      plot_shift = avg_splt * avg_splt;
    end
    subplt_pos_comp = [blank_x_comp + subplt_x_comp * mod((j + plot_shift - 1), subplt_width), ...
                  blank_y_comp + subplt_y_comp * (subplt_height - ceil((j + plot_shift) / subplt_width))];
    subplt_pos_spec = ...
        [blank_x_spec + .025 + .025 + subplt_x_spec * mod((j + plot_shift - 1), subplt_width), ...  %.025: labels, .025: tick labels
        blank_y_spec + .025 + .025 + subplt_y_spec * (subplt_height - ceil((j + plot_shift) / subplt_width))];

    %plot component map
    figure(4009);
    ch(j) = subplot('position', [subplt_pos_comp subplt_x_comp subplt_y_comp - .02]); axis off;  %.02: height of title
    DR_topoplot(icawinv(find(~isnan(icawinv(:, j))), j), chan_all{j}, 'electrodes', 'off', 'shrink', 'force');
    subplot('position', [subplt_pos_comp(1) subplt_pos_comp(2) + subplt_y_comp - .02 subplt_x_comp .02]); axis off;
    %title
    text(.5, .5, [subj '\_' ExpDate '-' num2str(plot_comp, '%02d')], ...
        'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'Cap');
    
    %plot power spectra
    figure(166);  %alert trial
    spec_all_tmp = spec_all; spec_all_tmp(j, :) = [];
    sh1(j) = subplot('position', [subplt_pos_spec subplt_x_spec - .025  subplt_y_spec - .025 - .005]);
%     sh1(j) = subplot('position', [subplt_pos_spec subplt_x_spec subplt_y_spec]);
    hold on;
    plot(freqs, spec_all(j, :), '-r', 'LineWidth', 1);  %one spectrum
    plot(freqs, trimmean(spec_all, 10, 1), '-b', 'LineWidth', 1.5);  %avg spectrum
    plot(freqs, spec_all_tmp', 'LineStyle', '-', 'Color', [.75 .75 .75]);  %every spectrum
%     if j == 1
%       legend_handle = legend([subj '\_' ExpDate '-' num2str(plot_comp, '%02d')], ...
%           'Avg. Spectra', 'The Others', 'location', 'NorthEast');
% %       text(power_xlim(2), power_ylim(2), {[subj '\_' ExpDate '-' num2str(plot_comp, '%02d')]; '\color{red}Avg. Spectra'}, ...
% %           'FontName', FONT_FACE, 'FontSize', 8, 'HorizontalAlignment', 'right', 'VerticalAlignment', 'cap');
%     else
%       legend_handle = legend([subj '\_' ExpDate '-' num2str(plot_comp, '%02d')], 'location', 'NorthEast');
    %legend
    text(power_xlim(2), power_ylim(2) - 2.5, ['\color{red}' sprintf('%s%s  ', 8212, 8212) '\color[rgb]' FONT_COLOR subj '\_' ExpDate], ...  %unicode 8212 (dec): dash
         'FontName', FONT_FACE, 'FontSize', FONT_SIZE, 'HorizontalAlignment', 'Right', 'VerticalAlignment', 'Cap');
%       text(power_xlim(2), power_ylim(2), [subj '\_' ExpDate '-' num2str(plot_comp, '%02d')], ...
%           'FontName', FONT_FACE, 'FontSize', 8, 'HorizontalAlignment', 'right', 'VerticalAlignment', 'cap');
%     end
%     set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE, 'box', 'off');
    
    hold off;
    xlim(power_xlim);
    ylim(power_ylim);
    set(gca, 'Box', 'off', 'FontName', FONT_FACE, 'Color', BACKGROUND_COLOR);
%     if cls_length - j >= subplt_width
      set(gca, 'XTick', []);
%     else
      set(gca, 'XTick', 10 : 10 : power_xlim(2), 'FontName', FONT_FACE, 'FontSize', FONT_SIZE);
%       xlabel('Frequency (Hz)', 'FontName', FONT_FACE, 'FontSize', FONT_SIZE, 'VerticalAlignment', 'middle');
%     end
%     if mod(j, subplt_width) ~= 1
      set(gca, 'YTick', []);
%     else
      set(gca, 'YTick', power_ylim(1) : 10 : power_ylim(2), 'FontName', FONT_FACE, 'FontSize', FONT_SIZE);
%       ylabel('Power (dB)', 'FontName', FONT_FACE, 'FontSize', FONT_SIZE, 'VerticalAlignment', 'middle');
%     end

    %plot dipole (cont.)
    %plot dipole in darker color
    figure(4002);
    set(gcf, 'Renderer', 'ZBuffer');
    eval(['dipplot(EEG.dipfit.model(plot_comp), ''mri'', mrifile, ''view'', view_angle, ''color'', {[0 1 1]}, ' ...
        '''dipolesize'', 5, ''dipolelength'', 0, ' [dip_option ', ''projimg'', ''off'', ''projlines'', ''off'', ''coordformat'', ''spherical'''] ');']);
    h1 = findobj(gcf, 'Type', 'line');
    figure(4001);  %copy into main window
    for k = 1 : cls_length
      if j ~= k
        copyobj(h1, dh(k));
      end
    end
    close(4002);

    %plot dipole into one figure
    figure(4003);
    set(gcf, 'Renderer', 'ZBuffer');
    dip_color_tmp = mat2str(dip_color{mod(j, size(dip_color, 1)) + 1});
    subplot('position', [0.84 0 .16 1]); axis off;
    text(.05, .85 - j * .03, ['\color[rgb]{' dip_color_tmp(2 : end - 1) '}' '\bullet\color[rgb]{0 0 0} ' subj '\_' ExpDate '-' num2str(plot_comp, '%02d')], ...
        'FontName', FONT_FACE, 'FontSize', 10, 'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Middle');
    if j == 1
      text(0, .975, {['\color[rgb]' FONT_COLOR 'Dipole of the ']; ...
          ['\color{blue}' ClsLabel{i} '\color[rgb]' FONT_COLOR]; 'Cluster'; ...
          ['(\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ',']; [int2str(cls_length) ' Components)']}, ...
          'FontName', FONT_FACE, 'FontSize', 10, 'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Top');
    end
    subplot('position', [0 .1 .8 .8]);
    target = gca;
    if j ~= 1
      figure(4004);
      set(gcf, 'Renderer', 'ZBuffer');
      subplot('position', [0 .1 .8 .8]);
    end
    eval(['dipplot(EEG.dipfit.model(plot_comp), ''mri'', mrifile, ''view'', view_angle_single, ''color'', {' ...
        dip_color_tmp '}, ''dipolesize'', 30, ''dipolelength'', 0, ' [dip_option ...
        ', ''projimg'', ''off'', ''projlines'', ''off'', ''coordformat'', ''spherical'''] ');']);
%     if (j == 1)
%       h2 = findobj(gcf, 'Type', 'surface');
%       copyobj(h2, target);
%     end
    if (j ~= 1)
      h2 = findobj(gcf,'Type','line');
      copyobj(h2, target);
%     if (j ~= 1)
      close(4004);
    end
  end

  %x and y labels of spectra
  figure(166);
  subplot('position', [0.025 0 .95 .025]); axis off;  %x label
  text(.5, 0, ['\color[rgb]' FONT_COLOR 'Frequency (Hz)'], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE + 2, ...
      'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Bottom');
  subplot('position', [0 0.025 .025 .95]); axis off;  %y label
  text(.5, .5, ['\color[rgb]' FONT_COLOR 'Power (dB)'],'FontName', FONT_FACE, 'FontSize', FONT_SIZE + 2, ...
      'HorizontalAlignment', 'Center', 'VerticalAlignment', 'middle', 'Rotation', 90);
  %avg dipole
  figure(4004);
  set(gcf, 'Renderer', 'ZBuffer');
  subplot('position', [0 .1 .8 .8]);
  eval(['dipplot(dipole_avg, ''mri'', mrifile, ''view'', view_angle_single, ''color'', {' ...
      '[.99 .99 .99]}, ''dipolesize'', 40, ''dipolelength'', 0, ' [dip_option ...
        ', ''projimg'', ''off'', ''projlines'', ''on'', ''projcol'', {[.99 .99 .99]}, ''coordformat'', ''spherical'''] ');']);
  h2 = findobj(gcf,'Type','line');
  copyobj(h2, target);
  close(4004);
  figure(4003);
  subplot('position', [0.84 0 .16 1]); axis off;
  text(.05, .85 - (j + 1) * .03, ['\color[rgb]{0 0 0}' 'o\color[rgb]{0 0 0} Avg. Dipole'], ...
      'FontName', FONT_FACE, 'FontSize', 10, 'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Middle');

  %set background
  for k = [166 4001 4003 4009]
    set(k, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');
  end

  %title of the whole figure (dipole only)
  figure(4001);
  subplt_width = ceil(sqrt(cls_length + 1));
  subplt_height = floor(sqrt(cls_length + 1));
  if cls_length + 1 > subplt_width * subplt_height
    subplt_height = subplt_height + 1;
  end
  subplt_x_dip = floor(10000 / subplt_width) / 10000;  %floor(10000 / 3) / 10000 = .3333
  subplt_y_dip = floor(10000 / subplt_height) / 10000;  %floor(10000 / 6) / 10000 = .1666 < roundn(1/6, -4) = .1667
  blank_x_dip = (1 - subplt_x_dip * subplt_width) / 2;
  blank_y_dip = (1 - subplt_y_dip * subplt_height) / 2;
  subplt_pos_dip = [blank_x_dip + subplt_x_dip * mod(j , subplt_width)  + subplt_x_dip * 0.1, ...
                blank_y_dip + subplt_y_dip * (subplt_height - ceil((j + 1) / subplt_width)) + subplt_y_dip * 0.1];
  th(j + 1) = subplot('position', [subplt_pos_dip(1) + subplt_x_dip * .1 subplt_pos_dip(2) + subplt_y_dip * .1 ...
      subplt_x_dip * .75 subplt_y_dip * .75]);
  axis off;
  if i ~= 9 && i ~= 10
    text(0.5, 0.5, ...
        {['\color[rgb]' FONT_COLOR 'Dipole of \color{blue}' ClsLabel{i} '\color[rgb]' FONT_COLOR ' Cluster']; ...
        ['\rm(\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' int2str(cls_length) ' Components)']}, ...
        'FontName', FONT_FACE, 'FontWeight', 'bold', 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle');
  else
    text(0.5, 0.5, ...
        {['\color[rgb]' FONT_COLOR 'Dipole of \color{blue}']; ...
        [ClsLabel{i} '\color[rgb]' FONT_COLOR ' Cluster']; ...
        ['\rm(\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' int2str(cls_length) ' Components)']}, ...
        'FontName', FONT_FACE, 'FontWeight', 'bold', 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle');
  end

%% save necessary variables and figures
  save([FilePath 'RS' SL MN SL 'IC', num2str(i, '%02d'), '_component_' cls_ver '_' MN], ...
      ['IC' num2str(i, '%02d')], 'std_chanlocs', 'chan_all', 'icawinv', 'avg_icawinv', 'comp_corr', 'avg_corr', 'sd_corr', 'spec_all', 'freqs', 'dipole_all', 'dipole_avg');
%   save(['~/IC', num2str(i, '%02d'), '_component_' cls_ver '_' MN], ...
%       ['IC' num2str(i, '%02d')], 'std_chanlocs', 'chan_all', 'icawinv', 'avg_icawinv', 'comp_corr', 'avg_corr', 'sd_corr', 'spec_all', 'freqs', 'dipole_all', 'dipole_avg');
%   save([FilePath 'RS' SL MN SL 'IC', num2str(i, '%02d'), '_component_' cls_ver '_' MN], 'spec_all', 'freqs', '-append');
  %save figure
  %component map
  figure(4009);
  saveas(gcf, [FilePath 'RS' SL MN SL  'IC', num2str(i, '%02d'), '_component_map_' cls_ver '_' MN '.fig'], 'fig');
  print('-dpng', [FilePath 'RS' SL MN SL  'IC', num2str(i, '%02d'), '_component_map_' cls_ver '_' MN '.png']);
  close(4009);

  %power spectra
  figure(166);
  saveas(gcf, [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_Cluster_Spectra_' cls_ver '_' MN '.fig'], 'fig');
  print('-dpng', [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_Cluster_Spectra_' cls_ver '_' MN '.png']);
  close(166);
%   figure(193);
%   saveas(gcf, [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_Cluster_Spectra_' cls_ver '_' MN '.fig'], 'fig');
%   print('-dpng', [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_Cluster_Spectra_' cls_ver '_' MN '.png']);
%   close(193);

  %dipole
  figure(4001);
  saveas(gcf, [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_DipoleMap_' cls_ver '_' MN], 'fig');
  print('-dpng', [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_DipoleMap_' cls_ver '_' MN '.png']);
  close(4001);

  %dipole (single plot)
  figure(4003);
  saveas(gcf, [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_DipoleMap_' cls_ver '_single_' MN], 'fig');
  print('-dpng', [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_DipoleMap_' cls_ver '_single_' MN '.png']);
  close(4003);
end