% Computing baseline power on alpha and theta bands
% Core code provided by Ruey-song Huang (SCCN, UCSD)
% ver. 200811

%% set parameters (initialize)
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/';  %directory
  SL = '/';
end
DR_PBase_setup;
%datasets
PLOT_SET = {
            's31_061103';  %motionless
            's32_061031';  %motionless
            's35_070322';  %motionless
            's36_061221';  %motionless
%             's37_061213';  %motionless
%             's39_070117';  %motionless
            's40_070207';  %motionless
            's41_061225';  %motionless
            's42_070105';  %motionless
            's43_070208';  %motionless
            's44_070325';  %motionless
            's54_081209n';  %motionless
            's31_061020';  %motion
            's35_070115';  %motion
            's36_061122';  %motion
            's39_061218';  %motion
            's40_070131';  %motion
            's43_070202';  %motion
            's44_070126';  %motion
           };
MN = 'motion';
p_val = 1E-4;
try  %for topoplot
  icadefs;
catch
  addpath(genpath(EEGLAB_dir));
  icadefs;
end
winsize = 30;  %-30 < t <= 30 (sec); real winsize = winsize * 2
stepping = 1;  %step
movstep = 1;  %stepping for moving avg
xstep_int = 5;
FilePathOld = FilePath;
try
  close(1026);
end

%%
for i = 1 : size(PLOT_SET, 1)
%% calculate power
  Go = true;  %flag, if dataset is invalid => stop process
  FilePath = FilePathOld;
  plot_set = PLOT_SET{i, 1};
  %check if the plot_set is valid
  for j = 1 : size(SET, 1)
    Set = SET{j, 1};
    condition = SET{j, 3};
    if strcmp(Set, plot_set)
      if strcmp(condition, MN)
        COMP = SET{j, 2};
        break;
      else
       Go = false;
       break;
      end
    end
    if j == size(SET, 1)
      Go = false;  %error occurs
    end
  end
  if Go
    [subj ExpDate] = strtok(Set, '_'); ExpDate = ExpDate(2 : end);
    FilePath = [FilePath Set SL];
    %load EEG dataset (only load necessary information. name of variables: the same as in .set file)
    EEG = pop_loadset([FilePath Set EpochType{1} rj '.set']);
    %load RT
    load([FilePath Set '_RT_of_trials'], 'RT');  %RT: 1 * n array
    %load epoch information
    load([FilePath Set '_epoch_inf']);
    %rename variables to more meaningful ones
    icaact = EEG.icaact;
    icawinv = EEG.icawinv;
    chanlocs = EEG.chanlocs;
    n_of_trials = EEG.trials;
    epoch_start = EEG.xmin;
%     epoch_start = -1;
    epoch_end = EEG.xmax;
    clear EEG;
    epoch_inf = epoch_inf(find(epoch_inf(:, 11)), :);
    urPB_old = [epoch_inf(:, 5) (epoch_inf(:, 6) - epoch_inf(:, 5))] / 500;  %urPB: [(time of dev_on) RT]; / 500: frame -> sec
    baseln = (0 - epoch_start) * SR;  %length of baseline
%     baseln = (epoch_end - epoch_start) * SR + 1;  %length of baseline (WHOLE epoch)
%     baseln = (epoch_end - 0) * SR + 1;  %length of baseline (after event)
%     tmp = find(RT <= alert.rt, 1, 'last');  %find # of trials with RT <= 3 sec
%     alert.trials = ceil(tmp * alert.rate);  %the first alert.rate * 100% of these trials: alert
    valid_trial = find(RT >= min_RT & RT <= max_RT);  %trial with RT in desired region
    [RT_s ur_idx] = sort(RT(valid_trial));  %RT_s: sorted RT; ur_idx: original index of each element in RT_s
    alert.trials = ceil(size(RT_s, 2) * alert.rate);  %the first alert.rate * 100% of all trials: alert

    for j = 1 : size(COMP, 2)
      comp = COMP(1, j);
      cls = COMP(2, j);  %which cluster
      PB_mean = [];
      if cls < 0  %not selected after screening
        cls = 0;
      end
      baseline = reshape(icaact(comp, 1 : baseln, :), baseln, n_of_trials);
%       baseline = reshape(icaact(comp, 1 : baseln, ur_idx), baseln, n_of_trials);  %sort by RT
      %calculate power across frequency
%       help timefreq2004;
      %timefreq2004: the same as timefreq in SCCN, UCSD
      %PB: time frequency array for all trials (freqs * times * trials) **baseline only**
      %freqs: vector of computed frequencies (Hz)
      %times: vector of computed time points (ms)
      [PB, freqs, times] = timefreq2004(baseline, SR, 'wavelet', 0, 'freqs', [min_freq max_freq], ...
          'winsize', 128, 'padratio', 2, 'ntimesout', 100);
      PB = 10 * log10(PB .* conj(PB));  %convert into dB
%       PB_mean = mean(PB, 2);  %calculate avg. spectra
      PB_mean = trimmean(PB, 10, 2);  %calculate avg. spectra
      PB_mean = reshape(PB_mean, size(freqs, 2), n_of_trials);
%       icaact = icaact(:, :, ur_idx);
%       for k = 1 : n_of_trials
%       [ERSP, ITC, PB_meanT, times, freqs] = timef(icaact(comp, :, k), 2000, [-2000 5996], 250, 0, ...
%           'padratio', 4, 'plotersp', 'off', 'plotitc', 'off', 'verbose', 'off'); close gcf;
%       PB_mean = [PB_mean PB_meanT'];
%       end
      freqs = freqs(find(freqs >= 3 & freqs <= 45));
      PB_mean = PB_mean(find(freqs >= 3 & freqs <= 45), valid_trial);

      %sparse moving avg.
      URPB = {'Duration', [], urPB_old(valid_trial, 1)', AXIS_COLOR, 0, 0, '0';
                  'RT', [], urPB_old(valid_trial, 2)', RT_COLOR, 0, 0, '0';};
      for k = 1 : size(FREQ_BAND, 1)
        freq_band = FREQ_BAND{k, 2};
        URPB(k + 2, 1) = FREQ_BAND(k, 1);  %k + 2: already 2 rows
        URPB(k + 2, 2) = FREQ_BAND(k, 2);
%         URPB(k + 2, 3) = {mean(PB_mean(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :))};
        URPB(k + 2, 3) = {trimmean(PB_mean(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :), 10)};
        URPB(k + 2, 4) = FREQ_BAND(k, 3);
        %correlation
        [corr p] = corrcoef(URPB{k + 2, 3}, log10(URPB{2, 3}));
        URPB(k + 2, [5 6]) = {corr(2), p(2)};
        if p(2) > .01
          URPB(k + 2, 7) = {num2str(p(2), '%.02f')};
        else
          URPB(k + 2, 7) = {num2str(p(2), '%.e')};
        end
      end
      %moving average (1-min window, 0: each dev_on)
      URPB_mov = URPB;
      urPB_mov = [];
      urPB_tmp = cell2mat(URPB(:, 3));
      sparse_ylim = [min(min(urPB_tmp(3 : end, :))) max(max(urPB_tmp(3 : end, :)))];
      for k = 1 : stepping : size(urPB_tmp, 2)
        idx = find(urPB_tmp(1, :) > urPB_tmp(1, k) - winsize & urPB_tmp(1, :) <= urPB_tmp(1, k) + winsize);
%         urPB_mov = [urPB_mov mean(urPB_tmp(:, idx), 10, 2)];
        urPB_mov = [urPB_mov trimmean(urPB_tmp(:, idx), 10, 2)];
      end
      sparse_ylim_mov = [min(min(urPB_mov(3 : end, :))) max(max(urPB_mov(3 : end, :)))];
      URPB_mov(:, 3) = mat2cell(urPB_mov, ones(1, size(urPB_mov, 1)), size(urPB_mov, 2));
      clear urPB_mov urPB_tmp;
      %correlation
      for k = 1 : size(FREQ_BAND, 1)
        [corr p] = corrcoef(URPB_mov{k + 2, 3}, log10(URPB_mov{2, 3}));  %k + 2: already 2 rows
        URPB_mov(k + 2, [5 6]) = {corr(2), p(2)};
        if p(2) > .01
          URPB_mov(k + 2, 7) = {num2str(p(2), '%.02f')};
        else
          URPB_mov(k + 2, 7) = {num2str(p(2), '%.e')};
        end
      end

      %sort by RT
      PB_mean = PB_mean(:, ur_idx);
%       PB_mean = 10*log10(PB_mean);
      PB_alert = PB_mean(:, 1 : alert.trials);  %calculating power of alert trials
%       PB_alert = mean(PB_alert, 2) * ones(1, size(valid_trial, 2));  %padding
      PB_alert = trimmean(PB_alert, 10, 2) * ones(1, size(valid_trial, 2));  %padding
      PB_n = PB_mean - PB_alert;  %normalized by power in alert stage
      %moving average
%       help movav;
%       PB_mov = movav(PB_n, [], alert.trials, 1);
%       RT_s_mov = movav(RT_s', [], alert.trials, 1);
      PB_mov = [];
      RT_s_mov = [];
      for k = 1 : movstep : size(PB_n, 2) - (alert.trials - 1)
%         PB_mov = [PB_mov mean(PB_n(:, k : k + alert.trials - 1), 2)];
%         RT_s_mov = [RT_s_mov mean(RT_s(:, k : k + alert.trials - 1), 2)];
        PB_mov = [PB_mov trimmean(PB_n(:, k : k + alert.trials - 1), 10, 2)];
        RT_s_mov = [RT_s_mov trimmean(RT_s(:, k : k + alert.trials - 1), 10, 2)];
      end
      %compute power over different freq bands
      FREQ_INC = {};
      for k = 1 : size(FREQ_BAND, 1)
        freq_band = FREQ_BAND{k, 2};
        FREQ_INC(k, 1) = FREQ_BAND(k, 1);
        FREQ_INC(k, 2) = FREQ_BAND(k, 2);
%         FREQ_INC(k, 3) = {mean(PB_mov(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :))};
        FREQ_INC(k, 3) = {trimmean(PB_mov(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :), 10)};
        FREQ_INC(k, 4) = FREQ_BAND(k, 3);
      end

      %statistics test (2-tail t-test)
      %courtesy Ruey-Song Huang in UCSD
      fprintf('Performing 2-tail T-test (p = %g): \n', p_val);
      P_mask = zeros(size(PB_mov));
      H_mask = P_mask;
      sig_idx = 1 : movstep : floor(size(PB_n, 2) / movstep) - (alert.trials - 1);
      for k = 1 : size(PB_mov, 2)
        PB_tmp = PB_mean(:, sig_idx(k) : sig_idx(k) + alert.trials - 1);
        %corrected p_val: / 2: 2-tail; / size(freqs, 2): freq bins;
%         [H, P] = ttest2(PB_tmp', PB_alert(:, 1 : alert.trials)', p_val / 2 / size(freqs, 2) / alert.trials, 'both');
        [H, P] = ttest2(PB_tmp', PB_alert(:, 1 : alert.trials)', p_val / 2 / size(freqs, 2), 'both');
        H_mask(:, k) = H';
        P_mask(:, k) = P';
      end

%% plot figure
      figure(1026); hold on;
      xstep = (size(RT_s, 2) - 1) / xstep_int;
      xstep_mov = (size(RT_s_mov, 2) - 1) / xstep_int;
      subplot('position', [.03 .88 .12 .12]); axis off;  %plot component map
      topoplot(icawinv(:, comp), chanlocs, 'electrodes', 'on', 'shrink', 'force');
      set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');  %set after topoplot to preserve backgound color
      subplot('position', [.15 .85 .8 .15]); axis off;   %title
      text(.5, .6, {['\color[rgb]' FONT_COLOR 'Baseline Power Spectra of']; ...
          ['Component ' int2str(comp) ', ' subj '\_' ExpDate ' (' int2str(size(valid_trial, 2)) ' Trials)']}, ...
          'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
          'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
%       text(.5, .6, {['\color[rgb]' FONT_COLOR 'Power Spectra of']; ...
%           ['Component ' int2str(comp) ', ' subj '\_' ExpDate ' (Whole Epoch, ' int2str(size(valid_trial, 2)) ' Trials)']}, ...
%           'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
%           'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');

      %plot original power image
      subplot('position', [.05 .533 .205 .317]); hold on;
      imagesc(1 : size(RT_s, 2), freqs, PB_mean, [-50 50]);
      set(gca, 'Xlim', [1 size(RT_s, 2)], 'XTick', 1 : xstep : size(RT_s, 2), ...
          'XTickLabel', roundn(RT_s(1 : xstep : size(RT_s, 2)), -2), 'XColor', AXIS_COLOR, ...
          'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
      %mark frequencies
      for k = 10 : 10 : 40
        plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
      end
      %plot a vertical line with x axis on that point
      try
        plot([find(RT_s <= 3, 1, 'last') find(RT_s <= 3, 1, 'last')], get(gca, 'Ylim'), ...
            'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
      end
      ylabel('Frequency (Hz)', 'VerticalAlignment', 'Baseline');
      title(['\color[rgb]' FONT_COLOR 'Original Baseline Power Image'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
      %colorbar
      subplot('position', [.02 .515 .03 .018]); axis off;
      text(1, -2, ['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
          'HorizontalAlignment', 'Right', 'VerticalAlignment', 'Top');
      subplot('position', [.05 .515 .205 .018]); axis off;
      colorbar('location', 'SouthOutside', 'XTick', 1 : 16 : 65, 'XTickLabel', -50 : 25 : 50, 'FontSize', CBAR_FSIZE);

      %plot normalized power image
      subplot('position', [.285 .533 .205 .317]); hold on;
      imagesc(1 : size(RT_s, 2), [freqs(1) freqs(end)], PB_n, [-25 25]);
      set(gca, 'Xlim', [1 size(RT_s, 2)], 'XTick', 1 : xstep : size(RT_s, 2), ...
          'XTickLabel', roundn(RT_s(1 : xstep : size(RT_s, 2)), -2), 'XColor', AXIS_COLOR, ...
          'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, ...
          'YTickLabel', [], 'FontSize', AXIS_FSIZE);
      %mark frequencies
      for k = 10 : 10 : 40
        plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
      end
      %plot a vertical line with x axis on that point
      try
        plot([find(RT_s <= 3, 1, 'last') find(RT_s <= 3, 1, 'last')], get(gca, 'Ylim'), ...
            'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
      end
      title(['\color[rgb]' FONT_COLOR 'Normalized Baseline Power Image'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
      %colorbar
      subplot('position', [.285 .515 .205 .018]); axis off;
      colorbar('location', 'SouthOutside', 'XTick', 1 : 16 : 65, 'XTickLabel', -25 : 12.5 : 25, 'FontSize', CBAR_FSIZE);
      %x label for the above 2 plots
      text(-.1, -.5, ['\color[rgb]' FONT_COLOR 'Sorted Reaction Time (sec)'], ...
          'fontsize', AXIS_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Top');
    
      %plot moving avg. power image (inside contour: p < p_val)
      subplot('position', [.52 .533 .205 .317]); hold on;
      imagesc(1 : size(RT_s_mov, 2), freqs, PB_mov, [-3 6]);
      contour(1 : size(RT_s_mov, 2), freqs, H_mask, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
      set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', 1 : xstep_mov : size(RT_s_mov, 2), ...
          'XTickLabel', roundn(RT_s_mov(1 : xstep_mov : size(RT_s_mov, 2)), -2), 'XColor', AXIS_COLOR, ...
          'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, ...
          'YTickLabel', [], 'FontSize', AXIS_FSIZE);
      %mark frequency
      for k = 10 : 10 : 40
        plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
      end
      %plot a vertical line with x axis on that point
      try
        plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
            'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
      end
      title({['\color[rgb]' FONT_COLOR 'Moving Avg Baseline Power Image']; ['(Countour: p < ' num2str(p_val, '%.e') ')']}, ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
      %colorbar
      subplot('position', [.52 .515 .205 .018]); axis off;
%       colorbar('location', 'SouthOutside', 'XLim', [13.8 52.2], 'XTick', 13.8 : 9.6 : 52.2, 'XTickLabel', -6 : 3 : 6, 'FontSize', CBAR_FSIZE);
      colorbar('location', 'SouthOutside', 'XLim', [1 65], 'XTick', 1 : 64/3 : 65, 'XTickLabel', -3 : 3 : 6, 'FontSize', CBAR_FSIZE);

      %plot p-value image
      subplot('position', [.755 .533 .205 .317]); hold on;
      imagesc(1 : size(RT_s_mov, 2), freqs, -log10(P_mask), [-2.5 10]);
      contour(1 : size(RT_s_mov, 2), freqs, H_mask, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
      set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', 1 : xstep_mov : size(RT_s_mov, 2), ...
          'XTickLabel', roundn(RT_s_mov(1 : xstep_mov : size(RT_s_mov, 2)), -2), 'XColor', AXIS_COLOR, ...
          'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, ...
          'YTickLabel', [], 'FontSize', AXIS_FSIZE);
      %mark frequency
      for k = 10 : 10 : 40
        plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
      end
      %plot a vertical line with x axis on that point
      try
        plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
            'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
      end
      title({['\color[rgb]' FONT_COLOR 'P-Value Image']; ['(Contour: p < ' num2str(p_val, '%.e') ')']}, ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
      subplot('position', [.725 .515 .03 .018]); axis off;
      text(1, -2, ['\color[rgb]' FONT_COLOR '(p) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
          'HorizontalAlignment', 'Right', 'VerticalAlignment', 'Top');
      %colorbar
      subplot('position', [.755 .515 .205 .018]); axis off;
      colorbar('location', 'SouthOutside', 'XLim', [13.8 65], 'XTick', 13.8 : 25.6 : 65, 'XTickLabel', ...
          {'1', '1e-5', '1e-10'}, 'FontSize', CBAR_FSIZE);
%       colorbar('location', 'SouthOutside', 'XLim', [1 65], 'XTick', 1 : 64/3 : 65, 'XTickLabel', ...
%           {'1', '1e-10', '1e-20', '1e-30'}, 'FontSize', CBAR_FSIZE);
      %x label for the above 2 plots
      text(-.1, -.5, ['\color[rgb]' FONT_COLOR 'Sorted Reaction Time (sec, moving avg.)'], ...
          'fontsize', AXIS_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Top');

      %plot power increase over different frequent bands
      subplot('position', [.05 .07 .33 .335]); hold on;
      legend_string = 'legend(';
      for k = 1 : size(FREQ_INC, 1)
        freq_name = FREQ_INC{k, 1};
        freq_band = FREQ_INC{k, 2};
        freq_inc = FREQ_INC{k, 3};
        freq_color = FREQ_INC{k, 4};
        plot(freq_inc, 'Color', freq_color, 'LineWidth', .5);
        %deal with legend
        legend_string = [legend_string '''' freq_name ' (' int2str(freq_band(1)) '~' int2str(freq_band(2)) ' Hz)'', '];
      end
      plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', .5);  %dummy, for RT
      legend_string = [legend_string '''RT = 3 sec'', ''Location'', ''NorthWest'');'];
      legend_handle = eval(legend_string);
      legend('boxoff');
%       if strcmp(MN, 'motion')
        ylim_tmp = [-3 6];
%       else
%         ylim_tmp = [-1.5 6];
%       end
      set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2);
      set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', 1 : xstep_mov : size(RT_s_mov, 2), ...
          'XTickLabel', roundn(RT_s_mov(1 : xstep_mov : size(RT_s_mov, 2)), -2), 'YLim', ylim_tmp, ...
          'XColor', AXIS_COLOR, 'YColor', AXIS_COLOR, 'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
      %plot a vertical line with x axis on that point
      try
        plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
            'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
      end
      xlabel('Sorted Reaction Time (sec, moving avg.)');
      ylabel('Power (dB)', 'VerticalAlignment', 'Baseline');
      title(['\color[rgb]' FONT_COLOR 'Power on Frequency Bands'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');

      %plot sparse moving avg.
      subplot('position', [.44 .07 .5 .265]); hold on;
%       
%       urPB_latency = URPB{1, 3};
%       urPB_RT = URPB{2, 3};
      urPB_mov_latency = URPB_mov{1, 3};
      urPB_mov_RT = URPB_mov{2, 3};
%       sparse_xlim = [0 floor(urPB_latency / 500) * 500 + 500];
%       sparse_ylimRT = [0 floor(max(urPB_RT) / 50) * 50 + 50];
      sparse_xlim = [0 floor(urPB_mov_latency(end) / 500) * 500 + 500];
      sparse_ylim_movRT = [0 floor(max(urPB_mov_RT) / 50) * 50 + 50];
%       sparse_ylim = [min(min(sparse_ylim, sparse_ylim_mov)) max(max(sparse_ylim, sparse_ylim_mov))];
%       sparse_ylimRT = [0 max(max(sparse_ylimRT, sparse_ylim_movRT))];
      sparse_ylim = sparse_ylim_mov;
      sparse_ylimRT = sparse_ylim_movRT;
      sparse_ylim = [floor(sparse_ylim(1) / 5) * 5 ceil(sparse_ylim(2) / 5) * 5 + 10];
      for k = 1 : size(FREQ_BAND, 1)
%         urPB_inc = URPB{k + 2, 3};
%         urPB_color = URPB{k + 2, 4};
        urPB_mov_inc = URPB_mov{k + 2, 3};
        urPB_mov_color = URPB_mov{k + 2, 4};
        if k == 1
          %plot original power vs RT
%           [AX1, H11 H12] = plotyy(urPB_latency, urPB_inc, urPB_latency, urPB_RT);
%           set(H11, 'Color', urPB_color, 'LineWidth', .5, 'LineStyle', '--');
%           set(H12, 'Color', RT_COLOR, 'LineWidth', .5, 'LineStyle', '--');
%           set(AX2(1), 'XColor', AXIS_COLOR, 'Xlim', sparse_xlim, 'XTick', [], 'XTickLabel', [], ...
%               'YColor', AXIS_COLOR, 'Ylim', sparse_ylim, 'YTick', [], 'YTickLabel', []);
%           set(AX2(2), 'FontSize', AXIS_FSIZE, 'XColor', AXIS_COLOR, 'Xlim', sparse_xlim, 'XTick', [], 'XTickLabel', [], ...
%               'YColor', RT_COLOR, 'YScale', 'log',  'Ylim', sparse_ylim_movRT, 'YTick', [], 'YTickLabel', []);
          %plot moving avg. power vs RT
          [AX2, H21 H22] = plotyy(urPB_mov_latency, urPB_mov_inc, urPB_mov_latency, urPB_mov_RT);
          set(H21, 'Color', urPB_mov_color, 'LineWidth', .5);
          set(H22, 'Color', RT_COLOR, 'LineWidth', .5);
          set(AX2(1), 'XColor', AXIS_COLOR, 'Xlim', sparse_xlim, 'XTick', [], 'XTickLabel', [], ...
              'YColor', RT_COLOR, 'Ylim', sparse_ylim, 'YTick', [], 'YTickLabel', []);
          set(AX2(2), 'FontSize', AXIS_FSIZE, 'XColor', AXIS_COLOR, 'Xlim', sparse_xlim, 'XTick', [], 'XTickLabel', [], ...
              'YColor', RT_COLOR, 'YScale', 'log',  'Ylim', sparse_ylim_movRT, ...
              'YTick', 10 .^ (-1 : 1 : log10(sparse_ylim_movRT(2))), 'YTickLabel', 10 .^ (-1 : 1 : log10(sparse_ylim_movRT(2))), 'YMinorTick', 'on');
          set(get(AX2(1),'YLabel'), 'String', 'Power (dB)', 'FontSize', AXIS_FSIZE);
          set(get(AX2(2),'YLabel'), 'String', 'Reaction Time (Sec)', 'FontSize', AXIS_FSIZE);
        else
%           %plot original power
%           plot(urPB_latency, urPB_inc, 'Color', urPB_color, 'LineWidth', .5, 'LineStyle', '--');
          %plot moving avg. power  
          plot(urPB_mov_latency, urPB_mov_inc, 'Color', urPB_mov_color, 'LineWidth', .5);
        end
      end
      set(gca, 'COLOR', BACKGROUND_COLOR, 'FontSize', AXIS_FSIZE, 'Box', 'off', ...
          'XColor', AXIS_COLOR, 'Xlim', sparse_xlim, 'XTick', 0 : 1000 : sparse_xlim(2), 'XTickLabel', 0 : 1000 : sparse_xlim(2), ...
          'YColor', AXIS_COLOR, 'Ylim', sparse_ylim, 'YTick', 0 : 10 : sparse_ylim(2), 'YTickLabel', 0 : 10 : sparse_ylim(2));
      set(get(gca,'XLabel'), 'String', 'Experiment Latency (Sec)', 'FontSize', AXIS_FSIZE);
%       ylabel('Power (dB)')
      %title
      subplot('position', [.44 .405 .5 .07]); axis off;
      text(.5, 0, ['\color[rgb]' FONT_COLOR 'Correlation Between Alpha/Theta Power and Reaction Time'], ...
          'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
      %add text
      subplot('position', [.44 .335 .5 .07]); axis off;
      set(gca, 'XMinorGrid', 'on');
      %width of 1st column: .16
      text(0, 1/2, ['\color[rgb]' FONT_COLOR 'Corr. Coef.'], ...
          'FontName', FONT_FACE, 'FontSize', FONT_SIZE, 'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Middle');
      text(0, 1/6, ['\color[rgb]' FONT_COLOR 'P-Val.'], ...
          'FontName', FONT_FACE, 'FontSize', FONT_SIZE, 'HorizontalAlignment', 'Left', 'VerticalAlignment', 'Middle');
      colwidth = (1 - .16) / (size(URPB_mov, 1) - 2);  %.16: width of 1st col
      urPB_RT_text = URPB_mov{2, 1};
      urPB_RT_color = mat2str(URPB_mov{2, 4}); urPB_RT_color(1) = '{'; urPB_RT_color(end) = '}';
      for k = 1 : size(URPB_mov, 1) - 2  %-2: the first 2 col: latency and RT
        urPB_title = URPB_mov{k + 2, 1};
        urPB_color = mat2str(URPB_mov{k + 2, 4}); urPB_color(1) = '{'; urPB_color(end) = '}';
        urPB_corr = num2str(URPB_mov{k + 2, 5}, '%.2f');
        urPB_p_val = URPB_mov{k + 2, 7};
        %title
        text(.16 + colwidth * k - colwidth / 2 , 5/6, ['\color[rgb]' urPB_color urPB_title ...
            '\color[rgb]' FONT_COLOR '_ _V_S_ log_1_0(\color[rgb]' urPB_RT_color urPB_RT_text '\color[rgb]' FONT_COLOR ')'], ...
            'FontName', FONT_FACE, 'FontSize', FONT_SIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle');
        %corr coef
        text(.16 + colwidth * k - colwidth / 2 , 3/6, ['\color[rgb]' FONT_COLOR urPB_corr], ...
            'FontName', FONT_FACE, 'FontSize', FONT_SIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle');
        %p-val
        text(.16 + colwidth * k - colwidth / 2 , 1/6, ['\color[rgb]' FONT_COLOR urPB_p_val], ...
            'FontName', FONT_FACE, 'FontSize', FONT_SIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle');
      end
      URPB(:, 7) = [];
      URPB_mov(:, 7) = [];

%% save figure and necessary variables
      saveas(1026, [FilePathOld 'RS' SL MN SL 'IC' num2str(cls, '%02d') SL Set '_PBaseRT_' num2str(comp, '%02d') rj 'A.fig']);
      print('-dpng', [FilePathOld 'RS' SL MN SL 'IC' num2str(cls, '%02d') SL Set '_PBaseRT_' num2str(comp, '%02d') rj 'A.png']);
      save([FilePathOld 'RS' SL MN SL 'IC' num2str(cls, '%02d') SL Set '_PBaseRT_' num2str(comp, '%02d') rj 'A.mat'], ...
          'PB', 'PB_mean', 'PB_alert', 'PB_n', 'PB_mov', 'freqs', 'RT', 'RT_s', 'RT_s_mov', 'FREQ_INC', 'H_mask', 'P_mask', 'p_val', 'URPB', 'URPB_mov');
%       print('-dpng', [FilePathOld 'RS' SL 'all' SL MN SL 'IC' num2str(cls, '%02d') SL Set '_PBaseRT_' num2str(comp, '%02d') rj '_all.png']);
%       save([FilePathOld 'RS' SL 'all' SL MN SL 'IC' num2str(cls, '%02d') SL Set '_PBaseRT_' num2str(comp, '%02d') rj '_all.mat'], ...
%           'PB', 'PB_mean', 'PB_alert', 'PB_n', 'PB_mov', 'freqs', 'RT', 'RT_s', 'RT_s_mov', 'FREQ_INC', 'H_mask', 'P_mask', 'p_val', 'URPB', 'URPB_mov');
%       print('-dpng', [FilePathOld 'RS' SL 'dev_on' SL MN SL 'IC' num2str(cls, '%02d') SL Set '_PBaseRT_' num2str(comp, '%02d') rj '_dev_on.png']);
%       save([FilePathOld 'RS' SL 'dev_on' SL MN SL 'IC' num2str(cls, '%02d') SL Set '_PBaseRT_' num2str(comp, '%02d') rj '_dev_on.mat'], ...
%           'PB', 'PB_mean', 'PB_alert', 'PB_n', 'PB_mov', 'freqs', 'RT', 'RT_s', 'RT_s_mov', 'FREQ_INC', 'H_mask', 'P_mask', 'p_val', 'URPB', 'URPB_mov');
%       saveas(1026, ['~/' Set '_PBaseRT_' num2str(comp, '%02d') rj 'A.fig']);
%       print('-dpng', ['~/'  Set '_PBaseRT_' num2str(comp, '%02d') rj 'A.png']);
%       save(['~/' Set '_PBaseRT_' num2str(comp, '%02d') rj 'A.mat'], ...
%           'PB', 'PB_mean', 'PB_alert', 'PB_n', 'PB_mov', 'freqs', 'RT', 'RT_s', 'RT_s_mov', 'alpha_inc', 'theta_inc', ...
%           'urPB', 'urPB_mov', 'alpha_corr', 'p_alpha', 'theta_corr', 'p_theta', 'alpha_mov_corr', 'p_alpha_mov', 'theta_mov_corr', 'p_theta_mov');
      close(1026);

%%
    end
  else
    fprintf('%s: not valid, check set name or condition (motion/motionless).\n', plot_set);
  end
end