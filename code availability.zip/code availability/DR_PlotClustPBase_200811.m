%power spectra cross subjects
%mostly base on RS_powbase
%This version: 2008/11 by poem

%% set parameters (initialize)
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/RS/';  %directory
  SL = '/';
end
DR_PBase_setup;  %load setup file
%datasets
PLOT_SET = {
            's31_061103';  %motionless
            's32_061031';  %motionless
            's35_070322';  %motionless
            's36_061221';  %motionless
%             's37_071213';  %motionless
%             's39_070117';  %motionless
            's40_070207';  %motionless
            's41_061225';  %motionless
            's42_070105';  %motionless
            's43_070208';  %motionless
            's44_070325';  %motionless
            's31_061020';  %motion
            's35_070115';  %motion
            's36_061122';  %motion
            's39_061218';  %motion
            's40_070131';  %motion
            's43_070202';  %motion
            's44_070126';  %motion
           };
MN = 'motion';
if strcmp(MN, 'motionless')
  MN_COLOR = '{0 0 1}';
elseif strcmp(MN, 'motion')
  MN_COLOR = '{1 0 0}';
else
  MN_COLOR = '{0 1 0}';
end
movstep = 1;  %stepping for moving avg
xstep_int = 5;
mypath;
FilePathOld = [FilePath MN SL];
try
  close(1024);
end

%% assign component to cluster
for i = 1 :size(ClsLabel, 1)
   com = sprintf('IC%02d = {ClsLabel{%d}};', i, i); eval(com);
   com = sprintf('subj_seq%02d = {};', i); eval(com);  %# of sessions in a cluster
   com = sprintf('session_count%02d = 0;', i); eval(com);
end
for i = 1 : size(PLOT_SET, 1)
  FilePath = FilePathOld;
  plot_set = PLOT_SET{i, 1};
  %check if the plot_set is valid
  for j = 1 : size(SET, 1)
    Set = SET{j, 1};
    condition = SET{j, 3};
    if strcmp(Set, plot_set)  %dataset found in database, checking if condition is ok
      oldcls = zeros(1, size(ClsLabel, 1));  %register to memorize if the cluster shown before
      if strcmp(condition, MN)  %condition ok => dataset valid => process
        COMP = SET{j, 2};
        for k = 1 : size(COMP, 2)
          comp = COMP(1, k);  %componet #
          comp_cls = COMP(2, k);  %which cluster
          if comp_cls > 0
            IC_tmp = {Set, comp};
            com = sprintf('IC%02d = [IC%02d IC_tmp];', comp_cls, comp_cls); eval(com);
            if ~oldcls(comp_cls)  %first appearing
              oldcls(comp_cls) = true;
              com = sprintf('session_count%02d = session_count%02d + 1;', comp_cls, comp_cls); eval(com);
            end
          end
        end
      else  %codition not ok => invalid
        fprintf('%s: not valid, check set name or condition (motion/motionless).\n', plot_set);
      end
      break;
    end
    if j == size(SET, 1)  %not able to find dataset
      fprintf('%s: not valid, check set name or condition (motion/motionless).\n', plot_set);
    end
  end
end

%% process data
for i = 1 : size(ClsLabel, 1)
  FilePath = FilePathOld;
  com = sprintf('IC_tmp = IC%02d;', i); eval(com);  %IC_tmp: sorted by subject list given above
  com = sprintf('session_count = session_count%02d;', i); eval(com);
  subj_seq = {};
  session_id = 0;  %the same dataset => session id NOT the same across clusters
  old_set = '';
  %load icawinv for plotting component maps
  tmp_icawinv = load([FilePath 'IC' num2str(i, '%02d') '_component_map_' cls_ver], 'avg_icawinv', 'std_chanlocs');  %tmp_set.PB_mean: row: freq, col: trial  
  icawinv = tmp_icawinv.avg_icawinv;
  chanlocs = tmp_icawinv.std_chanlocs;
  clear tmp_icawinv;
  FilePath = [FilePath 'IC' num2str(i, '%02d') SL];
  cls_length = (size(IC_tmp, 2) - 1) / 2;
  allAlpha = [];
  allTheta = [];
  allRT_s = [];
  RT_s = [];
  PB_mean = [];
  PB_alert_subj = [];  %baseline power for alert trials of each subject. only for the first normalize method
  if nor == 3 || nor == 4
    PB_alert = 0;
  else
    PB_alert = [];
  end
  PB_n = [];
  for j = 1 : cls_length
    plot_set = IC_tmp{1, 2 * j};
    plot_comp = IC_tmp{1, 2 * j + 1};
    tmp_cell = {};  %for storing session
    tmp_arr = [];  %for storing session ID (easy to access when calculating);
    %counting session id
    if ~strcmp(old_set, plot_set)  %new dataset
      session_id = session_id + 1;
    end
    %load dataset
    tmp_set = load([FilePath plot_set '_PBaseRT_' num2str(plot_comp, '%02d') rj 'A'], 'RT_s', 'PB_mean', 'freqs');  %tmp_set.PB_mean: row: freq, col: trial
    RT_s = [RT_s tmp_set.RT_s];
    PB_mean = [PB_mean tmp_set.PB_mean];
    freqs = tmp_set.freqs;
    %recording session according to trials (length of PB_mean or RT_s)
    tmp_cell(1 : size(tmp_set.PB_mean, 2)) = {plot_set};
    tmp_arr(1 : size(tmp_set.PB_mean, 2)) = session_id;
    tmp_arr_cell = mat2cell(tmp_arr, ones(1, size(tmp_arr, 1)), ones(1, size(tmp_arr, 2)));
    subj_seq = [subj_seq [tmp_cell; tmp_arr_cell]];
    switch nor
      case 1
        alert.trials = ceil(size(tmp_set.PB_mean, 2) * alert.rate);  %find baseline
        PB_alert_tmp = tmp_set.PB_mean(:, 1 : alert.trials);  %calculating power of alert trials
        PB_alert_tmp = mean(PB_alert_tmp, 2) * ones(1, length(tmp_set.RT_s));  %padding
        PB_n_tmp = tmp_set.PB_mean - PB_alert_tmp;  %normalized by power in alert stage
        PB_alert = [PB_alert PB_alert_tmp];
        PB_n = [PB_n PB_n_tmp];
        if j == cls_length  %finish loading dataset, calculate baseline
          [RT_s ur_idx] = sort(RT_s, 2);  %sort by RT
          PB_mean = PB_mean(:, ur_idx);
%           PB_alert = PB_alert(:, ur_idx);
          PB_n = PB_n(:, ur_idx);
          subj_seq = subj_seq(:, ur_idx);
          subj_seq_id = cell2mat(subj_seq(2, :));
        end
        if ~strcmp(old_set, plot_set)
          PB_alert_subj = [PB_alert_subj PB_alert_tmp(:, 1)];
        end
      case 2
        if j == cls_length  %finish loading dataset, calculate baseline
          [RT_s ur_idx] = sort(RT_s, 2);  %sort by RT
          PB_mean = PB_mean(:, ur_idx);
%           PB_mean = sortrows(PB_mean', size(PB_mean, 1))';  %sort by RT
%           RT_s = PB_mean(end, :);
%           PB_mean(end, :) = [];
          alert.trials = ceil(size(PB_mean, 2) * alert.rate);  %find baseline
          PB_alert = PB_mean(:, 1 : alert.trials);  %calculating power of alert trials
          PB_alert = mean(PB_alert, 2) * ones(1, length(RT_s));  %padding
          PB_n = PB_mean - PB_alert;  %normalized by power in alert stage
        end
      case {3, 4}
        alert.trials = ceil(size(tmp_set.PB_mean, 2) * alert.rate);  %find baseline
        PB_alert_tmp = tmp_set.PB_mean(:, 1 : alert.trials);  %calculating power of alert trials
        if nor == 4
          PB_alert = PB_alert + length(tmp_set.RT_s) * mean(PB_alert_tmp, 2);  %weighted sum
        else
          PB_alert = PB_alert + mean(PB_alert_tmp, 2);  %direct sum
        end
        if j == cls_length  %finish loading dataset, calculate baseline
          [RT_s ur_idx] = sort(RT_s, 2);  %sort by RT
          PB_mean = PB_mean(:, ur_idx);
          if nor == 4
            PB_alert = PB_alert / length(RT_s) * ones(1, length(RT_s));
          else
            PB_alert = PB_alert / cls_length * ones(1, length(RT_s));  %averaging baseline and padding
          end
          PB_n = PB_mean - PB_alert;
        end
    end
    old_set = plot_set;
  end
  alert.trials = ceil(size(RT_s, 2) * alert.rate);

  %moving average
  PB_mov = [];
  RT_s_mov = [];
  for j = 1 : movstep : size(PB_n, 2) - (alert.trials - 1)
%     PB_mov = [PB_mov mean(PB_n(:, j : j + alert.trials - 1), 2)];
%     RT_s_mov = [RT_s_mov mean(RT_s(:, j : j + alert.trials - 1), 2)];
%     aaa = trimmean(PB_n(:, j : j + alert.trials - 1), 2, 10);keyboard;
    PB_mov = [PB_mov trimmean(PB_n(:, j : j + alert.trials - 1), 10, 2)];
    RT_s_mov = [RT_s_mov trimmean(RT_s(:, j : j + alert.trials - 1), 10, 2)];
  end
  %compute power over different freq bands
  FREQ_INC = {};
  for k = 1 : size(FREQ_BAND, 1)
    freq_band = FREQ_BAND{k, 2};
    FREQ_INC(k, 1) = FREQ_BAND(k, 1);
    FREQ_INC(k, 2) = FREQ_BAND(k, 2);
    FREQ_INC(k, 3) = {mean(PB_mov(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :))};
    FREQ_INC(k, 4) = FREQ_BAND(k, 3);
    %curve fitting
%     tmp_inc_freq = mean(PB_n(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :));
    tmp_inc_freq = trimmean(PB_n(find(freqs >= FREQ_BAND{k, 2}(1) & freqs <= FREQ_BAND{k, 2}(2)), :), 10);
    [tmp_p tmp_S] = polyfit(RT_s, tmp_inc_freq, curfit_order);
%     keyboard
    tmp_p_val = polyval(tmp_p, RT_s);
    tmp_p_mov = [];
%     tmp_inc_freq_mov = [];
    for m = 1 : movstep : size(PB_n, 2) - (alert.trials - 1)
%       tmp_p_mov = [tmp_p_mov mean(tmp_p_val(:, m : m + alert.trials - 1), 2)];
      tmp_p_mov = [tmp_p_mov trimmean(tmp_p_val(:, m : m + alert.trials - 1), 10, 2)];
%       tmp_inc_freq_mov = [tmp_inc_freq_mov mean(tmp_inc_freq(:, m : m + alert.trials - 1), 2)];
    end
    FREQ_INC(k, 5) = {tmp_p};
    FREQ_INC(k, 6) = {tmp_S};
    FREQ_INC(k, 7) = {tmp_p_mov};
%     keyboard
  end

  %statistics
  fprintf('Performing 2-tail T-test (p = %g): \n', p_val);
  P_mask = zeros(size(PB_mov));
  H_mask = P_mask;
  sig_idx = 1 : movstep : floor(size(PB_n, 2) / movstep) - (alert.trials - 1);
  for j = 1 : size(PB_mov, 2)
    PB_tmp = PB_mean(:, sig_idx(j) : sig_idx(j) + alert.trials - 1);
    PB_alert_tmp = 0;
    if nor == 1
      subj_seq_id_tmp = subj_seq_id(:, sig_idx(j) : sig_idx(j) + alert.trials - 1);
      %counting how many trials of each subject in this window
      n_of_subj_win = 0;  %number of subjects in a moving window
      for k = 1 : session_count
        n_of_trial = length(find(subj_seq_id_tmp == k));
        if ~isempty(n_of_trial)
          PB_alert_tmp = PB_alert_tmp + PB_alert_subj(:, k) * n_of_trial;  %adding the power of alert trials according to propotion
          n_of_subj_win = n_of_subj_win + 1;
        else
          keyboard;
        end
      end
      PB_alert_tmp = PB_alert_tmp * ones(1, alert.trials) / alert.trials;
    else
      n_of_subject_win = 1;  %use the same baseline, no need do consider the difference between subjects
      PB_alert_tmp = PB_alert(:, 1 : alert.trials);
    end
    %corrected p_val: / 2: 2-tail; / size(freqs, 2): freq bins;
%     [H, P] = ttest2(PB_tmp', PB_alert_tmp', p_val / 2 / size(freqs, 2) / alert.trials, 'both');
    [H, P] = ttest2(PB_tmp', PB_alert_tmp', p_val / 2 / size(freqs, 2) / n_of_subj_win, 'both');
    H_mask(:, j) = H';
    P_mask(:, j) = P';
  end

%% plot figure
  %larger font size is ok
  STITLE_FSIZE = 9;  %subtitle
  AXIS_FSIZE = 8;  %axis
  CBAR_FSIZE = 8;  %color bar
  figure(1024); hold on;
  xstep = (size(RT_s, 2) - 1) / xstep_int;
  xstep_mov = (size(RT_s_mov, 2) - 1) / xstep_int;

  %plot component map
  subplot('position', [.03 .88 .12 .12]); axis off;
  topoplot(icawinv, chanlocs, 'electrodes', 'off', 'shrink', 'force');
  set(gcf, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off', 'Render', 'Zbuffer');  %set AFTER opoplot to preserve backgound color

  %title
  subplot('position', [.15 .85 .8 .15]); axis off;
  text(.5, .6, ...
      {['\color[rgb]' FONT_COLOR 'Baseline Power Spectra on Alpha and Theta Bands of \color[rgb]{0 0 1}' IC_tmp{1} '\color[rgb]' FONT_COLOR  ' Cluster']; ...
      ['(\color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ', ' int2str(length(RT_s)) ' Trials from ' int2str(cls_length) ...
      ' Components in ' int2str(session_count) ' Sessions)']}, ...
      'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'bold', ...
      'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');

  %plot original power image
  subplot('position', [.055 .55 .26 .3]); hold on;
%   subplot('position', [.05 .533 .205 .317]); hold on;
  imagesc(1 : size(RT_s, 2), freqs, PB_mean, [-50 50]);
  set(gca, 'Xlim', [1 size(RT_s, 2)], 'XTick', 1 : xstep : size(RT_s, 2), ...
      'XTickLabel', roundn(RT_s(1 : xstep : size(RT_s, 2)), -2), 'XColor', AXIS_COLOR, ...
      'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
  %mark frequencies
  for k = 10 : 10 : 40
    plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
  end
  %plot a vertical line with x axis on that point
  try
    plot([find(RT_s <= 3, 1, 'last') find(RT_s <= 3, 1, 'last')], get(gca, 'Ylim'), ...
        'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
  end
  ylabel('Frequency (Hz)', 'VerticalAlignment', 'Baseline');
  title(['\color[rgb]' FONT_COLOR 'Original Baseline Power Image'], ...
      'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
  %colorbar
  subplot('position', [.025 .532 .03 .018]); axis off;
%   subplot('position', [.02 .515 .03 .018]); axis off;
  text(1, -2, ['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
      'HorizontalAlignment', 'Right', 'VerticalAlignment', 'Top');
  subplot('position', [.055 .532 .26 .018]); axis off;
%   subplot('position', [.05 .515 .205 .018]); axis off;
  colorbar('location', 'SouthOutside', 'XTick', 1 : 16 : 65, 'XTickLabel', -50 : 25 : 50, 'FontSize', CBAR_FSIZE);

  %plot normalized power image
  subplot('position', [.37 .55 .26 .3]); hold on;
%   subplot('position', [.285 .533 .205 .317]); hold on;
  imagesc(1 : size(RT_s, 2), [freqs(1) freqs(end)], PB_n, [-25 25]);
  set(gca, 'Xlim', [1 size(RT_s, 2)], 'XTick', 1 : xstep : size(RT_s, 2), ...
      'XTickLabel', roundn(RT_s(1 : xstep : size(RT_s, 2)), -2), 'XColor', AXIS_COLOR, ...
      'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, ...
      'YTickLabel', [], 'FontSize', AXIS_FSIZE);
  %mark frequencies
  for k = 10 : 10 : 40
    plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
  end
  %plot a vertical line with x axis on that point
  try
    plot([find(RT_s <= 3, 1, 'last') find(RT_s <= 3, 1, 'last')], get(gca, 'Ylim'), ...
        'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
  end
  title(['\color[rgb]' FONT_COLOR 'Normalized Baseline Power Image'], ...
      'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
  %colorbar
  subplot('position', [.37 .532 .26 .018]); axis off;
%   subplot('position', [.285 .515 .205 .018]); axis off;
  colorbar('location', 'SouthOutside', 'XTick', 1 : 16 : 65, 'XTickLabel', -25 : 12.5 : 25, 'FontSize', CBAR_FSIZE);
  %x label for the above 2 plots
  text(-.1, -.5, ['\color[rgb]' FONT_COLOR 'Sorted Reaction Time (sec)'], ...
      'fontsize', AXIS_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Top');

  %plot moving avg. power image
  subplot('position', [.055 .098 .26 .3]); hold on;
%   subplot('position', [.52 .533 .205 .317]); hold on;
  imagesc(1 : size(RT_s_mov, 2), freqs, PB_mov, [-3 6]);
  contour(1 : size(RT_s_mov, 2), freqs, H_mask, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
  set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', 1 : xstep_mov : size(RT_s_mov, 2), ...
      'XTickLabel', roundn(RT_s_mov(1 : xstep_mov : size(RT_s_mov, 2)), -2), 'XColor', AXIS_COLOR, ...
      'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, 'FontSize', AXIS_FSIZE);
  %mark frequency
  for k = 10 : 10 : 40
    plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
  end
  %plot a vertical line with x axis on that point
  try
    plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
        'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
  end
  ylabel('Frequency (Hz)', 'VerticalAlignment', 'Baseline');
  title({['\color[rgb]' FONT_COLOR 'Moving Avg Baseline Power Image']; ['(Countour: p < ' num2str(p_val, '%.e') ')']}, ...
      'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');  %V. alignment not using 'baseline'
  %colorbar
  subplot('position', [.025 .08 .03 .018]); axis off;
%   subplot('position', [.02 .515 .03 .018]); axis off;
  text(1, -2, ['\color[rgb]' FONT_COLOR '(dB) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
      'HorizontalAlignment', 'Right', 'VerticalAlignment', 'Top');
  subplot('position', [.055 .08 .26 .018]); axis off;
%   subplot('position', [.05 .515 .205 .018]); axis off;
%   colorbar('location', 'SouthOutside', 'XTick', 1 : 16 : 65, 'XTickLabel', -6 : 3 : 6, 'FontSize', CBAR_FSIZE);
%   colorbar('location', 'SouthOutside', 'XLim', [13.8 52.2], 'XTick', 13.8 : 9.6 : 52.2, 'XTickLabel', -6 : 3 : 6, 'FontSize', CBAR_FSIZE - 1);
%   colorbar('location', 'SouthOutside', 'XLim', [13.8 52.2], 'XTick', 13.8 : 9.6 : 52.2, 'XTickLabel', -6 : 3 : 6, 'FontSize', CBAR_FSIZE);
  colorbar('location', 'SouthOutside', 'XLim', [1 65], 'XTick', 1 : 64/3 : 65, 'XTickLabel', -3 : 3 : 6, 'FontSize', CBAR_FSIZE);

  %plot p-value image
  subplot('position', [.37 .098 .26 .3]); hold on;
%   subplot('position', [.755 .533 .205 .317]); hold on;
%   imagesc(1 : size(RT_s_mov, 2), freqs, -log10(P_mask), [-10 50]);
  imagesc(1 : size(RT_s_mov, 2), freqs, -log10(P_mask), [-10 30]);
  contour(1 : size(RT_s_mov, 2), freqs, H_mask, 1, 'LineColor', CONTOUR_COLOR * 0, 'LineWidth', CONTOUR_WIDTH);
  set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', 1 : xstep_mov : size(RT_s_mov, 2), ...
      'XTickLabel', roundn(RT_s_mov(1 : xstep_mov : size(RT_s_mov, 2)), -2), 'XColor', AXIS_COLOR, ...
      'Ylim', [freqs(1) freqs(end)], 'YTick', 10 : 10 : freqs(end), 'YColor', AXIS_COLOR, ...
      'YTickLabel', [], 'FontSize', AXIS_FSIZE);
  %mark frequency
  for k = 10 : 10 : 40
    plot(get(gca, 'Xlim'), [k k], ':k', 'LineWidth', 1);
  end
  %plot a vertical line with x axis on that point
  try
    plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
        'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
  end
  title({['\color[rgb]' FONT_COLOR 'P-Value Image']; ['(Contour: p < ' num2str(p_val, '%.e') ')']}, ...
      'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
  subplot('position', [.34 .08 .03 .018]); axis off;
%   subplot('position', [.725 .515 .03 .018]); axis off;
  text(1, -2, ['\color[rgb]' FONT_COLOR '(p) '], 'FontName', FONT_FACE, 'FontSize', FONT_SIZE - 2, ...
      'HorizontalAlignment', 'Right', 'VerticalAlignment', 'Top');
  %colorbar
  subplot('position', [.37 .08 .26 .018]); axis off;
%   subplot('position', [.755 .515 .205 .018]); axis off;
%   colorbar('location', 'SouthOutside', 'XLim', [35 131] / 3, 'XTick', (35 : 16 : 131) / 3, 'XTickLabel', ...
%       {'1', '1e-5', '1e-10', '1e-15', '1e-20', '1e-25', '1e-30'}, 'FontSize', CBAR_FSIZE - 1);
%   colorbar('location', 'SouthOutside', 'XLim', [35 131] / 3, 'XTick', (35 : 16 : 131) / 3, 'XTickLabel', ...
%       {'1', '1e-5', '1e-10', '1e-15', '1e-20', '1e-25', '1e-30'}, 'FontSize', CBAR_FSIZE - 1);
%   colorbar('location', 'SouthOutside', 'XLim', [13.8 65], 'XTick', 13.8 : 25.6 : 65, 'XTickLabel', ...
%       {'1', '1e-5', '1e-10'}, 'FontSize', CBAR_FSIZE - 1);
%   colorbar('location', 'SouthOutside', 'XLim', [13.8 65], 'XTick', 13.8 : 25.6 : 65, 'XTickLabel', ...
%       {'1', '1e-5', '1e-10'}, 'FontSize', CBAR_FSIZE);
  colorbar('location', 'SouthOutside', 'XLim', [17 65], 'XTick', 17 : 16 : 65, 'XTickLabel', ...
      {'1', '1e-10', '1e-20', '1e-30'}, 'FontSize', CBAR_FSIZE);
  %x label for the above 2 plots
  text(-.1, -.5, ['\color[rgb]' FONT_COLOR 'Sorted Reaction Time (sec, moving avg.)'], ...
      'fontsize', AXIS_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Top');
  
  %plot power increase over different frequent bands
  subplot('position', [.685 .055 .26 .795]); hold on;
%   subplot('position', [.05 .07 .91 .335]); hold on;
%   subplot('position', [.05 .07 .33 .335]); hold on;
  legend_string = 'legend(';
  for k = 1 : size(FREQ_INC, 1)
    freq_name = FREQ_INC{k, 1};
    freq_band = FREQ_INC{k, 2};
    freq_inc = FREQ_INC{k, 3};
    freq_color = FREQ_INC{k, 4};
    freq_poly = FREQ_INC{k, 5};
    freq_poly_val = FREQ_INC{k, 7};
    plot(freq_inc, 'Color', freq_color, 'LineWidth', 1);
    plot(freq_poly_val, 'Color', freq_color, 'LineWidth', .5, 'LineStyle', '--');
    %deal with legend
    if freq_poly(1) ~= 0
      freq_poly_string = [num2str(freq_poly(1), '%.4f') '(RT)^' num2str(curfit_order, '%g')];
    end
    for m = curfit_order - 1 : -1 : 0
      if freq_poly(curfit_order + 1 - m) > 0
        if m > 1
          freq_poly_string = [freq_poly_string ' + ' num2str(freq_poly(curfit_order + 1 - m), '%.4f') '(RT)^' num2str(m, '%g')];
        elseif m == 1
          freq_poly_string = [freq_poly_string ' + ' num2str(freq_poly(curfit_order + 1 - m), '%.4f') '(RT)'];
        else
          freq_poly_string = [freq_poly_string ' + ' num2str(freq_poly(curfit_order + 1 - m), '%.4f')];
        end
      elseif freq_poly(curfit_order + 1 - m) < 0
        if m > 1
          freq_poly_string = [freq_poly_string ' - ' num2str(-freq_poly(curfit_order + 1 - m), '%.4f') '(RT)^' num2str(m, '%g')];
        elseif m == 1
          freq_poly_string = [freq_poly_string ' - ' num2str(-freq_poly(curfit_order + 1 - m), '%.4f') '(RT)'];
        else
          freq_poly_string = [freq_poly_string ' - ' num2str(-freq_poly(curfit_order + 1 - m), '%.4f')];
        end
      end
    end
    legend_string = [legend_string '''' freq_name ' (' int2str(freq_band(1)) '~' int2str(freq_band(2)) ' Hz)'', '];
    legend_string = [legend_string '''' '\fontsize{' int2str(FONT_SIZE - 2) '}' freq_poly_string ''', '];
  end
  plot(0, 0, 'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', .5);  %dummy, for RT
  legend_string = [legend_string '''RT = 3 sec'', ''Location'', ''NorthWest'');'];
  legend_handle = eval(legend_string);
  legend('boxoff');
%   if strcmp(MN, 'motion')
    ylim_tmp = [-3 6];
%   else
%     ylim_tmp = [-1.5 6];
%   end
%   set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE ''- 2);
  set(legend_handle, 'Color', BACKGROUND_COLOR, 'FontName', FONT_FACE, 'FontSize', FONT_SIZE);
  set(gca, 'Xlim', [1 size(RT_s_mov, 2)], 'XTick', 1 : xstep_mov : size(RT_s_mov, 2), ...
      'XTickLabel', roundn(RT_s_mov(1 : xstep_mov : size(RT_s_mov, 2)), -2), 'YLim', ylim_tmp, ...
      'XColor', AXIS_COLOR, 'YColor', AXIS_COLOR, 'FontSize',AXIS_FSIZE, 'Color', BACKGROUND_COLOR);
  %plot a vertical line with x axis on that point
  try
    plot([find(RT_s_mov <= 3, 1, 'last') find(RT_s_mov <= 3, 1, 'last')], get(gca, 'Ylim'), ...
        'Color', RT_COLOR, 'LineStyle', '--', 'LineWidth', 1);
  end
  xlabel('Sorted Reaction Time (sec, moving avg.)');
  ylabel('Power (dB)', 'VerticalAlignment', 'Baseline');
  title(['\color[rgb]' FONT_COLOR 'Power on Frequency Bands'], ...
      'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE , 'VerticalAlignment', 'baseline', 'FontWeight', 'bold');
  IC_tmp = ['IC' num2str(i, '%02d')];

%% save figure;
%   saveas(1024, [FilePathOld 'RS/IC' num2str(cls, '%02d') '/' SL Set '_PBaseRT_' num2str(comp, '%02d') rj 'A.fig']);
%   print('-dpng', [FilePathOld 'RS/IC' num2str(cls, '%02d') '/' SL Set '_PBaseRT_' num2str(comp, '%02d') rj 'A.png']);
%   keyboard;
%   keyboard
  saveas(1024, [FilePathOld 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '.fig']);
  print('-dpng', [FilePathOld 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '.png']);
%   %save necessary variables
  save([FilePathOld 'IC' num2str(i, '%02d') '_PBase_' int2str(nor) '.mat'], ...
         'session_count', 'icawinv', 'chanlocs', 'freqs', 'RT_s', 'RT_s_mov', 'subj_seq', 'p_val', ...
         'PB_mean', 'PB_alert', 'PB_n', 'PB_alert_subj', 'PB_mov', 'FREQ_INC');
  close(1024);

%%
end