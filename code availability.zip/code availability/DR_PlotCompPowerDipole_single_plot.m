%component maps, dipoles and power spectra in a cluster (only one subject in a plot)
%run after finishing running DR_PlotCompPowerDipole

%% set parameters (initialize)
clear all;
try
  close(4001);  %dipole (final)
end
try
  close(4002);  %dipole (tmp)
end
try
  close(4003);  %component map
end
try
  close(4009);  %spectra
end
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/';  %directory
  SL = '/';
end
DR_PBase_setup;  %load setup file
MN = 'motionless';
plot_all = true;  %true: plot rejected components; false: only plot selected components
FilePathOld = FilePath;
rj = '_rj';
n_of_cls = size(ClsLabel, 1);  %# of cluster
undef_cls = n_of_cls + 1;
%for component map
% std_chanlocs = '~/30ch.xyz';  %standard channel location file
%axes limites for plotting power spectra
power_xlim = [0 50];
power_ylim = [-30 10];
avg = '_trim';  %method for averaging
%dipole
view_angle = [45 30];  %view angles
view_angle_single = [40 20];
HeadFilePath = '/home/eeglab5.03/eeglab5.03/plugins/dipfit2.0/standard_BESA/';  %.4, using BESA
hdmfile = [HeadFilePath 'standard_BESA.mat'];  %head model
mrifile = '/home/eeglab5.03/eeglab5.03/plugins/dipfit2.0/standard_BEM/standard_mri.mat';  %MRI file, using MNI in paper
chanfile = [HeadFilePath 'standard-10-5-cap385.elp'];  %electrodes
dip_option = {%for plotting dipole. see help -> pop_dipplot / dipplot for details
              '''axistight'', ' '''off'', ', ...  %for MRI only, display the closest MRI slide
              '''drawedges'', ' '''off'', ', ...  %draw edges of the 3-D MRI (black in axistight, white otherwise.)
              '''mesh'', '      '''off'', ', ...  %display spherical mesh
              '''gui'', '       '''off'', ', ...  %display controls. if gui 'off', a new figure is not created.
              '''summary'', '   '''off'', ', ...  %build a summary plot with three views (top, back, side)
              '''verbose'', '   '''off'', ', ...  %comment on operations on command line
              '''normlen'', '   '''on'', ' , ...  %normalize length of all dipoles
              '''num'', '       '''off'', ', ...  %display component number
              '''cornermri'', ' '''off'', ', ...  %force MRI images to the corner of the MRI volume (useful when background is not black)
              '''projimg'', '   '''on'', ' , ...  %project dipole(s) onto the 2-D images, for use in making 3-D plots
              '''projlines'', ' '''on'', ' , ...  %plot lines connecting dipole with 2-D projection
              '''pointout'', '  '''off'', ', ...  %point the dipoles outward
              '''spheres'', '   '''off'''    ...  %plot dipole markers as 3-D spheres
             };
dip_color = {%for single dipole map
             [0 0 1];
             [0 1 0];
             [0 1 1];
             [1 0 0];
             [1 0 1];
             [1 1 0];
             [0 0 .66];
             [0 .66 0];
             [0 .66 .66];
             [.66 0 0];
             [.66 0 .66];
             [.66 .66 0];
             [0 0 .33];
             [0 .33 0];
             [0 .33 .33];
             [.33 0 0];
             [.33 0 .33];
             [.33 .33 0];
            };
dip_option = cell2mat(dip_option);

if plot_all
  load([FilePath 'RS' SL MN SL 'IC00_component_' cls_ver '_' MN]);
  IC00_tmp = IC00(2 : end); IC00_tmp = reshape(IC00_tmp, 2, size(IC00_tmp, 1) / 2); IC00_tmp = IC00_tmp';
%   %convert component index to char (for sorting)
%   for i = i : size(IC00_tmp, 1)
%     IC00_tmp(i, 2) = {num2str(IC00_tmp{i, 2}, '%02d')};
%   end
%   IC00_tmp = sortrows(IC00_tmp, 2);
%   %convert component index back to int
%   for i = i : size(IC00_tmp, 1)
%     IC00_tmp(i, 2) = {str2double(IC00_tmp{i, 2})};
%   end
end

for i = 1 : size(ClsLabel, 1)
  FilePath = FilePathOld;
  load([FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d') '_component_' cls_ver '_' MN]);
  eval(['IC_tmp = IC' num2str(i, '%02d') '(2 : end);']);
  icawinv_tmp = icawinv;
  chan_tmp = chan_all;
  dip_tmp = dipole_all;
  spec_tmp = spec_all;

  for j = 1 : size(spec_all, 1)
    IC_tmp(2 * j - 1 : 2 * j) = []; com = sprintf('IC_tmp = [IC%02d(1) IC%02d(2 * j : 2 * j + 1) IC_tmp];', i, i); eval(com)
    plot_set = IC_tmp{1, 2};
    plot_comp = IC_tmp{1, 3};
    [subj ExpDate] = strtok(plot_set, '_'); ExpDate = ExpDate(2 : end);
    icawinv_tmp(:, j) = []; icawinv_tmp = [icawinv(:, j) icawinv_tmp];
    chan_tmp(j) = []; chan_tmp = [chan_all(j) chan_tmp];
    spec_tmp(j, :) = []; spec_tmp = [spec_all(j, :); spec_tmp];
    dip_tmp(j) = []; dip_tmp = [dipole_all(j) dip_tmp];
    %after executing the above codes, the first element (row of array or in a cell) is the desired one

    %layout for componet map
    subplt_width = ceil(sqrt(size(spec_all, 1) + 3));
    subplt_height = floor(sqrt(size(spec_all, 1) + 3));
    if size(spec_all, 1) + 3 > subplt_width * subplt_height
      subplt_height = subplt_height + 1;
    end

    figure(4003);  %component map
    figure(4001);  %dipole
    hold on;
    figure(4009);  %spectra
    hold on;
    for k = 1 : size(spec_all, 1)
      plot_set_tmp = IC_tmp{1, 2 * k};
      plot_comp_tmp = IC_tmp{1, 2 * k + 1};
      chanlocs = chan_tmp{k};
      if k == 1
        figure(4003)  %component map
        subplot(subplt_height, subplt_width, [1 2 subplt_width + 1 subplt_width + 2]); axis off;
        topoplot(icawinv_tmp(find(~isnan(icawinv_tmp(:, k))), k), chanlocs, 'electrodes', 'off', 'shrink', 'force');
        title([subj '\_' ExpDate], 'FontName', FONT_FACE, 'FontSize', 8, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'cap');
        figure(4001)  %dipole
        subplot('position', [.1 .1 .8 .8]); axis off;
        target = gca;
        eval(['dipplot(dip_tmp{k}, ''mri'', mrifile, ''view'', view_angle_single, ''color'', {[1 1 0]}, ' ...
          '''dipolesize'', 20, ''dipolelength'', 0, ' [dip_option ', ''coordformat'', ''spherical'''] ');']);
        figure(4009)  %spectra
        plot(freqs, spec_tmp(k, :), '-k', 'LineWidth', 1.5);
      else
        figure(4003)  %component map
        if k + 1 <= subplt_width
          subplot(subplt_height, subplt_width, k + 1);
        else
          subplot(subplt_height, subplt_width, k + 3);
        end
        topoplot(icawinv(find(~isnan(icawinv_tmp(:, k))), k), chanlocs, 'electrodes', 'off', 'shrink', 'force');
        figure(4002)
        subplot('position', [.1 .1 .8 .8]); axis off;
        eval(['dipplot(dip_tmp{k}, ''mri'', mrifile, ''view'', view_angle_single, ''color'', {[0 1 1]}, ' ...
          '''dipolesize'', 5, ''dipolelength'', 0, ' [dip_option ', ''coordformat'', ''spherical'''] ');']);
        h1 = findobj(gcf, 'Type', 'line');
        figure(4001);  %copy into main window
        copyobj(h1, target);
        close(4002);
        figure(4009);
        plot(freqs, spec_tmp(k, :), 'LineStyle', '-', 'Color', [.75 .75 .75]);
      end
    end
    figure(4001);
    subplot('position', [0.025 .9 .95 .01]); axis off;
    text(0, .95, ['\color[rgb]{0 0 0}' subj '\_' ExpDate '-' num2str(plot_comp, '%02d')], 'FontName', FONT_FACE, 'FontSize', 8, ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'cap');
    figure(4009);
    text(50, 10, [subj '\_' ExpDate '-' num2str(plot_comp, '%02d')], 'FontName', FONT_FACE, 'FontSize', 8, ...
        'HorizontalAlignment', 'right', 'VerticalAlignment', 'cap');
    hold off;
    xlim(power_xlim);
    ylim(power_ylim);
    set(gca, 'Box', 'off', 'XTick', 0 : 10 : 50, 'YTick', -30 : 10 : 10, ...
        'FontName', FONT_FACE, 'FontSize', 8, 'Color', BACKGROUND_COLOR);
    xlabel('Frequency (Hz)', 'VerticalAlignment', 'cap');
    ylabel('Power (dB)', 'FontName', FONT_FACE, 'FontSize', 8, 'VerticalAlignment', 'baseline');

    %set background
    for k = [4001 4003 4009]
      set(k, 'color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');
    end

    %save figure
    for k = [4009 4001]
      %power spectra
      figure(4009);
%       saveas(gcf, [FilePath plot_set SL 'IC' num2str(plot_comp, '%02d') '_Cluster_Spectra.fig'], 'fig');
%       print('-dpng', [FilePath plot_set SL 'IC' num2str(plot_comp, '%02d') '_Cluster_Spectra.png']);
      close(4009);

      %dipole
      figure(4001);
%       saveas(gcf, [FilePath plot_set SL 'IC' num2str(plot_comp, '%02d') '_DipoleMap.fig'], 'fig');
%       print('-djpeg', [FilePath plot_set SL 'IC' num2str(plot_comp, '%02d') '_DipoleMap.jpeg']);
      close(4001);

%     %dipole (single plot)
      figure(4003);
%       saveas(gcf, [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_DipoleMap_' cls_ver '_single_' MN ], 'fig');
%       print('-djpeg', [FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d'), '_DipoleMap_' cls_ver '_single_' MN '.jpeg']);
      close(4003);
    end
  end
end