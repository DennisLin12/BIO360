allcomp = 1 : 30;
allchans = 30;  %30-channel data
ClsLabel = {
            'Frontal';  %1
            'Left Frontal';  %2
            'Right Frontal';  %3
            'Central';  %4
            'Parietal';  %5
            'Left Somatomotor';  %6
            'Right Somatomotor';  %7
            'Occipital Midline';  %8
            'Bilateral Occipital';  %9  +\/+
            'Tangential Occipital';  %10 +\/-
           };
SET = {%Set, [component; cluster]
       's01_061102', ...
           [5 6 7 8  9 10 11 12 13 14 15;
            8 1 5 4 -9 9  7  3  -2 10 -6], ...
            'motionless';
%        's05_060308', ...  %1 hr
%            [3 4 5 6 7 8 9 11 12 14 16 17;
%             2 4 5 7 9 1 3 5  6  8  -9 -9];
       's05_061101', ...
           [3 4 6 7  8  9 10 11 13;
            4 9 5 2 -9 -8 6  9  5], ...
            'motionless';
       's05_061019', ...
           [ 3 4 5 6 7 8 9 10 12 15 16 17 18 20 21 22 24;
            -8 9 1 4 8 7 6  2  5 -3  3  7  9 10 -6 -6 -6], ...
            'motion';
%        's11_060920', ...  %1 hr
%            [4 5 7 8 9 23; 
%             9 9 6 7 5 -5];
%        's16_060717', ...  %1 hr
%            [5 6 7 8 9 10 11 12 13 14 15 16 17; %[13 5]
%             5 8 3 1 7 4  -6 -7 4  2  -9 6  9];
%        's18_060303', ...  %1 hr
%            [4 5 8 9 10 12 15; ...
%             5 9 7 1 2  10 3];
%        's28_060707', ...  %1 hr
%            [2  5 6 7 8 9  10 11 13; 
%             -4 3 2 7 1 -9 9  6  9];
%        's31_061103', ...  %2 hr, DIGITIZED (obsolete)
%            [5 6 7 8 9 10 13;
%             2 9 3 5 6 4  10];
       's31_061103', ... 
           [5 6  7 8  9 10 11 12 13 16 20;
            2 9 -7 5 +6 4  -5  7 10  3 -1], ...
            'motionless';
%        's31_061020', ... 
%            [3 6 7  8 9 10 11 13 15 16;
%             1 9 5 -5 7 6  4  2  10 -9], ...
%             'motion';
       's31_061020', ... 
           [3 6 7 9 10 11 13 15;
            1 9 5 7 6  4  2  10], ...
            'motion';
       's32_061031', ...  %2 hr
           [3 4 6 7 8 9 10 11 12;
            9 9 5 8 6 7 1  2  1], ...
            'motionless';
%        's35_070322', ...  %2 hr OLD
%            [2  5 6  7 8 9  11 12;
%             -9 5 -1 8 3 -6 -5 10];
       's35_070322', ...  %2 hr
           [3 7 8  9 10 11 12 13;
            9 5 4 +8 3  1  9  6], ...
            'motionless';
%        's35_070115', ...  %2 hr, MOTION, OLD
%            [2 4 6 7 9 10 11 12 14;
%             9 5 3 1 4 8  2  9 -6], ...
%             'motion';
       's35_070115', ...  %2 hr, MOTION
           [2 4 6 7 9 10 11 12 14;
            9 5 3 1 4 8  2  10 -6], ...
            'motion';
%        's36_061221', ...  %OLD
%            [3 4 5 7 8 9 11 12 13 16 17;
%             4 8 9 5 1 6 3  2  7  7  9];
       's36_061221', ...
           [2 4 6 7 8 9 10 12 14 16;
            4 9 8 1 6 5 3  7  2  10], ...
            'motionless';
%        's36_061122', ...  %2 hr, MOTION
%            [2 3 4 7 9 10 11 14 15 17;
%             1 4 9 6 8 7  -9 3  2  -5], ...
%             'motion';
       's36_061122', ...  %2 hr, MOTION
           [2 3 4 7 9 10 11 14 15 17;
            1 4 9 6 7 8  -9  3  2 +5], ...
            'motion';
%        's37_061213', ...  %2 hr
%            [4 5 6 10 15;
%             4 9 5 10 7], ...
%             'motionless';
%        's39_070117', ...  %2 hr
%            [4 5 6 7 8 9;
%             9 9 5 4 8 7], ...
%             'motionless';
       's39_061218', ...  %2 hr, MOTION
           [3 5  6 7 8 10 14;
            9 5 -8 2 9  6 -1], ...
            'motion';
%        's40_070207', ...  %2 hr  OLD
%            [3  4 5 6 7 9 10 11 12 13 14; %[10; 5]
%             -9 4 7 6 8 9 -6 10 2  3  1];
%        's40_070207', ...  %2 hr  OLD
%            [2 3 5 7 8  9 10 11 13 14 15 17 18;
%             9 4 6 8 -3 6 7  -3 10 2  -9 -1 -2], ...
%             'motionless';
       's40_070207', ...  %2 hr
           [2 3 4 7 8 9 12 13 14;
            9 4 5 8 6 3 10  7  2], ...
            'motionless';
%        's40_070207', ...  %2 hr NOREJ
%            [9 10 12 24;
%             9 1  5  10], ...
%             'motionless';
       's40_070131', ...  %2 hr, MOTION
           [3 4 7 10 12;
            9 5 1 10 -6], ...
            'motion';
%        's41_061225', ...  %2 hr OLD
%            [2 3 6 7 8 9 10 11 12 14 16 19 21; 
%             1 5 4 9 7 9 3  4  6  2  9  -9  6];
       's41_061225', ...  %2 hr
           [2 3 4 6 7 8 9 10 11 14 18 21; 
            3 1 5 9 9 7 4 6  2  -9 +2 6], ...
            'motionless';
%        's41_061225', ...  %2 hr, NOREJ
%            [3 5 8 9 10 11 13 15 22; 
%             1 5 9 4 9  7  6  -2 -6], ...
%             'motionless';
%        's42_061222', ...  %1 hr
%            [3 6 7 8; ...
%             9 6 9 1];
%        's42_061222', ...  %1 hr
%            [3 4 6 7  8; ...
%             9 1 5 10 5];
       's42_070105', ...  %2 hr
           [4 5 7  13 14;
            9 5 10 1  -4], ...
            'motionless';
%        's43_070208', ...  %2 hr  OLD
%            [5 6 8  10 11 14 18;
%             5 9 -9 -5 7  -9 -9];
       's43_070208', ...  %2 hr
           [5 6  7 8 9 11;
            5 9 -2 4 7 10], ...
            'motionless';
       's43_070202', ...  %2 hr, MOTION
           [4 9  10 11;
            9 10 5  7], ...
            'motion';
%        's44_070325', ...  %2 hr  OLD
%            [4  5 6 8 13 14; %[8; 5]
%             -1 9 5 4 10 6];
       's44_070325', ...  %2 hr
           [5 6 7  8 10 11 12 13 25;
            1 5 4 +8 6 -2 -7 -1 10], ...
            'motionless';
       's44_070126', ...  %2 hr, MOTION
           [4 6 7  8 9 10 11;
            1 9 2 -5 5 7  -9], ...
            'motion';
       's44_070209', ...  %2 hr, MOTION
           [4 5 8 9 13;
            5 1 9 4 10], ...
            'motion';
       's54_081209n', ...  %2 hr
           [2 3 4 5 6 7 9 10 12 13 14;
            4 3 9 5 1 9 6 2  7  -9 -9], ...
            'motionless';
%        'sine_test', ...
%            [1 2 3 4; 0 0 0 0];
      };
% EpochType = {
%              '_intrial';
%             };
EpochType = {
             '_dev_on';
            };
cls_ver = '090212';  %cluster version
SR = 250;  %sampling rate
% min_freq = 0;
% max_freq = 50;
min_freq = 3;  %[min_freq max_freq]: freq limits for doing time-frequency transform
max_freq = 45;
min_RT = 0;  %trials' max RT (sec)
max_RT = Inf;  %trials' max RT (sec)
alert.rt = 3;  %line to mark drowsiness. 3: RT > 3 sec => deep drowsy, mark a line at 3 sec.
% alert.rate = .25;
alert.rate = .1;  %.1: the fastest 10%
FREQ_BAND = {%'Name', [freq], [color]
             %'\delta', [0 3], [??];
             '\theta', [4 7], [1 0 0];
             '\alpha', [8 12], [0 0 1];
             '\alpha + \theta', [4 12], [.66 0 .66];
%              '\sigma', [13 16], [0 .25 0];
%              'L-\beta', [17 20], [0 .5 0];
%              'H-\beta', [21 25], [0 .75 0];
             'L-\beta', [13 20], [0 .33 0];
             'H-\beta', [21 25], [0 .66 0];
            };
% alpha_freq = [8 12];
% theta_freq = [4 7];
%normalization
%1: use fastest 10% of EACH subject (normalizing each subject's data by its baseline) {default}
%2: use fastest 10% of ALL subject (normalizing all subject by this baseline)
%3: find the fastest 10% of EACH subject, calculate the power, and then avegage. use this as the baseline
%4: similar to 3, but consider the weighting
% %only function in calculating group data
% nor = 1;
% p_val = 1E-10;  %p-value
curfit_order = 3;  %use this order to do curve fitting

%Plotting parameters (CSS :p)
FONT_FACE = 'Helvetica';
%font size
FONT_SIZE = 8;  %text
TITLE_FSIZE = 12;  %title
STITLE_FSIZE = 8;  %subtitle
AXIS_FSIZE = 7;  %axis
CBAR_FSIZE = 7;  %color bar
% FONT_SIZE = 12;  %text
% TITLE_FSIZE = 14;  %title
% STITLE_FSIZE = 12;  %subtitle
% AXIS_FSIZE = 12;  %axis
% CBAR_FSIZE = 12;  %color bar
% %Blackboard
% BACKGROUND_COLOR = 'k';
% FONT_COLOR = '{.867 .867 .867}';
% ALPHA_COLOR = [.4 .8 1];
% THETA_COLOR = [1 .6 .8];
% RT_COLOR = [.867 .867 .867];
% CONTOUR_COLOR = [.867 .867 .867];
% CONTOUR_WIDTH = 1;
% %White
BACKGROUND_COLOR = [.95 .95 .95];  %avoid using pure white in power point
% BACKGROUND_COLOR = [1 1 1];  %avoid using pure white in power point
FONT_BKCOLOR = [.75 .75 .75];
FONT_COLOR = '{0 0 0}';
% ALPHA_COLOR = [0 0 1];
% THETA_COLOR = [1 0 0];
AXIS_COLOR = [0 0 0];
RT_COLOR = [.5 .5 .5];
CONTOUR_COLOR = [.5 .5 .5];
CONTOUR_WIDTH = 1;
%dipole
view_angle = [45 30];  %view angles
view_angle_single = [40 20];
HeadFilePath = '/home/eeglab5.03/eeglab5.03/plugins/dipfit2.0/standard_BESA/';  %.4, using BESA
hdmfile = [HeadFilePath 'standard_BESA.mat'];  %head model
mrifile = '/home/eeglab5.03/eeglab5.03/plugins/dipfit2.0/standard_BEM/standard_mri.mat';  %MRI file, using MNI in paper
chanfile = [HeadFilePath 'standard-10-5-cap385.elp'];  %electrodes
dip_option = {%for plotting dipole. see help -> pop_dipplot / dipplot for details
              '''axistight'', ' '''off'', ', ...  %for MRI only, display the closest MRI slide
              '''drawedges'', ' '''off'', ', ...  %draw edges of the 3-D MRI (black in axistight, white otherwise.)
              '''mesh'', '      '''off'', ', ...  %display spherical mesh
              '''gui'', '       '''off'', ', ...  %display controls. if gui 'off', a new figure is not created.
              '''summary'', '   '''off'', ', ...  %build a summary plot with three views (top, back, side)
              '''verbose'', '   '''off'', ', ...  %comment on operations on command line
              '''normlen'', '   '''on'', ' , ...  %normalize length of all dipoles
              '''num'', '       '''off'', ', ...  %display component number
              '''cornermri'', ' '''off'', ', ...  %force MRI images to the corner of the MRI volume (useful when background is not black)
              '''pointout'', '  '''off'', ', ...  %point the dipoles outward
              '''spheres'', '   '''off'''    ...  %plot dipole markers as 3-D spheres
             };
%               '''projimg'', '   '''off'', ', ...  %project dipole(s) onto the 2-D images, for use in making 3-D plots
%               '''projlines'', ' '''off'', ', ...  %plot lines connecting dipole with 2-D projection
dip_color = {%for single dipole map
             [0 0 1];
             [0 1 0];
             [0 1 1];
             [1 0 0];
             [1 0 1];
             [1 1 0];
             [0 0 .66];
             [0 .66 0];
             [0 .66 .66];
             [.66 0 0];
             [.66 0 .66];
             [.66 .66 0];
             [0 0 .33];
             [0 .33 0];
             [0 .33 .33];
             [.33 0 0];
             [.33 0 .33];
             [.33 .33 0];
            };
dip_option = cell2mat(dip_option);