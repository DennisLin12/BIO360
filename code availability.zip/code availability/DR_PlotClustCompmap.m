%Plot avg component map in a cluster
%ver 200904
%pre_ver: none

%% set parameters (initialize)
try
  close(2041);
end
clear all;
SL = '\';
FilePath = '';
if isunix
  mypath;
  FilePath = '~/liang/';  %directory
  SL = '/';
end
DR_PBase_setup;  %load setup file
MN = 'motion';
if strcmpi(MN, 'motionless')
  MN_COLOR = '{0 0 1}';
elseif strcmpi(MN, 'motion')
  MN_COLOR = '{1 0 0}';
else
  MN_COLOR = '{0 1 0}';
end
FilePathOld = FilePath;
rj = '_rj';
%font size
FONT_SIZE = 12;  %text
TITLE_FSIZE = 14;  %title
STITLE_FSIZE = 12;  %subtitle
AXIS_FSIZE = 12;  %axis
CBAR_FSIZE = 12;  %color bar

%% compute dimension
% ClsLabel(2 : 3) = [];
subplt_width = ceil(sqrt(size(ClsLabel, 1)));
subplt_height = floor(sqrt(size(ClsLabel, 1)));
if size(ClsLabel, 1) > subplt_width * subplt_height
  subplt_height = subplt_height + 1;
end
subplt_x = floor(10000 / subplt_width) / 10000;  %floor(10000 / 3) / 10000 = .3333
subplt_y = floor(9500 / subplt_height) / 10000;  %floor(9500 / 6) / 10000 = .1583 = roundn(.95/6, -4) = .1583
blank_x = (1 - subplt_x * subplt_width) / 2;
blank_y = (1 - subplt_y * subplt_height) / 2;
figure(2041);
set(gcf, 'Renderer', 'ZBuffer');
%title
subplot('position', [0 .95 1 .05]); axis off;
text(.5, .5, ['\color[rgb]' FONT_COLOR 'Average Scalp Map of \color[rgb]' MN_COLOR upper(MN) '\color[rgb]' FONT_COLOR ' Datasets'], ...
    'FontName', FONT_FACE, 'FontSize', TITLE_FSIZE, 'FontWeight', 'Bold', 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle');
for i = 1 : size(ClsLabel, 1)
  %load ICA inverse weight vector (icawinv)
%   if i >= 2
%     i = i + 2;
%   end
  load([FilePath 'RS' SL MN SL 'IC' num2str(i, '%02d') '_component_' cls_ver '_' lower(MN) '.mat'], 'avg_icawinv', 'std_chanlocs');
%   if i >= 4
%     i = i - 2;
%   end
  subplot('position', ...
      [blank_x + mod(i - 1, subplt_width) * subplt_x, .95 - blank_y - ceil(i / subplt_width) * subplt_y, ...
      subplt_x, subplt_y]);
  try
    DR_topoplot(avg_icawinv, std_chanlocs, 'electrodes', 'off', 'shrink', 'force');
  catch
    topoplot(avg_icawinv, std_chanlocs, 'electrodes', 'off', 'shrink', 'force');  %original in EEGLAB
  end
  title(['\color[rgb]' FONT_COLOR ClsLabel{i}], ...
      'FontName', FONT_FACE, 'FontSize', STITLE_FSIZE, 'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Middle');
end
set(gcf, 'Color', BACKGROUND_COLOR, 'InvertHardcopy', 'off');

%save figure
%component map
figure(2041);
saveas(gcf, [FilePath 'RS' SL MN SL 'Avg_Scalp_Map_' cls_ver '_' MN '.fig'], 'fig');
print('-dpng', [FilePath 'RS' SL MN SL 'Avg_Scalp_Map_' cls_ver '_' MN '.png']);
close(2041);