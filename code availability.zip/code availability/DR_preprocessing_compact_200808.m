% Preprocessing for drowsiness (long-term and single trial) in BRC
% by poem
% recovered in 2008/6

% clear all;
FilePath = '';
if isunix
  mypath;
  FilePath = '~/Drowsiness/';
  SL = '/';
end
DataFormat = '16';
SET = {
%        's18_060120';
%        's18_060121';
%        's18_060228';
%        's22_060718A';
%        's23_060707';
%        's23_060711B';
       's31_061020m';
%        's41_070117';
%        's48_080501n';
%        's22_080513m';
%        's48_080516m';
%        's41_080520m';
%        's49_080527n';
%        's22_080529n';
%        's41_080530n';
%        's49_080602m';
%        's50_080725n';
%        's50_080731m';
      };
CASE = {
        'penta';
       };
EpochType = {
             '01';
             '02';
             '03';
             '04';
             '05';
             '06';
            };
DeleteChannel = [1 2 5 6 27 33];
% DeleteChannel = [];
ExtractEpoch = {
                '1251', '1252', '2251', '2252', '3251', '3252', '4251', '4252', '5251', '5252', '6251', '6252';
               };
rj = '_rj';
epoch_start = -2;
epoch_end = 6;
FilePathOld = FilePath;

%% begin preprocessing 
for i = 1 : size(SET, 1)
  RT = [];  %reaction time of each trial
  [ALLEEG EEG CURRENTSET ALLCOM] = eeglab;
  FilePath = FilePathOld;
  Set = SET{i, 1};
  FilePath = [FilePath Set SL];
  ChanLoc = [Set '.xyz'];
  CNT_FILE = [Set '.cnt'];
  EVENT_FILE = [Set '_event.txt'];
  [subj ExpDate] = strtok(Set, '_'); ExpDate = ExpDate(2 : end);
  rj_latency1 = []; rj_latency2 = [];% rj_latency2A = []; rj_latency3 = [];  %for storing rejected EEG intervals
  RT = [];
  
%% interpolate events
  try
    evt = load([FilePath EVENT_FILE]);  %sxx_yymmdd_event_new.txt
  catch
    error('Fail to load modified event file');
  end
  evt(:, [3 4]) = [];
  %calculate time difference between 2 events for future use
  evt(1, 4) = 8;
  for j = 2 : size(evt, 1)
    evt(j, 4) = evt(j, 3) - evt(j - 1, 3);
  end
  %interpolate  (no event when crashing => interpolate)
  evt_tmp1 = [];
  idx = find((evt(:, 2) == 0 | evt(:, 2) == 233) & evt(:, 4) > 10);
  for j = 1 : size(idx, 1)
    evt_tmp1 = [evt_tmp1; evt(idx(j) - 1, :); evt(idx(j), :)];
  end
  evt_tmp2 = [];
  for j = 1 : 2 : size(evt_tmp1, 1)
    for k = evt_tmp1(j, 3) + 8 : 8 : evt_tmp1(j + 1, 3) - 1
      evt_tmp2 = [evt_tmp2; evt_tmp1(j + 1, 1 : 2) k 8];
    end
  end
  evt = [evt; evt_tmp2];
  evt = sortrows(evt, 3);
  %fix index of event
  if ~isequal(evt(:, 1), (1 : size(evt(:, 1), 1))')
    evt(:, 1) = (1 : size(evt(:, 1), 1))';
  end
  evt(:, 4) = [];
  evt = sortrows(evt, [1 3]);
  clear evt_compact_idx evt_tmp1 evt_tmp2;

%% check if incomplete or error trial exists
  %fix the first and the last events
  if evt(1, 2) > 250  %1st point
    evt(1, 2) = evt(2, 2);
  end
  if evt(end, 2) > 250 & evt(end, 2) ~= 254  %last point
    evt(end, 2) = evt(end - 1, 2);
  end
  %extract event mark
  evt_tmp = find(evt(:, 2) >= 250);  %evt: event file
  evt_mark = evt(evt_tmp, :);
  help DR_check_incomplete;
  [evt_mark evt_tmp] = DR_check_incomplete(evt_mark, 2);
  if ~isempty(evt_tmp)
    fprintf('Manually remove incomplete trials:\n');
    fprintf('Save rj_latency1:\n');
    fprintf('');  %for setting breakpoint
  end
  rj_latency1 = round(rj_latency1 / 2);  %downsampling to 250 Hz
  save([FilePath Set '_rejected_trials'], 'rj_latency1');  %save rejected information
  %after this step, evt_mark should be [(251/252) - 253 - 254] + [(251/252) - 253 - 254] ...
  %save information of each epoch (behavior time)

%% modify event value according to reaction time
  epoch_inf = [];
  for j = 1 : 3 : size(evt_mark, 1)
    RT_tmp = (evt_mark(j + 1, 3) - evt_mark(j, 3)) / 500;
    epoch_inf = [
                 (j + 2) / 3  %evt_idx
                 evt_mark(j, 1),  %original index of dev_on
                 evt_mark(j, 2),  %original event type of dev_on
                 evt_mark(j, 3),  %latency of dev_on
                 evt_mark(j + 1, 1),  %original index of act_on
                 evt_mark(j + 1, 2),  %original event type of act_on
                 evt_mark(j + 1, 3),  %latency of act_on
                 evt_mark(j + 2, 1),  %original index of dev_off
                 evt_mark(j + 2, 2),  %original event type of dev_off
                 evt_mark(j + 2, 3),  %latency of dev_off
                 RT_tmp,  %RT
                ]';
    if RT_tmp < 0.4
      epoch_inf([3 6 9]) = epoch_inf([3 6 9]) + 1000;
      evt_mark(j : j + 2, 2) = evt_mark(j : j + 2, 2) + 1000;
    elseif 0.4 <= RT_tmp & RT_tmp <= 0.65
      epoch_inf([3 6 9]) = epoch_inf([3 6 9]) + 2000;
      evt_mark(j : j + 2, 2) = evt_mark(j : j + 2, 2) + 2000;
    elseif 0.65 < RT_tmp & RT_tmp < 0.95
      epoch_inf([3 6 9]) = epoch_inf([3 6 9]) + 3000;
      evt_mark(j : j + 2, 2) = evt_mark(j : j + 2, 2) + 3000;
    elseif 0.95 <= RT_tmp & RT_tmp <= 1.25
      epoch_inf([3 6 9]) = epoch_inf([3 6 9]) + 4000;
      evt_mark(j : j + 2, 2) = evt_mark(j : j + 2, 2) + 4000;
    elseif 1.25 < RT_tmp & RT_tmp <= 5
      epoch_inf([3 6 9]) = epoch_inf([3 6 9]) + 5000;
      evt_mark(j : j + 2, 2) = evt_mark(j : j + 2, 2) + 5000;
    else
      epoch_inf([3 6 9]) = epoch_inf([3 6 9]) + 6000;
      evt_mark(j : j + 2, 2) = evt_mark(j : j + 2, 2) + 6000;
    end
    for k = 2 : 3 : 8
      evt(epoch_inf(k), 2) =  epoch_inf(k + 1);
    end
    RT = [RT; [RT_tmp epoch_inf(4)]];
  end
  clear epoch_inf;
  RT_original = RT(:, 1)';

%% EEG preprocessing: phase I
  %load raw EEG data
  EEG = DR_pop_loadcnt(CNT_FILE, 'dataformat', ['int' DataFormat]);
  [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', Set, 'overwrite', 'on');
  EEG = eeg_retrieve(ALLEEG, 1);
  CURRENTSET = 1;
  eeglab redraw;
  %clear event
  EEG.event = [];
  eeglab redraw;
  %select channel
  if (DeleteChannel)
    EEG = pop_select(EEG, 'nochannel', DeleteChannel);
  end
%   EEG.chanlocs = pop_chanedit(EEG.chanlocs, 'load',{ChanLoc, 'filetype', 'xyz eeglab'}, 'delete', 1 : 5);
%   eeglab redraw;
  %50Hz LPF
  EEG = pop_eegfilt(EEG, 0, 50, [], [0]);
  eeglab redraw;
  fprintf('\n');
  [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', Set, 'overwrite', 'on');
  %0.5Hz HPF
  EEG = pop_eegfilt(EEG, 0.5, 0, [], [0]);
  eeglab redraw;
  fprintf('\n');
  [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', Set, 'overwrite', 'on');
  %down sampling
  EEG = pop_resample(EEG, 250);
  eeglab redraw;
  [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', Set, 'overwrite', 'on');
  %save dataset ("_pre")
  EEG = pop_editset(EEG, 'setname',  [subj '_' ExpDate '_pre']);
  [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
  EEG = pop_saveset(EEG, [FilePath Set '_pre.set']);
  %import eventfile
  %make fake channel (35, 39, and 40)
  evt(:, 4) = round(evt(:, 3) / 2);  %original 500 Hz => 250 Hz
  RT(:, 2) = round(RT(:, 2) / 2);
  %for event file
  EEG.data(40, :) = -1;
  EEG.data(40, evt(:, 4)') = -evt(:, 2)';
  EEG.data(39, RT(:, 2)) = RT(:, 1);
  %for checking abnormal behavior
  traj = [evt(:, 2) evt(:, 4)];
  clear evt;
  %remove event points
  if mod(traj(1, 1), 1000) == 251 | mod(traj(1, 1), 1000) == 252  %must be dev_on; checked before
    traj(1, 1) = traj(2, 1);
  end
  if mod(traj(end, 1), 1000) == 254  %must be dev_off; checked before
    traj(end, 1) = traj(end - 1, 1);
  end
  for j = 2 : size(traj, 1) - 1
    if mod(traj(j, 1), 1000) == 251  %dev_on
      traj(j, 1) = traj(j - 1, 1);
      direct = 0;  %left
    elseif mod(traj(j, 1), 1000) == 252  %dev_on
      traj(j, 1) = traj(j - 1, 1);
      direct = 1;  %right
    elseif mod(traj(j, 1), 1000) == 253 | mod(traj(j, 1), 1000) == 254 | mod(traj(j, 1), 1000) == 255  %act_on and dev_off
      if j > 10
        Prev = find(traj(j - 10 : j - 1, 1) < 250, 1, 'last');
        Prev = traj(j - 11 + Prev, 1);
      else
        Prev = find(traj(1 : j - 1, 1) < 250, 1, 'last');
        Prev = traj(Prev, 1);
      end
      if j <= size(traj, 1) - 10
        Next = find(traj(j + 1 : j + 10, 1) < 250, 1, 'first');
      else
        Next = find(traj(j + 1 : end, 1) < 250, 1, 'first');
      end
      Next = traj(j + Next, 1);
      if mod(traj(j, 1), 1000) == 253  %act_on
        if direct == 0  %left
          traj(j, 1) = min(Prev, Next);
        else  %right
          traj(j, 1) = max(Prev, Next);
        end
      else  %dev_off
        traj(j, 1) = round(mean(Prev, Next));
      end
    end
  end
  %interpolate into 250 Hz
  traj_tmp = zeros(traj(end, 2) - traj(1, 2) + 1, 2);
  traj_tmp(1, :) = traj(1, :);
  traj_idx = 1;  %next frame
  for j = 2 : size(traj, 1)
    frame_diff = traj(j, 2) - traj(j - 1, 2);
    traj_diff = traj(j, 1) - traj(j - 1, 1);
    traj_inc = traj_diff / frame_diff;
    for k = 1 : frame_diff - 1
      traj_tmp(traj_idx + k, 1) = traj(j - 1, 1) + round(traj_inc * k);
      traj_tmp(traj_idx + k, 2) = traj(j - 1, 2) + k;
    end
    traj_idx = traj_idx + frame_diff;
    traj_tmp(traj_idx, :) = traj(j, :);
  end
  EEG.data(35, traj_tmp(:, 2)) = traj_tmp(:, 1);
  EEG = pop_importevent(EEG, 'append', 'no', 'event', [evt_mark(:, [1 2]), round(evt_mark(:, 3) / 2)], ...
      'fields',{'index', 'type', 'latency'}, 'skipline', 0, 'timeunit', 0.004, 'align', NaN);
  eeglab redraw;
  EEG = eeg_eegrej(EEG, rj_latency1);
  %plot EEG data for noise removal
  %for behavior (not for s41/48/49)
  %extract epoch information
  Epoch = ExtractEpoch(1, :);
  EEG = pop_epoch(EEG, Epoch, [epoch_start epoch_end], 'newname',  [Set '_intrial'], 'epochinfo', 'yes');
  EEGtmp = EEG.data;  %keep fake channels
  EEG = pop_select(EEG, 'nochannel', 31 : 40);  %temporarily remove fake channels
  EEG = pop_rmbase(EEG, [epoch_start * 1000 0]);
  for j = 1 : size(EEG.data, 3)  %reload fake channels
    EEG.data([35 39 40], :, j) = EEGtmp([35 39 40], :, j);
  end
  clear EEGtmp
  [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', [Set '_intrial'], 'overwrite', 'on');
  [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
  eeglab redraw;
  EEG = pop_saveset(EEG, [FilePath Set '_intrial']);
  eegplot(EEG.data, 'srate', 250, 'dispchans', 0, 'spacing', 120, 'winlength', 5, 'events', EEG.event, 'command', ...
      'TMPREJ = sortrows(TMPREJ, 1); rj_latency2 = TMPREJ(:, 2)'' / (EEG.pnts); EEG.reject.rejmanual = zeros(size(EEG.epoch)); EEG.reject.rejmanual(rj_latency2) = true; EEG = pop_select(EEG, ''notrial'', rj_latency2);', ...
      'position', [0, 0, 1024, 768], 'wincolor', [1 1 .783]);
%   save([FilePath Set '_rejected_trials'], 'rj_latency2', '-append');  %save rejected information
  EEG.reject.rejmanual(rj_latency2) = true;
%   EEG = eeg_eegrej(EEG, rj_latency2A);
%   eegplot(EEG.data, 'srate', 250, 'dispchans', 29, 'spacing', 40, 'winlength', 5 / (EEG.pnts / EEG.srate), 'events', EEG.event, 'command', ...
%       'TMPREJ = sortrows(TMPREJ, 1); rj_latency2 = TMPREJ(:, 2) / (EEG.pnts); EEG = pop_select(EEG, ''notrial'', rj_latency2);', ...
%       'position', [0, 0, 1024, 768], 'wincolor', [1 1 .783]);
%   save([FilePath Set '_rejected_trials'], 'rj_latency2', '-append');  %save rejected information
%   EEG = eeg_eegrej(EEG, rj_latency2);
%   EEG = pop_select(EEG, 'notrial', rj_latency2);
  clear TMPREJ;
  %check if incomplete trials exists after noise removal
%   evt_tmp2 = [];
%   idx_boundary = [];
%   %load event information from EEG data
%   for j = 1 : size(EEG.event, 2)
%     event_tmp = EEG.event(j);
%     if ~strcmp(EEG.event(j).type, 'boundary')
%       evt_tmp2 = [evt_tmp2; event_tmp.index str2double(event_tmp.type) event_tmp.latency event_tmp.urevent];
% %       evt_tmp2 = [evt_tmp2; event_tmp.index event_tmp.type event_tmp.latency event_tmp.urevent];
%     else
%       evt_tmp2 = [evt_tmp2; 0 -1 event_tmp.latency 0];
%       idx_boundary = [idx_boundary; j];
%     end
%   end
%   evt_tmp2(:, 5 : 6) = 0;
%   if idx_boundary(1) ~= 1
%     [evt_tmp1 evt_tmp] = DR_check_incomplete(evt_tmp2(1 : idx_boundary(1) - 1, :), 2);
%     size_diff = size(1 : idx_boundary(1) - 1, 2) - size(evt_tmp1, 1);  %(original size) - (new size)
%     if ~isempty(evt_tmp)
%       evt_tmp1(evt_tmp, 8) = 0;
%     end
%     evt_tmp2(1 : idx_boundary(1) - 1 - size_diff, :) = evt_tmp1(:, [1 : 4 7 8]);
%     if size_diff ~= 0  %some events were removed
%       %change the remaining redundant event into 0
%       evt_tmp2(idx_boundary(1) - 1 - size_diff : idx_boundary(2) - 1, [1 2]) = 0;
%     end
%   end
%   for j = 1 : size(idx_boundary, 1) - 1
%     if ~isempty(idx_boundary(j) + 1 : idx_boundary(j + 1) - 1)
%       [evt_tmp1 evt_tmp] = DR_check_incomplete(evt_tmp2(idx_boundary(j) + 1 : idx_boundary(j + 1) - 1, :), 2);
%       size_diff = size((idx_boundary(j) : idx_boundary(j + 1)), 2) - size(evt_tmp1, 1) - 2;  %(original size) - (new size)
%       if ~isempty(evt_tmp)
%         evt_tmp1(evt_tmp, 8) = 0;
%       end
%       evt_tmp2(idx_boundary(j) + 1 : idx_boundary(j + 1) - 1 - size_diff, :) = evt_tmp1(:, [1 : 4 7 8]);
%       if size_diff ~= 0  %some events were removed
%         %change the remaining redundant event into 0
%         evt_tmp2(idx_boundary(j + 1) - 1 - size_diff : idx_boundary(j + 1) - 1, [1 2]) = 0;
%       end
%     end
%   end
%   if idx_boundary(j + 1) ~= size(evt_tmp2, 1)
%     [evt_tmp1 evt_tmp] = DR_check_incomplete(evt_tmp2(idx_boundary(j + 1) + 1 : end, :), 2);
%     if ~isempty(evt_tmp)
%       evt_tmp1(evt_tmp, 8) = 0;
%     end
%     size_diff = size(idx_boundary(j + 1) + 1 : size(evt_tmp2, 1), 2) - size(evt_tmp1, 1);  %(original size) - (new size)
%     evt_tmp2(idx_boundary(j + 1) + 1 : size(evt_tmp2, 1) - size_diff, :) = evt_tmp1(:, [1 : 4 7 8]);
%     if size_diff ~= 0  %some events were removed
%       %change the remaining redundant event into 0
%       evt_tmp2(size(evt_tmp2, 1) - size_diff : end, [1 2]) = 0;
%     end
%   end
%   idx_boundary = find(evt_tmp2(:, 6) ~= 1 & evt_tmp2(:, 2) ~= -1);  %incomplete trials
%   if ~isempty(idx_boundary)
%     fprintf('Manually remove incomplete trials:\n');
%     fprintf('Save rj_latency3:\n');
%     fprintf('');  %for setting breakpoint
%   end
%   %after above procedures, all the trials are complete in CONTINUOUS data
%   save([FilePath Set '_rejected_trials'], 'rj_latency3', '-append');  %save rejected information
%   %remove boundary event and incomplete trials
%   idx_boundary = find(evt_tmp2(:, 6) ~= 1);  %incomplete trials and boundary events
%   evt_tmp2(idx_boundary, :) = [];
%   epoch_inf = [];
%   for j = 1 : 3 : size(evt_tmp2, 1)
%     epoch_inf_tmp = [
%                      (j + 2) / 3  %evt_idx
%                      evt_tmp2(j, 1),  %original index of dev_on
%                      evt_tmp2(j, 2),  %original event type of dev_on
%                      evt_tmp2(j, 3),  %latency of dev_on
%                      evt_tmp2(j + 1, 1),  %original index of act_on
%                      evt_tmp2(j + 1, 2),  %original event type of act_on
%                      evt_tmp2(j + 1, 3),  %latency of act_on
%                      evt_tmp2(j + 2, 1),  %original index of dev_off
%                      evt_tmp2(j + 2, 2),  %original event type of dev_off
%                      evt_tmp2(j + 2, 3),  %latency of dev_off
%                      evt_tmp2(j + 1, 3) - evt_tmp2(j, 3),  %RT
%                      evt_tmp2(j, 4),  %urevent of dev_on
%                     ]';
%     epoch_inf = [epoch_inf; epoch_inf_tmp];
%   end
%   clear evt_tmp evt_tmp1 evt_tmp2 idx_boundary

%% EEG preprocessing: phase II
  RT = find(EEG.data(39, :) ~= 0); RT = EEG.data(39, RT);
  evt_tmp1 = EEG.data(40, :)';
  evt_tmp_idx1 = find(evt_tmp1 ~= -1);
  evt_zeros = zeros(size(evt_tmp_idx1, 1), 2);
  evt_new = [(1 : size(evt_tmp_idx1, 1))' -evt_tmp1(evt_tmp_idx1) evt_zeros evt_tmp_idx1];
  %save new event file
  fp = fopen([FilePath subj '_' ExpDate '_event_new.txt'], 'w');
  for j = 1 : size(evt_new, 1)
    fprintf(fp, '%d\t%d\t%d\t%d\t%d\n', evt_new(j, 1), evt_new(j, 2), evt_new(j, 3), evt_new(j, 4), evt_new(j, 5));
  end
  fclose(fp);
  EEG = pop_select(EEG, 'nochannel', 31 : 40);
  %read channel locations
  try
    %read digitized one
    EEG.chanlocs = pop_chanedit(EEG.chanlocs, 'load',{ChanLoc, 'filetype', 'xyz eeglab'}, 'delete', [1:7 10 11 32 38], 'eval', 'chantmp = pop_chancenter(chantmp, [], []);');
  catch
  %read channel locations (standard)
    EEG.chanlocs = pop_chanedit(EEG.chanlocs, 'load', {'~/30ch.xyz', 'filetype', 'xyz eeglab'}, ...
        'eval', 'chantmp = pop_chancenter(chantmp, [], []);');
  end
  eeglab redraw;
  %save dataset ("_rj")
  EEG = pop_editset(EEG, 'setname',  [subj '_' ExpDate rj]);
  [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
  EEG = pop_saveset(EEG, [FilePath Set '_intrial' rj '.set']);
%   RT(rj_latency2) = [];
  save([FilePath Set '_RT_of_trials'], 'RT', 'RT_original');

% %% singal trial
%   %extract epoch information
%   Epoch = ExtractEpoch(1, :);
%   EEG = pop_epoch(EEG, Epoch, [epoch_start epoch_end], 'newname',  [Set '_intrial' rj], 'epochinfo', 'yes');
%   EEG = pop_rmbase(EEG, [epoch_start * 1000 0]);
%   [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', [Set '_intrial' rj], 'overwrite', 'on');
%   [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
%   eeglab redraw;
%   EEG = pop_saveset(EEG, [FilePath Set '_intrial' rj]);
%   
%   %check if the epoch is rejected (with no response time information)
%   rj_epoch = [];
%   RT = [];
%   k = 1;
%   for j = 1 : size(EEG.epoch, 2)
%     while epoch_inf(k, 12) ~= EEG.epoch(j).eventurevent{1}
%       k = k + 1;
%       if epoch_inf(k, 12) > EEG.epoch(j).eventurevent{1}  %miss
%         k = k - 1;  %may be next epoch
%         rj_epoch = [rj_epoch j];
%         break;
%       end
%     end
%     if epoch_inf(k, 12) == EEG.epoch(j).eventurevent{1}
%       EEG.epoch(j).RT = epoch_inf(k, 11);
%       RT = [RT; epoch_inf(k, 3) epoch_inf(k, 11) / 250];
%     end
%   end
%   EEG = pop_select(EEG, 'notrial', rj_epoch);
%   EEG = pop_saveset(EEG, [FilePath Set '_intrial' rj]);

%% run ICA
  EEG = pop_runica(EEG,  'icatype', 'runica', 'dataset',1, 'options',{ 'extended', 1});
  EEG = pop_editset(EEG, 'setname',  [Set '_intrial' rj]);
  [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
  eeglab redraw;
  EEG = pop_saveset(EEG, [FilePath Set '_intrial' rj '.set']);
  [subj ExpDate] = strtok(Set, '_'); ExpDate = ExpDate(2 : end);
  pop_topoplot(EEG, 0, [1 : size(EEG.icaact, 1)], [subj '\_' ExpDate], [5 6], 0, 'electrodes', 'on', 'masksurf', 'on');
  clear subj ExpDate;
  print('-dpng', [FilePath Set '_component_map_intrial' rj '.png']);

%% split dataset into groups
  for j = 1 : size(CASE, 1)
    Case = CASE{j, 1};
    for k = 1 : size(EpochType, 1)
      condition = EpochType{k};
      Epoch = [ExtractEpoch(1, 2 * k - 1) ExtractEpoch(1, 2 * k)];
      try
        fprintf(['Epoching epoch type ' ExtractEpoch{1, 2 * k - 1} ' and/or ' ExtractEpoch{1, 2 * k} '...\n']);
        EEG = pop_epoch(EEG, Epoch, [epoch_start epoch_end], 'newname',  [Set '_' Case condition rj], 'epochinfo', 'yes');
        EEG = pop_rmbase(EEG, [epoch_start * 1000 0]);
        [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'setname', [Set '_' Case condition rj], 'overwrite', 'off');
        [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
        eeglab redraw;
        EEG = pop_saveset(EEG, [FilePath Set '_' Case condition rj]);
        ALLEEG = pop_delset(ALLEEG, 2);
        eeglab redraw;
      catch
        fprintf(['Event epoch type ' ExtractEpoch{1, 2 * k - 1} ' and/or ' ExtractEpoch{1, 2 * k} ': no such events\n']);
      end
    end
  end
end